
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetCCARegions] 
PRINT @returnValue 

EXEC [dbo].[spGetCCARegions] 2, 'ap'   , NULL
EXEC [dbo].[spGetCCARegions] 2, 'West' , NULL
EXEC [dbo].[spGetCCARegions] 2, 'st'	, NULL

EXEC [dbo].[spGetCCARegions] 2, 'ap'   , 'ICO'
EXEC [dbo].[spGetCCARegions] 2, 'West' , 'ICO'
EXEC [dbo].[spGetCCARegions] 2, 'st'	, 'ICO'

EXEC [dbo].[spGetCCARegions] 2, 'ap'   , 'SCO'
EXEC [dbo].[spGetCCARegions] 2, 'West' , 'SCO'
EXEC [dbo].[spGetCCARegions] 2, 'st'	, 'SCO'

EXEC [dbo].[spGetCCARegions] 2, NULL   , 'ICO'
EXEC [dbo].[spGetCCARegions] 2, NULL	, 'SCO'

EXEC [dbo].[spGetCCARegions] NULL, NULL, NULL, 1, 5
EXEC [dbo].[spGetCCARegions] NULL, NULL, NULL, 2, 5
EXEC [dbo].[spGetCCARegions] NULL, NULL, NULL, 3, 5


DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetCCARegions] 
	@eventUserID = NULL
	, @searchRegion = NULL -- 'East'
	, @searchProduct = NULL
/*
	, @pageIndex  = 0
	, @pageSize  = 25
	, @sortBy  = 'CCARegionID' 
	, @orderBy  = 1 -- 0: ASC; 1: DESC
*/
PRINT @returnValue 

-- *****************************************************************************************************
