use RevRec

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	

	-- SELECT * FROM DiscrepancyStatuses
	-- SELECT * FROM DiscrepancyCategories

	DECLARE @processMonth date

	-- get status IDs for system statuses 
	DECLARE @newStatusID	  int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'New') 
	DECLARE @reopenStatusID   int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Reopen') 
	DECLARE @pendingStatusID int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Pending')
	DECLARE @workingStatusID int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Working')
	DECLARE @completeStatusID int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Complete')
	DECLARE @resolvedStatusID int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Resolved')
	
	
	
	 
-- *****************************************************************************************************

select
			MonthlySummaryRecordID = msr.MonthlySummaryRecordID
			, Variance = msr.Variance
			, PaymentError = msr.PaymentError
			, BaseCapitationAmount	= msr.BaseCapitationAmount
			, PatientPayAmountN		= msr.PatientPayAmountN
			, PatientPayAmountSCO	= msr.PatientPayAmountSCO
			, PaidCapitationAmount	= msr.PaidCapitationAmount
	

			, CCARateCellID         = msr.CCARateCellID
			, CCARegionID 			= msr.CCARegionID 			
			, CCAPatientPay 		= msr.CCAPatientPay 		
			, CCAPatientSpendDown 	= msr.CCAPatientSpendDown 	

			-- CCA's expected based on current member's rate cell and region in MP
			, CCARateCardID         = msr.CCARateCardID         
			, CCAAmount 			= msr.CCAAmount 			
			, CCANetAmount 			= msr.CCANetAmount 			
		
			, MMISRateCellID        = msr.MMISRateCellID      
			, MMISRegionID 			= msr.MMISRegionID 			
			, MMISPatientPay 		= msr.MMISPatientPay 		
			, MMISPatientSpendDown 	= msr.MMISPatientSpendDown
	
			-- expected payment based on state's rate rate cell and region
			, MMISRateCardID        = msr.MMISRateCardID        
			, MMISAmount 			= msr.MMISAmount 			
			, MMISNetAmount 		= msr.MMISNetAmount 		

			, TypeRateCell          = case when isnull(msr.CCARateCellID, 0) <> isnull(msr.MMISRateCellID , 0) or isnull(msr.rawCCARateCell, '99') <> isnull(msr.rawMMISRateCell, '99') then 1 else 0 end  
			, TypeRegion 			= case when isnull(msr.CCARegionID  , 0) <> isnull(msr.MMISRegionID   , 0) or isnull(msr.rawCCARegion, 'NA')   <> isnull(msr.rawMMISRegion, 'NA') then 1 else 0 end 
			, TypePatientPay 		= case when isnull(msr.CCAPatientPay      , 0.00) <> isnull(msr.MMISPatientPay      , 0.00) then 1 else 0 end 
			, TypePatientSpendDown 	= case when isnull(msr.CCAPatientSpendDown, 0.00) <> isnull(msr.MMISPatientSpendDown, 0.00) then 1 else 0 end 

			/*
			-- this relates to be the actual values, both CCA and MMIS keys and amounts
			, TypeRateCell          = case when msr.CCARateCellID <> msr.MMISRateCellID then 1 else 0 end 
			, TypeRegion 			= case when msr.CCARegionID <> msr.MMISRegionID then 1 else 0 end 
			, TypePatientPay 		= case when msr.CCAPatientPay <> msr.MMISPatientPay then 1 else 0 end 
			, TypePatientSpendDown 	= case when msr.CCAPatientSpendDown <> msr.MMISPatientSpendDown then 1 else 0 end 
			*/
			, TypePaymentError 		= case when isnull(msr.PaymentError, 0.00) <> 0.00 then 1 else 0 end 

			, rawMMISRateCell = msr.rawMMISRateCell 
			, rawMMISRegion   = msr.rawMMISRegion   
			, rawCCARateCell  = msr.rawCCARateCell  
			, rawCCARegion    = msr.rawCCARegion    

			-- status columns
			, DiscrepancyStatusID 	= case 
				-- reopen when 'resolved'... reopening working will have to be reconsidered
				when (isnull(msr.Variance,0.00) <> 0.00 or isnull(msr.PaymentError, 0.00) <> 0.00) and DiscrepancyStatusID in (@resolvedStatusID)
					then @reopenStatusID
				-- mark 'resolved' when variance/payment error is $0.00 
				when (isnull(msr.Variance,0.00) = 0.00 and isnull(msr.PaymentError, 0.00) = 0.00) and DiscrepancyStatusID <> @resolvedStatusID
					then @resolvedStatusID
				else DiscrepancyStatusID
				end
																												 
			, ResolvedDate          = case 
				-- reopen when 'working' or 'resolved'
				when (isnull(msr.Variance,0.00) <> 0.00 or isnull(msr.PaymentError, 0.00) <> 0.00) and DiscrepancyStatusID in (@resolvedStatusID)
					then @spStart 
				-- mark 'resolved' when variance/payment error is $0.00 
				when (isnull(msr.Variance,0.00) = 0.00 and isnull(msr.PaymentError, 0.00) = 0.00) and DiscrepancyStatusID <> @resolvedStatusID
					then cast(NULL as date)
				else ResolvedDate
			end 
			, Balanced              = case 
				-- mark "un"balanced when reopening
				when (isnull(msr.Variance,0.00) <> 0.00 or isnull(msr.PaymentError, 0.00) <> 0.00) and DiscrepancyStatusID in (@resolvedStatusID)
					then 0 
				-- mark balanced when resolved
				when (isnull(msr.Variance,0.00) = 0.00 and isnull(msr.PaymentError, 0.00) = 0.00) and DiscrepancyStatusID <> @resolvedStatusID
					then 1
				else Balanced
			end
			, updateDate = @spStart 
			
	
			, case when  isnull(d.rawMMISRateCell , '') <> msr.rawMMISRateCell then 1 else 0 end as matchRaw_MMISRateCell
			, case when  isnull(d.rawMMISRegion   , '') <> msr.rawMMISRegion   then 1 else 0 end as matchRaw_MMISRegion  
			, case when  isnull(d.rawCCARateCell  , '') <> msr.rawCCARateCell  then 1 else 0 end as matchRaw_CCARateCell 
			, case when  isnull(d.rawCCARegion    , '') <> msr.rawCCARegion    then 1 else 0 end as matchRaw_CCARegion   
	
	from Discrepancies as d
	inner join MonthlySummaryRecord as msr 
		on msr.MasterPatientID = d.MasterPatientID 
		and msr.MemberMonth = d.MemberMonth
	-- where d.DiscrepancyStatusID <> @resolvedStatusID
	-- condition to avoid updating all discrepancies



/*
	where (
			   d.Variance               <> msr.Variance
			or d.PaymentError           <> msr.PaymentError
			or d.BaseCapitationAmount	<> msr.BaseCapitationAmount
			or d.PatientPayAmountN		<> msr.PatientPayAmountN
			or d.PatientPayAmountSCO	<> msr.PatientPayAmountSCO
			or d.PaidCapitationAmount	<> msr.PaidCapitationAmount
	

			or d.CCARateCellID          <> msr.CCARateCellID
			or d.CCARegionID 			<> msr.CCARegionID 			
			or d.CCAPatientPay 		    <> msr.CCAPatientPay 		
			or d.CCAPatientSpendDown 	<> msr.CCAPatientSpendDown 	

			-- CCA's expected based on current member's rate cell and region in MP
			or d.CCARateCardID          <> msr.CCARateCardID         
			or d.CCAAmount 			    <> msr.CCAAmount 			
			or d.CCANetAmount 			<> msr.CCANetAmount 			
		
			or d.MMISRateCellID         <> msr.MMISRateCellID      
			or d.MMISRegionID 			<> msr.MMISRegionID 			
			or d.MMISPatientPay 		<> msr.MMISPatientPay 		
			or d.MMISPatientSpendDown 	<> msr.MMISPatientSpendDown

			-- *************************************************
			-- can we leave this out of the update?
			or d.TypeRateCell           <> case when isnull(msr.CCARateCellID, 0) <> isnull(msr.MMISRateCellID , 0) or isnull(msr.rawCCARateCell, '99') <> isnull(msr.rawMMISRateCell, '99') then 1 else 0 end  
			or d.TypeRegion 			<> case when isnull(msr.CCARegionID  , 0) <> isnull(msr.MMISRegionID   , 0) or isnull(msr.rawCCARegion, 'NA')   <> isnull(msr.rawMMISRegion, 'NA') then 1 else 0 end 
			or d.TypePatientPay 		<> case when isnull(msr.CCAPatientPay      , 0.00) <> isnull(msr.MMISPatientPay      , 0.00) then 1 else 0 end 
			or d.TypePatientSpendDown 	<> case when isnull(msr.CCAPatientSpendDown, 0.00) <> isnull(msr.MMISPatientSpendDown, 0.00) then 1 else 0 end 
			or d.TypePaymentError 		<> case when isnull(msr.PaymentError, 0.00) <> 0.00 then 1 else 0 end 
			-- *************************************************

			
			-- Will not update on raw matches.  should only be necessary if another element is changed.

			or d.rawMMISRateCell <> msr.rawMMISRateCell 
			or d.rawMMISRegion   <> msr.rawMMISRegion   
			or d.rawCCARateCell  <> msr.rawCCARateCell  
			or d.rawCCARegion    <> msr.rawCCARegion    
	)
*/

	and msr.mmis_id = '100015228818' -- '100005437941'



select * from ExecutionLog 
-- where job = '[dbo].[spProcessMonthly]'
order by StartTime desc, ExecutionLogID

/*
-- removve all discrepancies with memberMonth before 2018
delete from Discrepancies		   where MemberMonth < '2018-01-01'
delete from DiscrepanciesHistory where MemberMonth < '2018-01-01'
*/
