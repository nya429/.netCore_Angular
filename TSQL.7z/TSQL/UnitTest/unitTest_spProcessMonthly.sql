
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMonthly] 
PRINT @returnValue 

select * from ExecutionLog order by starttime desc, endtime desc

-- *****************************************************************************************************
