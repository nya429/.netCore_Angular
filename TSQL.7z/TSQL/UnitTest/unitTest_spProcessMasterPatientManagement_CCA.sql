
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMasterPatientManagement_CCA] 
PRINT @returnValue 

select * from MasterPatientManagement
where insertDate > '2019-10-05'

select * from ExecutionLog order by ExecutionLogID desc

-- *****************************************************************************************************
