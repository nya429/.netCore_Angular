
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetUsers] 
PRINT @returnValue 

select * from users

EXEC [dbo].[spGetUsers] NULL, 'son'
EXEC [dbo].[spGetUsers] 1


EXEC [dbo].[spGetUsers] NULL, 'lewis'

EXEC [dbo].[spGetUsers] NULL, NULL, 1, 3 
EXEC [dbo].[spGetUsers] NULL, NULL, 2, 3 

EXEC [dbo].[spGetUsers] NULL, NULL, 0, 25, 'UserLastName' 
EXEC [dbo].[spGetUsers] NULL, NULL, 0, 25, 'garbage' -- uses default sort

-- *****************************************************************************************************
