
USE [RevRec]
GO



-- *****************************************************************************************************
-- Test Execution Block;

EXEC [dbo].[spGetRateCellMap] -- expected: entire list

EXEC [dbo].[spGetRateCellMap] 2, 'I2D', 'I2D2', 'SCO' -- expected: 1 match
EXEC [dbo].[spGetRateCellMap] 2, 'I2D', NULL, NULL  -- expected: two mappings
EXEC [dbo].[spGetRateCellMap] 2, NULL, 'I2D2', NULL -- expected: 1 match
EXEC [dbo].[spGetRateCellMap] 2, NULL, NULL, 'SCO' -- expected: all Items for 'SCO'
 							  
EXEC [dbo].[spGetRateCellMap] 2, 'I2D', 'I2D2', 'ICO' -- execpted: no matches (ICO filter prevents SCO lookup)
EXEC [dbo].[spGetRateCellMap] 2, NULL, NULL, 'ICO' -- expected: all items for 'ICO'

-- lookup via parameter names
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetRateCellMap] 

	--   @eventUserID int = NULL
	  @CCARateCell  = NULL -- 'I2D'
	, @MMISRateCell = NULL -- 'I2D2'
	, @Product      = NULL -- 'ICO' -- 'SCO'

	, @pageIndex    = 1
	, @pageSize     = 25
	, @sortBy       = 'RateCellMapID' 
	, @orderBy      = 1 -- 0: ASC; 1: DESC

PRINT @returnValue 


-- lookup via parameter names
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetRateCellMap] 

	--   @eventUserID int = NULL
	  @CCARateCell  = NULL -- 'I2D'
	, @MMISRateCell = NULL -- 'I2D2'
	, @Product      = NULL -- 'ICO' -- 'SCO'

	, @pageIndex    = 0
	, @pageSize     = 25
	, @sortBy       = NULL -- 'RateCellMapID' 
	, @orderBy      = 1 -- 0: ASC; 1: DESC

PRINT @returnValue 


exec [dbo].[spGetRateCellMap] @sortBy = 'MMISRateCell',  @orderBy = 0
exec [dbo].[spGetRateCellMap] @sortBy = 'garbage',  @orderBy = 0


-- from postman:
exec sp_executesql N'dbo.spGetRateCellMap @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7
',N'@p0 int,@p1 nvarchar(4000),@p2 nvarchar(4000),@p3 nvarchar(4000),@p4 int,@p5 int,@p6 nvarchar(4000),@p7 int',@p0=1,@p1=N'',@p2=N'',@p3=N'',@p4=0,@p5=25,@p6=N'',@p7=1


-- *****************************************************************************************************
