
USE [RevRec]
GO

-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spCreateRateCard] 
PRINT @returnValue 

DECLARE @returnValue as INT, @NewID int, @RetCd int
	
EXEC @returnValue = [dbo].[spCreateRateCard] 
	  @eventUserID    = 2 
	, @CCARateCellID  = 14
	, @CCARegionID    = 5
	, @Amount         = 648.62
	, @StartDate      = '2023-01-01' 
	, @EndDate        = '2023-06-30'
	-- , @RateCardLabel  = NULL 
	, @Product = 'SCO'
	, @ActiveFlag = 1 -- default to 1 for active

	, @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output

PRINT @returnValue 
PRINT @NewID 
PRINT @RetCd  

select * from vwRateCard order by RateCardID desc
select * from ratecard   order by RateCardID desc
exec spGetRateCard

select * from ExecutionLog order by ExecutionLogID desc
select * from UserEventLog order by EventID desc

-- *****************************************************************************************************
