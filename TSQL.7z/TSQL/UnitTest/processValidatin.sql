use RevRec

select insertDate, count(*) as countByInsertDate 
from PaymentDetailPaid 
group by insertDate 
order by insertDate desc


select top 100 * from PaymentDetailPaid where insertDate
 = '2019-10-04 11:28:48.100'
 and CapitationMonthYear < '2018-07-01'


select * from ExecutionLog order by StartTime desc, ExecutionLogID desc -- , EndTime desc


select * from MasterPatientManagement where ccaid is not null
select * from MMISMemberData

select * from RateCard

select Top 100 * from MonthlySummaryRecord
select top 100 * from discrepancies

select * from discrepancies where discrepancyid = 94
select * from discrepancieshistory where discrepancyid = 94 order by discrepancyhistoryID desc



