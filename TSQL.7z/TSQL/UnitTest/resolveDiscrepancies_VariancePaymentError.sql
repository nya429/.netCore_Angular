use RevRec

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	

	-- SELECT * FROM DiscrepancyStatuses
	-- SELECT * FROM DiscrepancyCategories

	DECLARE @processMonth date

	-- get status IDs for system statuses 
	DECLARE @newStatusID	  int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'New') 
	DECLARE @reopenStatusID   int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Reopen') 
	DECLARE @pendingStatusID int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Pending')
	DECLARE @workingStatusID int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Working')
	DECLARE @completeStatusID int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Complete')
	DECLARE @resolvedStatusID int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Resolved')
	
	
	
	 
-- *****************************************************************************************************


	select 
		  msr.MonthlySummaryRecordID
		, msr.MasterPatientID 
		, msr.MemberMonth 

		, msr.Variance 
	
		-- Payment error SHOULD NOT be part of the variance calculation
		, msr.PaymentError 

		-- from PatientPayDetail... what the state actually says they paid, based on file
		, msr.BaseCapitationAmount	
		, msr.PatientPayAmountN		
		, msr.PatientPayAmountSCO	
		, msr.PaidCapitationAmount	
	

		, msr.CCARateCellID 
		, msr.CCARegionID 
		, msr.CCAPatientPay 
		, msr.CCAPatientSpendDown 

		-- CCA's expected based on current member's rate cell and region in MP
		, msr.CCARateCardID 
		, msr.CCAAmount 
		, msr.CCANetAmount 
		
		, msr.MMISRateCellID 
		, msr.MMISRegionID 
		, msr.MMISPatientPay 
		, msr.MMISPatientSpendDown 
	
		-- expected payment based on state's rate rate cell and region
		, msr.MMISRateCardID 
		, msr.MMISAmount 
		, msr.MMISNetAmount 

		-- this relates to be the actual values, both CCA and MMIS keys and amounts
		, case when isnull(msr.CCARateCellID, 0) <> isnull(msr.MMISRateCellID , 0) and isnull(msr.rawCCARateCell, '99') <> isnull(msr.rawMMISRateCell, '99') then 1 else 0 end as TypeRateCell 
		, case when isnull(msr.CCARegionID  , 0) <> isnull(msr.MMISRegionID   , 0) and isnull(msr.rawCCARegion, 'NA')   <> isnull(msr.rawMMISRegion, 'NA') then 1 else 0 end as TypeRegion 
		, case when isnull(msr.CCAPatientPay      , 0.00) <> isnull(msr.MMISPatientPay      , 0.00) then 1 else 0 end as TypePatientPay 
		, case when isnull(msr.CCAPatientSpendDown, 0.00) <> isnull(msr.MMISPatientSpendDown, 0.00) then 1 else 0 end as TypePatientSpendDown 
		, case when isnull(msr.PaymentError, 0.00) <> 0.00 then 1 else 0 end as TypePaymentError 

		-- status columns
		, NULL AS Assigned_UserID 
		, NULL AS Action_UserID 
		, @newStatusID as DiscrepancyStatusID 
		, NULL AS DueDate 
		, @spStart AS DiscoverDate -- will match insert date, unless re-opened, then will reflect the initial re-open date; will use for aging
		, NULL AS ResolvedDate -- only when a designated resolved system status/balanced bit is used; re-open, this date is cleared
		, NULL AS Balanced -- will consider this for system marking complete/resolved 

		, 1 as ActiveFlag
		, @spStart as insertDate
		, @spStart as updateDate

		-- debug:
		, isnull(msr.CCARateCellID, 0)      
		, isnull(msr.MMISRateCellID , 0) 
		, isnull(msr.rawCCARateCell, '99') 
		, isnull(msr.rawMMISRateCell, '99') 
		, isnull(msr.CCARegionID  , 0) 
		, isnull(msr.MMISRegionID   , 0) 
		, isnull(msr.rawCCARegion, 'NA')   
		, isnull(msr.rawMMISRegion, 'NA') 


	-- select * from PatientPayDetail
	from MonthlySummaryRecord as msr
	where (
			(msr.Variance is not null and msr.Variance <> 0.00)
			or (msr.PaymentError is not null and msr.PaymentError <> 0.00)
		)

-- 		and not exists (
-- 			select DiscrepancyID 
-- 			from Discrepancies as d
-- 			where d.MasterPatientID = msr.MasterPatientID
-- 				and d.MemberMonth = msr.MemberMonth
-- 		)
		-- FOR TESTING
		-- and msr.CCARateCellID is not null

	-- and msr.mmis_id = '100005437941' -- success
	-- and msr.mmis_id = '100028157103' -- no expected rate cell discrepancy
	-- and msr.mmis_id = '100007439217'  
	-- and msr.mmis_id = '100000593457' -- expect rate cell match, but not region match
	and msr.mmis_id = '100008100255' -- expect variance
	


	select * from Discrepancies where MasterPatientID = 7747
	

	/*
	select insertdate, count(*) as countByInsertDate from Discrepancies group by insertdate order by insertdate
	select updatedate, count(*) as countByupdatedate from Discrepancies group by updatedate order by updatedate


	select * from vwMemberMap where mmis_mmis_id = '100005437941' -- success
	select * from vwMemberMap where mmis_mmis_id = '100007439217'
	
	-- why aren't their rating categories showing?
	select * from vwccaMemberData
	where ccaid in (
		5364521215
		, 5364522234
	)
	order by ccaid

	select * from CCAMemberSpanEnrollment


*/