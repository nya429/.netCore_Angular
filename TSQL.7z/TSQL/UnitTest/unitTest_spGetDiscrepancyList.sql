
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyList] 
	@MasterPatientID = 49717 -- 16439 
PRINT @returnValue 


-- setup to test bulk
select * from discrepancies where masterpatientid = 16439 
update discrepancies set Assigned_UserID = 1 where DiscrepancyID between 1 and 1000
update discrepancies set Assigned_UserID = 2 where DiscrepancyID between 1001 and 2000
update discrepancies set Assigned_UserID = 3 where DiscrepancyID between 2001 and 3000

declare @SendAssigneeIDs as dbo.BulkID
insert into @SendAssigneeIDs (
	updateID
)
values (1)
, (2)


EXEC [dbo].[spGetDiscrepancyList]
	@AssigneeIDs = @SendAssigneeIDs 

EXEC [dbo].[spGetDiscrepancyList]
	@CCARateCellIDs = @SendAssigneeIDs 

EXEC [dbo].[spGetDiscrepancyList]
	@DiscrepancyStatusIDs = @SendAssigneeIDs 


EXEC [dbo].[spGetDiscrepancyList]
	  @eventUserID = NULL
	, @name					  = NULL
	, @CCAID				  = NULL
	, @MMIS_ID				  = NULL
	, @MasterPatientID		  = NULL
	-- , @Months				  
	-- , @Programs				  
	-- , @CCARateCellIDs		  
	-- , @DiscrepancyStatusIDs	  
	-- , @AssigneeIDs            
	, @hasComment			  = 1 -- NULL -- 0: No; 1: Yes
	, @discoverDateStart	  = '2019-09-05'
	, @discoverDateEnd		  = '2019-09-30'
	, @resolutionDateStart	  = NULL
	, @resolutionDateEnd	  = NULL
	, @includeResolved        = 0 -- 0: No; 1: Yes


	, @pageIndex int		  = 0
	, @pageSize int			  = 25
	, @sortBy varchar(50)	  = 'Variance' 
	, @orderBy int            = 1 -- 0: ASC; 1: DESC
	
	
		    
EXEC [dbo].[spGetDiscrepancyList]
	@name = 'mar da'


declare @SendPrograms as dbo.BulkString
insert into @SendPrograms (
	updateString
)
values ('SCO')
, ('ICO')

EXEC [dbo].[spGetDiscrepancyList]
	@Programs = @SendPrograms


declare @SendMonths as dbo.BulkDate
insert into @SendMonths  (
	updateDate
)
values ('2019-05-01')
, ('2019-03-01')

EXEC [dbo].[spGetDiscrepancyList]
	@Months = @SendMonths



declare @SendDisc as dbo.BulkID
insert into @SendDisc  (
	updateID
)
values (9) -- 'No Active MDS'


	
EXEC [dbo].[spGetDiscrepancyList]
	@name = 'felix'
	, @pagesize = 50
	, @DiscrepancyStatusIDs = @SendDisc 

-- where are the discrepancies: 100015217589

select * from DiscrepanciesComments where discrepancyID = 666

EXEC [dbo].[spGetDiscrepancyList]
@hasComment			  = 0 -- NULL -- 0: No; 1: Yes

-- *****************************************************************************************************
