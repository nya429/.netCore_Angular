
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMMISRegions] 
PRINT @returnValue 

-- validate results:
select * from MMISRegions
select * from vwMMISRegions
select * from ExecutionLog order by startTime desc, endTime desc

-- *****************************************************************************************************
