
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMMISMemberData] 
PRINT @returnValue 



-- SEARCH BY NAME
EXEC [dbo].[spGetMMISMemberData] 
	  @searchName = 'JACO'
	, @searchMMIS_ID = NULL

-- SEARCH BY MMIS
EXEC [dbo].[spGetMMISMemberData] 
	  @searchName = NULL
	, @searchMMIS_ID = '100009285841'

-- SEARCH BY ALL
EXEC [dbo].[spGetMMISMemberData] 
	  @searchName = 'JACO'
	, @searchMMIS_ID = 100004633961


-- *****************************************************************************************************
