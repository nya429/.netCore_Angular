
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMMISRegions] 
PRINT @returnValue 


EXEC [dbo].[spGetMMISRegions] 2, 'c0'   , NULL
EXEC [dbo].[spGetMMISRegions] 2, '01'   , NULL
EXEC [dbo].[spGetMMISRegions] 2, 'C009' , NULL

EXEC [dbo].[spGetMMISRegions] 2, 'c0'   , 'ICO'
EXEC [dbo].[spGetMMISRegions] 2, '01'   , 'ICO'
EXEC [dbo].[spGetMMISRegions] 2, 'C009' , 'ICO'

EXEC [dbo].[spGetMMISRegions] 2, 'c0'   , 'SCO'
EXEC [dbo].[spGetMMISRegions] 2, '01'   , 'SCO'
EXEC [dbo].[spGetMMISRegions] 2, 'C009' , 'SCO'

EXEC [dbo].[spGetMMISRegions] 2, NULL   , 'ICO'
EXEC [dbo].[spGetMMISRegions] 2, NULL	 , 'SCO'

EXEC [dbo].[spGetMMISRegions] NULL, NULL, NULL, 1, 5
EXEC [dbo].[spGetMMISRegions] NULL, NULL, NULL, 2, 5
EXEC [dbo].[spGetMMISRegions] NULL, NULL, NULL, 3, 5

-- *****************************************************************************************************
