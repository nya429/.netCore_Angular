
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spCreateUser] 
PRINT @returnValue 

-- reset tests:
delete from users where usernamead = 'jbrown'
delete from userrolemap where userid > 9


-- Full Example Test
DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spCreateUser] 
	  @eventUserID = 2 

	, @UserNameAD = 'jbrown'
	, @UserEmail = 'jbrown@celtics.com'
	, @UserFirstName = 'Jaylen'
	, @UserLastName = 'Brown'

	, @RoleAdministrator = 0
	, @RoleHelpdesk = 1
	, @RoleSupervisor = 0
	, @RoleSpecialist = 1

	, @ActiveFlag = 1 

	, @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @NewID
PRINT @RetCd


-- Confirm data tables updated appropriately

SELECT * FROM UserRoles
SELECT * FROM Users
SELECT * FROM UserRoleMap

select * from ExecutionLog order by ExecutionLogID desc
select * from UserEventLog order by EventID desc

-- *****************************************************************************************************
