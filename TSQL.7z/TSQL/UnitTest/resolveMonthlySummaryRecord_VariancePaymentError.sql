use RevRec

	select 
		mpm.MasterPatientID as MasterPatientID
		, isnull(pd.CapitationMonthYear, ep.MasterMemberMonth) as MemberMonth
		-- , pd.MemberID as MMIS_ID
		, mpm.MMIS_ID as MMIS_ID



		, statePaidCalc = (pd.Paid + isnull(pd.PatientPay,0.00) + isnull(pd.SpendDown,0.00))
		, pd.PatientPay
		, pd.SpendDown
			-- - (pd.BaseCapitationAmount - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00)) as Variance -- altered this to reflect variance in paid, not base capitation amount
		, ccaPaidCalc = isnull(
			(ep.Amount - case when ep.PatientPay like '%[0-9].[0-9][0-9]' then cast(ep.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when ep.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(ep.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end)
			, 0.00)  

		, ccaPaidCalc = isnull(
			(ep.Amount - case when ep.PatientPay like '%[0-9].[0-9][0-9]' then cast(ep.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when ep.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(ep.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end)
			, 0.00)  




		-- conversion for varchar > numeric errors
		, (
			-- substract 0 when no rate card amount
			pd.Paid
			-- - (pd.BaseCapitationAmount - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00)) as Variance -- altered this to reflect variance in paid, not base capitation amount
			- isnull(
			(ep.Amount - case when ep.PatientPay like '%[0-9].[0-9][0-9]' then cast(ep.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when ep.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(ep.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end)
			, 0.00)  
		) as Variance 
		-- , (pd.BaseCapitationAmount - pd.Amount) as PaymentError  -- Payment error SHOULD NOT be part of the variance calculation... should consider patient pay and spend down
		, (pd.Paid + isnull(pd.PatientPay,0.00) + isnull(pd.SpendDown,0.00)) - coalesce(pd.Amount, pd.BaseCapitationAmount,0.00) as PaymentError  -- Payment error SHOULD NOT be part of the variance calculation; altered this to reflect actual paid vs base amount
		, coalesce(pd.Amount, pd.BaseCapitationAmount,0.00) - (pd.Paid + isnull(pd.PatientPay,0.00) + isnull(pd.SpendDown,0.00)) as PaymentError_Reverse  -- Payment error SHOULD NOT be part of the variance calculation; altered this to reflect actual paid vs base amount
		/*
		-- option B: 
		, CASE WHEN pd.Amount IS NULL 
			THEN 0.00 ELSE 
			(
			isnull(
			(pd.Paid + isnull(pd.PatientPay,0.00) + isnull(pd.SpendDown,0.00)) - pd.Amount
			,0.00)
		) END as PaymentError  -- Payment error SHOULD NOT be part of the variance calculation; altered this to reflect actual paid vs base amount
		*/
		-- from PatientPayDetail... what the state actually says they paid, based on file
		, pd.BaseCapitationAmount as BaseCapitationAmount	
		, pd.PatientPay as PatientPayAmountN		
		, pd.SpendDown as PatientPayAmountSCO	
		, pd.Paid as PaidCapitationAmount
		, pd.Remit	
	

		, ep.CCARateCellID as CCARateCellID 
		, ep.CCARegionID as CCARegionID 
		-- conversion for varchar > numeric errors
		, case when ep.PatientPay like '%[0-9].[0-9][0-9]' then cast(ep.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end as CCAPatientPay 
		, case when ep.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(ep.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end as CCAPatientSpendDown 


		-- CCA's expected based on current member's rate cell and region in MP
		, ep.RateCardID as CCARateCardID 
		, ep.Amount as CCAAmount 

		-- conversion for varchar > numeric errors
		, (isnull(ep.Amount,0.00) - case when ep.PatientPay like '%[0-9].[0-9][0-9]' then cast(ep.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when ep.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(ep.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end) as CCANetAmount 
		
		, pd.CCARateCellID as MMISRateCellID 
		, pd.CCARegionID as MMISRegionID 
		, pd.PatientPay as MMISPatientPay 
		, pd.SpendDown as MMISPatientSpendDown 
	
		-- expected payment based on state's rate rate cell and region
		, pd.RateCardID as MMISRateCardID 
		, pd.Amount as MMISAmount 
		, (isnull(pd.Amount,0.00) - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00))  as MMISNetAmount 

		-- include these for null rate card matches later
		, pd.RateCell as rawMMISRateCell
		, pd.MCRegion as rawMMISRegion

		, case when ep.Product = 'SCO' then left(ep.RatingCategory, 3) else ep.RatingCategory end	as rawCCARateCell
		, ep.Region			as rawCCARegion


	-- select mpm.*, md.MemberMonth -- select count(*)
	from MasterPatientManagement as mpm
	-- get member months for all members
	inner join (
		-- pre-build this list for performance: total rows: 716299
		select mpm.MasterPatientID, pd.CapitationMonthYear as MemberMonth 
		from MasterPatientManagement as mpm
		inner join PaymentDetail as pd on pd.MemberID = mpm.MMIS_ID -- 683164
		-- where pd.rnCurrentPaidAmount = 1 -- staging takes care of this
		union 
		select mpm.MasterPatientID, ep.MasterMemberMonth as MemberMonth 
		from MasterPatientManagement as mpm
		inner join ExpectedPayments as ep on ep.MMIS_ID = mpm.MMIS_ID -- 618614
		union 
		select mpm.MasterPatientID, ep.MasterMemberMonth as MemberMonth 
		from MasterPatientManagement as mpm
		inner join ExpectedPayments as ep on ep.CCAID = mpm.CCAID -- 195... but expected payment is not missing MMIS_ID on any
	) md on md.MasterPatientID = mpm.MasterPatientID
	full outer join ExpectedPayments as ep 
		on (
			ep.MMIS_ID = mpm.MMIS_ID
			-- May need this in the future, but causes huge performance issue and is not needed for any matches right now
			-- or (ep.MMIS_ID is null
			-- 	and ep.CCAID = mpm.CCAID 
			-- )
		)
		and ep.MasterMemberMonth = md.MemberMonth 
	full outer join PaymentDetail as pd -- do we get the rate card here and call it a day?
		on pd.MemberID = mpm.MMIS_ID 
		and pd.CapitationMonthYear = md.MemberMonth 
		-- and pd.rnCurrentPaidAmount = 1 -- staging takes care of this
	where mpm.MMIS_ID in (
	
		-- '100011586541'
		 '100028157103'

	) 
	order by MMIS_ID, MemberMonth 
	
	-- MMIS_ID	100028157103
	-- MemberMonth 2018-01-01

/*
-- select * from MonthlySummaryRecord where PaymentError <> 0
select * from MasterPatientManagement where MasterPatientID = 30367
select * from vwMemberMap where MasterPatientID = 30367
select * from CCAMemberSpanEnrollment where CCAID = 5365552016 -- 2012-10-01	2018-11-30

select insertDate, count(*) as countByInsertDate 
from vwMemberMap
group by insertDate
order by insertDate


*/

-- CND 6/18 - 11/18
select * from pdrin.[dbo].[MMIS8200MDetail]
where memberid = '100028157103'
and CapitationMonthYear >= '2018-01-01'
order by CapitationMonthYear
, PaymentPeriodEnd



select * from PaymentDetail where memberid = '100028157103'
order by CapitationMonthYear
select * from PaymentDetailPaid where memberid = '100028157103'
order by CapitationMonthYear

select * from MonthlySummaryRecord where mmis_id = '100028157103'
order by CapitationMonthYear



select * from pdrin.[dbo].[MMIS8200MDetail]
where memberid = '100028157103'
and CapitationMonthYear >= '2018-01-01'
and RunDateTime = '2019-06-13 11:08:52.000'
order by CapitationMonthYear
, PaymentPeriodEnd


-- 263200
select count(*) from pdrin.[dbo].[MMIS8200MDetail]
where RunDateTime = '2019-06-13 11:08:52.000'
