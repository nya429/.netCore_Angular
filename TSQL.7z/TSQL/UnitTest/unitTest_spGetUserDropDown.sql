
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetUserDropDown] 
PRINT @returnValue 

-- *****************************************************************************************************
