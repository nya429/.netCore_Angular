
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spCreateDiscrepancyStatus] 
PRINT @returnValue 

-- new test
-- Full Example Test
DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spCreateDiscrepancyStatus] 
	  @eventUserID = 2 
	, @DiscrepancyCategoryID = 7
	, @DiscrepancyStatus = 'Homer Simpson' 
	, @DiscrepancyStatusDescription = 'all work and no play makes... something, something'
	, @ActiveFlag = 1 

	, @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @NewID
PRINT @RetCd

-- Confirm data tables updated appropriately
select * from DiscrepancyStatuses
select * from ExecutionLog order by ExecutionLogID desc
select * from UserEventLog order by EventID desc
-- *****************************************************************************************************
