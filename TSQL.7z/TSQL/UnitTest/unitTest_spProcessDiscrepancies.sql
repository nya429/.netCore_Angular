﻿USE RevRec
GO

-- *******************************************************
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessDiscrepancies] 
PRINT @returnValue 


SELECT * FROM [dbo].[Discrepancies]
-- where CCAPatientPay	is not NULL or CCAPatientSpendDown is not NULL
select * from executionLog order by executionLogID DESC

-- validate singular results
select MasterPatientID, MemberMonth, count(*) as dupCheck 
from Discrepancies 
where insertdate > '2019-09-25'
group by MasterPatientID, MemberMonth having count(*) > 1 
order by dupCheck desc, MasterPatientID

select * 
from discrepancies
where MasterPatientID	= 3029	
and MemberMonth = '2019-06-01'

select * 
from MonthlySummaryRecord
where MasterPatientID	= 3029	
and MemberMonth = '2019-06-01'

delete from discrepancies where insertdate > '2019-09-24'
-- *******************************************************

-- *******************************************************
-- Unit test 1. reopen status, based on variance
-- *******************************************************

SELECT TOP 10 * FROM MonthlySummaryRecord 
SELECT TOP 10 * FROM Discrepancies -- 4

select * from DiscrepancyStatuses
SELECT * FROM Discrepancies WHERE discrepancyid = 4
SELECT * FROM DiscrepanciesHistory WHERE discrepancyid = 4 ORDER BY DiscrepancyHistoryID DESC


UPDATE Discrepancies 
SET DiscrepancyStatusID = 2
, variance = 0.00
, PaymentError = 0.00
where DiscrepancyID = 4


exec spProcessDiscrepancies


-- *******************************************************
-- Unit test 2. resolved based on rate card change in MP
-- *******************************************************

SELECT TOP 10 * FROM MonthlySummaryRecord 
SELECT TOP 10 * FROM Discrepancies -- 4
select top 100 * from ExpectedPayments


SELECT TOP 10 * FROM MonthlySummaryRecord 
where MasterPatientID = 17720	
	and MemberMonth = '2018-01-01'

select * from Discrepancies 
where MasterPatientID = 17720	
	and MemberMonth = '2018-01-01'


select top 100 * from ExpectedPayments
where MMIS_ID = '100013606494'
and MasterMemberMonth = '2018-01-01'



-- *******************************************************
-- Unit test 3. resolved based on rate card amount change in Rev Rec
-- *******************************************************

-- *******************************************************
-- Unit test 4. bad bubbles
-- *******************************************************

select MSR.MMIS_ID, MSR.PaymentError, MSR.Variance, D.* 
from Discrepancies as d
inner join MonthlySummaryRecord as msr on msr.MasterPatientID = d.MasterPatientID
where 
    d.TypeRateCell	            = 0
and d.TypeRegion			    = 0
and d.TypePatientPay		    = 0
and d.TypePatientSpendDown	= 0  
and d.TypePaymentError	    = 0
and (
	-- MSR.Variance <> 0.00	
	-- or 
	MSR.PaymentError <> 0.00
)


-- *******************************************************
-- Unit test 5. multi member month discrepancies
-- *******************************************************

select * fr

