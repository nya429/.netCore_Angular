
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetUnmappedMMISRateCellCount] 
PRINT @returnValue 

exec spGetMMISRateCells -- has a flag for unmapped... why can't this be used, or is it used?

select * from ratecellmap 
update ratecellmap 
set ccaratecellid = NULL
where ratecellmapid in (10, 11, 12)
-- *****************************************************************************************************
