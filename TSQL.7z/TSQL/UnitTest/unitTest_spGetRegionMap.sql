
USE [RevRec]
GO



-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetRegionMap] 
PRINT @returnValue 


EXEC [dbo].[spGetRegionMap] 

EXEC [dbo].[spGetRegionMap] 2, 'ICO', 'West', 'C011'
EXEC [dbo].[spGetRegionMap] 2, NULL, 'West',   NULL
EXEC [dbo].[spGetRegionMap] 2, NULL,  NULL , 'C011'
EXEC [dbo].[spGetRegionMap] 2, 'ICO',  NULL ,   NULL

EXEC [dbo].[spGetRegionMap] 2, 'SCO', 'West', 'C011'
EXEC [dbo].[spGetRegionMap] 2, 'SCO', NULL, NULL



DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetRegionMap] 
	-- Add the parameters for the stored procedure here
	  @eventUserID = NULL
	, @Product     = NULL -- 'SCO' -- 'ICO' 
	, @CCARegion   = NULL -- 'West' -- 'Bos'
	, @MMISRegion  = NULL -- 'CINBN' -- 'C011'

	-- maybe move hardcoding into stored procedure, then can check for isnull values
	, @pageIndex  = 0
	, @pageSize   = 25
	, @sortBy 	  = 'RegionMapID' 
	, @orderBy    = 1 -- 0: ASC; 1: DESC
PRINT @returnValue 


exec spGetRegionMap  1,'ICO','','',0,25,'',1 

-- postman:
exec sp_executesql N'dbo.spGetRegionMap @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7
',N'@p0 int,@p1 nvarchar(4000),@p2 nvarchar(4000),@p3 nvarchar(4000),@p4 int,@p5 int,@p6 nvarchar(4000),@p7 int',@p0=1,@p1=N'',@p2=N'',@p3=N'',@p4=0,@p5=25,@p6=N'',@p7=1

-- *****************************************************************************************************
