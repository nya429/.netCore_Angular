
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyStatusDropDown] 
PRINT @returnValue 

select * from discrepancyStatuses as ds
select * from DiscrepancyCategories as dc


-- *****************************************************************************************************
