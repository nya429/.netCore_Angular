
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spCreateDiscrepancyCategories] 
PRINT @returnValue 

-- new test
-- Full Example Test
DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spCreateDiscrepancyCategories] 
	  @eventUserID = 2 
	, @DiscrepancyCategory = 'XFiles4' 
	, @DiscrepancyCategoryDescription = NULL -- 'Trust No one'
	, @ActiveFlag = 1 

	, @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @NewID
PRINT @RetCd

-- Confirm data tables updated appropriately
select * from DiscrepancyCategories
select * from ExecutionLog order by ExecutionLogID desc
select * from UserEventLog order by EventID desc

-- *****************************************************************************************************
