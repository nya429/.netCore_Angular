
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMemberList] 
PRINT @returnValue 

DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMemberList] 
	  @MasterPatientID        = NULL -- 125
	-- , @Name                   = NULL -- 'JACO'         -- unit test: confirmed... much faster now that data is staged rather than joined in realtime
	, @Name                   = 'JACO'         -- unit test: confirmed... much faster now that data is staged rather than joined in realtime
	-- , @Name                   = 'Sand Woo'
	, @CCAID                  = NULL -- 5365566023     -- unit test: confirmed
	, @MMIS_ID                = NULL -- '100009285841' -- unit test: confirmed       
	, @includeZeroDiscrepancy = 0 					   -- unit test: pending test data
	, @AssigneeID             = NULL
	, @pageIndex              = 0                      -- unit test: confirmed
	, @pageSize               = 25                     -- unit test: confirmed
	, @sortBy                 = 'absoluteVarianceSum'  -- unit test: pending test data
	, @orderBy                = 1 					   -- unit test: pending test data
PRINT @returnValue 

select * 
from MMISMemberData
where masterpatientid in (
	  27  -- 100000113132
	, 125 -- 100000150019
	, 205 -- 100000019537
	, 219 -- 100000100386
	, 502 -- 100001046661
	, 570 -- 100000976678
)


-- examples to review
EXEC [dbo].[spGetMemberList] @MasterPatientID = 1397 , @AssigneeID = 1 -- 6 0
EXEC [dbo].[spGetMemberList] @MasterPatientID = 10102, @AssigneeID = 1 -- 15 3
EXEC [dbo].[spGetMemberList] @MasterPatientID = 41074, @AssigneeID = 3 -- 6 3
EXEC [dbo].[spGetMemberList] @MasterPatientID = 51673, @AssigneeID = 2 -- 0 14

EXEC [dbo].[spGetMemberList] @AssigneeID = 1 , @mmis_id = '100012762744'-- 6 0  
EXEC [dbo].[spGetMemberList] @AssigneeID = 2 , @mmis_id = '100012762744'-- 0 14 
EXEC [dbo].[spGetMemberList] @AssigneeID = 3 , @mmis_id = '100012762744'-- 6 3	 

EXEC [dbo].[spGetMemberList] @mmis_id = '100012762744' -- 20, 19
EXEC [dbo].[spGetMemberList] @mmis_id = '100012762744', @AssigneeID = 2 -- 20, 6

EXEC [dbo].[spGetMemberList] @CCAID = 5364521807


SELECT * FROM DISCREPANCIES WHERE MASTERPATIENTID = 1397   
SELECT * FROM DISCREPANCIES WHERE MASTERPATIENTID = 10102  
SELECT * FROM DISCREPANCIES WHERE MASTERPATIENTID = 41074  
SELECT * FROM DISCREPANCIES WHERE MASTERPATIENTID = 51673  

-- *****************************************************************************************************

-- total Assigned

-- dt.TotalDiscrepancies instead of ml.TotalDiscrepancies
100013190465

