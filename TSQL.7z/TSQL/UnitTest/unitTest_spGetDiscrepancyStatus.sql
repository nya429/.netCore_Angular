
USE [RevRec]
GO

-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyStatus] 
PRINT @returnValue 

EXEC [dbo].[spGetDiscrepancyStatus] 2, 
EXEC [dbo].[spGetDiscrepancyStatus] 2, NULL, NULL, NULL
EXEC [dbo].[spGetDiscrepancyStatus] 2, 'new', 1, 1
EXEC [dbo].[spGetDiscrepancyStatus] 2, 'new', 1, 1
EXEC [dbo].[spGetDiscrepancyStatus] 2,  'new', 5, 1
EXEC [dbo].[spGetDiscrepancyStatus] 2,  'resol', 5, 1
EXEC [dbo].[spGetDiscrepancyStatus] 2,  'resol', 5, 0
EXEC [dbo].[spGetDiscrepancyStatus] 2,  NULL, 4, 1
EXEC [dbo].[spGetDiscrepancyStatus] 2,  NULL, NULL, 1

EXEC [dbo].[spGetDiscrepancyStatus] 2, NULL, NULL, 1, 0, 25, 'DiscrepancyStatus'
EXEC [dbo].[spGetDiscrepancyStatus] 2, NULL, NULL, 1, 0, 25, 'DiscrepancyCategory'

update discrepancyStatuses 
set DiscrepancyStatusType = 0
WHERE DISCREPANCYstatusID in (1,2)

update discrepancyStatuses 
set ActiveFlag = 0
WHERE DISCREPANCYstatusID in (

20
,21
,22
,23
,24
,25
)

DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyStatus] 
	  @eventUserID = NULL
	, @DiscrepancyStatus     = NULL -- 'Resol'
	, @DiscrepancyCategoryID = NULL
	, @DiscrepancyStatusType = NULL -- 1

	-- maybe move hardcoding into stored procedure, then can check for isnull values
	, @pageIndex = 0
	, @pageSize = 25
	, @sortBy = 'DiscrepancyStatusID' 
	, @orderBy = 1 -- 0: ASC; 1: DESC
PRINT @returnValue 

select * from discrepancystatuses order by DiscrepancyStatusID desc


-- *****************************************************************************************************
