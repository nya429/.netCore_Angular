
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetCCAMemberData] 
PRINT @returnValue 
-- new test
-- SEARCH BY NAME
EXEC [dbo].[spGetCCAMemberData] 
	@eventUserID = 2
	, @Name = 'JACO'
	, @CCAID = NULL
	, @MMIS_ID = NULL

-- SEARCH BY CCAID
EXEC [dbo].[spGetCCAMemberData] 
	 @CCAID = 5365566023
	
-- SEARCH BY MMIS
EXEC [dbo].[spGetCCAMemberData] 
	  @Name = NULL
	, @CCAID = NULL
	, @MMIS_ID = '100009285841'

-- SEARCH BY ALL
EXEC [dbo].[spGetCCAMemberData] 

	@pageIndex = 20
	, @pageSize = 50
	, @sortBy = 'CCAID' 
	, @orderBy = 1 -- 0: ASC; 1: DESC

-- *****************************************************************************************************
