
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMemberName] null, 'jaco'
PRINT @returnValue 

DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMemberName] null, 'sand woo'
PRINT @returnValue 



-- *****************************************************************************************************
