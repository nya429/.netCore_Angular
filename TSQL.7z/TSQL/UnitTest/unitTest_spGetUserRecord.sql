
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetUserRecord] 
PRINT @returnValue 

EXEC [dbo].[spGetUserRecord] @UserID = 1
EXEC [dbo].[spGetUserRecord] @UserID = 2
EXEC [dbo].[spGetUserRecord] @UserID = 3
EXEC [dbo].[spGetUserRecord] @UserID = 5
EXEC [dbo].[spGetUserRecord] @UserID = 7


select * from users
select * from userrolemap
-- *****************************************************************************************************
