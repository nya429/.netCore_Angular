
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessExpectedPayments] 
PRINT @returnValue 


select * from ExpectedPayments
select  
	count(*)
	, sum(case when RateCardID is null then 0 else 1 end) as RateCardFound
	, sum(case when RateCardID is null then 1 else 0 end) as RateCardNotFound
from ExpectedPayments

select * from ExecutionLog order by ExecutionLogID desc

-- *****************************************************************************************************
