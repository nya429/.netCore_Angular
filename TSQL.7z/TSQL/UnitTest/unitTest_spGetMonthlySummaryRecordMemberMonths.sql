
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMonthlySummaryRecordMemberMonths] 
PRINT @returnValue 

EXEC [dbo].[spGetMonthlySummaryRecordMemberMonths] 
	  @eventUserID = 2
	  , @MasterPatientID = 1 
	  , @Year = '2019'


EXEC [dbo].[spGetMonthlySummaryRecordMemberMonths] 
	  @eventUserID = 2
	  , @MasterPatientID = 2 -- complete set of months
	  , @Year = '2019'

EXEC [dbo].[spGetMonthlySummaryRecordMemberMonths] 
	  @eventUserID = 2
	  , @MasterPatientID = 4 -- gaps in months (check with Yue... does this need to be years?)
	  , @Year = '2019'


select cast('2019' as date)
-- select eomonth(dateadd(m,11,cast('2019' as date))) -- don't want, because member months are always listed with the 1st of month
select dateadd(m,11,cast('2019' as date))


-- *****************************************************************************************************
