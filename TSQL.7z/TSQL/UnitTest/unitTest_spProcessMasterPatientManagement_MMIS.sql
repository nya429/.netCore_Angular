
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMasterPatientManagement_MMIS] 
PRINT @returnValue 


select insertDate, count(*) as countByInserDate 
from MasterPatientManagement
group by insertDate
order by insertDate

select updateDate, count(*) as countByUpdateDate 
from MasterPatientManagement
group by updateDate
order by updateDate

select * from MasterPatientManagement
where insertDate > '2019-10-05'

select top 10 * from MasterPatientManagement

update mpm
	set SourceSystem = 'CCA'
-- select *
from MasterPatientManagement as mpm
where MasterPatientID	= 10 -- 100000034387


select * from ExecutionLog order by ExecutionLogID desc

-- *****************************************************************************************************
