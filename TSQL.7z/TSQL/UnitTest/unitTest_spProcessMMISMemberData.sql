
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMMISMemberData] 
PRINT @returnValue 

exec spTrun_MMISMemberData
select * from ExecutionLog order by startTime desc, endTime desc
SELECT TOP 100 * FROM MMISMemberData 
SELECT TOP 100 * FROM vwMMISMemberData 

-- *****************************************************************************************************
