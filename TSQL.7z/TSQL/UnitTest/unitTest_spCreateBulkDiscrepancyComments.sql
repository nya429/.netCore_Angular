
USE [RevRec]
GO

-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spCreateBulkDiscrepancyComments] 
PRINT @returnValue 

declare @SendDiscrepancyIDs as dbo.BulkID
insert into @SendDiscrepancyIDs (
	updateID
)
values 
  (1)
, (2)
, (3)
, (4)


-- Full Example Test
DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spCreateBulkDiscrepancyComments] 
	  @eventUserID = 2
	, @DiscrepancyIDs = @SendDiscrepancyIDs
	, @DiscrepancyComment = 'testing the bulkiness'
	, @ActiveFlag = 1 

	-- , @NewIdentity int output -- no single new id can be sent for a bulk update
	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @RetCd

-- validate results
select * from discrepanciescomments
select * from discrepancies


-- *****************************************************************************************************
