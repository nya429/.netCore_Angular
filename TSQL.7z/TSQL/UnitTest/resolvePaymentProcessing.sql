use revrec


	select 
		 f.Product	
		,f.ReportType	
		,f.ReportMonth
		,p.MemberID
		,p.CapitationMonthYear
		,p.RateCell	
		,p.MCRegion	
		,p.BaseCapitationAmount
		,p.Paid
		,pp.PatientPay
		,sd.SpendDown
		,r.Remit

		, ratMMIS.RateCardID
		, ratMMIS.CCARateCell
		, ratMMIS.CCARateCellID
		, ratMMIS.CCARegion
		, ratMMIS.CCARegionID
		, ratMMIS.StartDate
		, ratMMIS.EndDate
		, ratMMIS.Amount
		, ratMMIS.ActiveFlag
	
		, p.PaymentIndicator -- won't even need this if row_number works



		-- , row_number() over(Partition by p.MemberID, p.CapitationMonthYear, p.RateCell, p.MCRegion order by f.ReportMonth desc) as rnCurrentPaidAmount
		-- cannot consider rate cell and region... this creates duplciate monthly summary record and discrepancies
		, row_number() over(Partition by p.MemberID, p.CapitationMonthYear order by f.ReportMonth desc, p.PaymentIndicator desc) as rnCurrentPaidAmount
	-- select count(*) -- 2296133
	from MMISFileProcessing as f 
	-- lead table... but all should have same member set
	inner join PaymentDetailPaid as p on p.MMISFileProcessID = f.MMISFileProcessID 
	inner join PaymentDetailPatientPay as pp 
		on pp.MMISFileProcessID = f.MMISFileProcessID 
		and pp.MemberID = p.MemberID
		and pp.CapitationMonthYear = p.CapitationMonthYear
		and pp.PaymentIndicator = p.PaymentIndicator
		and pp.RateCell	= p.RateCell
		and pp.MCRegion	= p.MCRegion
	inner join PaymentDetailSpendDown as sd 		
		on sd.MMISFileProcessID = f.MMISFileProcessID 
		and sd.MemberID = p.MemberID
		and sd.CapitationMonthYear = p.CapitationMonthYear
		and sd.PaymentIndicator = p.PaymentIndicator
		and sd.RateCell	= p.RateCell
		and sd.MCRegion	= p.MCRegion
	-- do we need this table for monthly summary record
	inner join PaymentDetailRemit as r 		
		on r.MMISFileProcessID = f.MMISFileProcessID 
		and r.MemberID = p.MemberID
		and r.CapitationMonthYear = p.CapitationMonthYear
		and r.PaymentIndicator = p.PaymentIndicator
		and r.RateCell	= p.RateCell
		and r.MCRegion	= p.MCRegion

	-- potential addition, rather than dealing with this in MonthlySummaryRecord... will still be current because in view
	left join vwRateCellMap	 as rcMap   on rcMap.MMISRateCell = p.RateCell and rcMap.ActiveFlag = 1
	left join vwRegionMap    as regMap  on regMap.MMISRegion  = p.MCRegion and regMap.ActiveFlag = 1
	left join vwRateCard     as ratMMIS	
		on  ratMMIS.CCARateCellID = rcMap.CCARateCellID
		and ratMMIS.CCARegionID = regMap.CCARegionID
		and p.CapitationMonthYear between ratMMIS.StartDate and ratMMIS.EndDate
		and ratMMIS.ActiveFlag = 1
	where p.memberid = '100028157103' -- '100013253412'
	order by CapitationMonthYear, ReportMonth

