
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spCreateMonthlyClose] 
PRINT @returnValue 

DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spCreateMonthlyClose] 
	  @eventUserID = 2 

	, @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @NewID
PRINT @RetCd


-- truncate table MonthlyCloseHeader
-- truncate table MonthlyCloseRecord
-- select * from dbo.listParameters

-- Confirm data tables updated appropriately
select * from MonthlyCloseHeader
select top 10 * from MonthlyCloseRecord
select count(*) from MonthlyCloseRecord
select * from ExecutionLog order by ExecutionLogID desc
select * from UserEventLog order by EventID desc

-- *****************************************************************************************************
