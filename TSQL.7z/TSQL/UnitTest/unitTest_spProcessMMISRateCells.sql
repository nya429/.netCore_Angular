
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMMISRateCells] 
PRINT @returnValue 



-- validate results:
select * from MMISRateCells
select * from vwMMISRateCells
select * from ExecutionLog order by startTime desc, endTime desc

-- *****************************************************************************************************
