
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetUnmappedMMISRegionCount] 
PRINT @returnValue 

exec spGetMMISRegions -- has a flag for unmapped... why can't this be used, or is it used?
-- *****************************************************************************************************
