
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetRateCard] 
	@eventUserID = NULL
	, @searchRateCell = NULL
	, @searchRegion  = NULL
	, @searchProduct  = NULL
	, @StartDate     = '2019-01-01'
	, @EndDate       = '2019-06-30'
	, @pageIndex 		  = 0
	, @pageSize 			  = 25
	, @sortBy 	  = 'RateCardID' 
	, @orderBy             = 1 -- 0: ASC; 1: DESC
PRINT @returnValue 


-- API parameters
EXEC [dbo].[spGetRateCard]   1, N'', N'', N'', N'', N'', 1, 25, N'', 0
EXEC [dbo].[spGetRateCard]   1, N'', N'', N'', NULL, NULL, 1, 25, N'', 0

EXEC [dbo].[spGetRateCard]   null, 'cwd'
EXEC [dbo].[spGetRateCard]   null, 'C2'   , 'ap'     , NULL
EXEC [dbo].[spGetRateCard]   null, 'CW'   , 'West'   , NULL
EXEC [dbo].[spGetRateCard]   null, 'I1M'  , 'st'     , NULL

EXEC [dbo].[spGetRateCard]   null, 'C2'   , 'ap'     , 'ICO'
EXEC [dbo].[spGetRateCard]   null, 'CW'   , 'West'   , 'ICO'
EXEC [dbo].[spGetRateCard]   null, 'I1M'  , 'st'     , 'ICO'r

EXEC [dbo].[spGetRateCard]   null, 'C2'   , 'ap'     , 'SCO'
EXEC [dbo].[spGetRateCard]   null, 'CW'   , 'West'   , 'SCO'
EXEC [dbo].[spGetRateCard]   null, 'I1M'  , 'st'     , 'SCO'

EXEC [dbo].[spGetRateCard]   null, 'C2'   , NULL     , NULL
EXEC [dbo].[spGetRateCard]   null, 'CW'   , NULL     , NULL
EXEC [dbo].[spGetRateCard]   null, 'I1M'  , NULL     , NULL

EXEC [dbo].[spGetRateCard]   null, NULL   , 'ap'     , NULL
EXEC [dbo].[spGetRateCard]   null, NULL   , 'West'   , NULL
EXEC [dbo].[spGetRateCard]   null, NULL   , 'st'     , NULL

EXEC [dbo].[spGetRateCard]   null, NULL   , NULL     , 'ICO'
EXEC [dbo].[spGetRateCard]   null, NULL   , NULL     , 'SCO'

EXEC [dbo].[spGetRateCard]   2, null, NULL, NULL     , '2019-01-01', '2019-06-30'
EXEC [dbo].[spGetRateCard]   2, null, NULL, NULL     , '2019-07-01', '2019-12-31'
EXEC [dbo].[spGetRateCard]   2, null, NULL, NULL     , '2019-07-01', NULL
EXEC [dbo].[spGetRateCard]   2, null, NULL, NULL     , NULL, '2019-12-31'

EXEC [dbo].[spGetRateCard]   null, 'CW'   , NULL     , NULL, '2019-07-01', NULL
EXEC [dbo].[spGetRateCard]   null, 'CWD'   , NULL     , NULL, '2019-07-01', NULL
EXEC [dbo].[spGetRateCard]   null, 'DC3A'  , NULL     , NULL, NULL, '2019-12-31'

EXEC [dbo].[spGetRateCard]   null, 'CWD'  , NULL     , NULL, NULL, NULL, 0, 1
EXEC [dbo].[spGetRateCard]   null, 'CWD'  , NULL     , NULL, NULL, NULL, 1, 1
EXEC [dbo].[spGetRateCard]   null, 'CWD'  , NULL     , NULL, NULL, NULL, 2, 1
EXEC [dbo].[spGetRateCard]   null, 'CWD'  , NULL     , NULL, NULL, NULL, 3, 1
EXEC [dbo].[spGetRateCard]   null, 'CWD'  , NULL     , NULL, NULL, NULL, 4, 1

select * from vwRateCard


-- *****************************************************************************************************
