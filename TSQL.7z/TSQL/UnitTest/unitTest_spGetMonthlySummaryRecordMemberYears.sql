
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMonthlySummaryRecordMemberYears] 
PRINT @returnValue 

-- find members with memberMonth gaps
	 select top 100 * from MonthlySummaryRecord 
	 order by MasterPatientID
	 , MemberMonth

-- "create" some Monthly summary records 
insert into MonthlySummaryRecord (
	MasterPatientID, MMIS_ID, MemberMonth, Variance, PaymentError, BaseCapitationAmount, PatientPayAmountN, PatientPayAmountSCO, PaidCapitationAmount, CCARateCellID, CCARegionID, CCAPatientPay, CCAPatientSpendDown, CCARateCardID, CCAAmount, CCANetAmount, MMISRateCellID, MMISRegionID, MMISPatientPay, MMISPatientSpendDown, MMISRateCardID, MMISAmount, MMISNetAmount
)
values
  ( 1 , NULL, '2018-01-01', NULL, 0.00, 2785.69, 0.00, 0.00, 2785.69, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 5, 2, 0.00, 0.00, 6, 2785.69, 2785.69)
, ( 2 , NULL, '2018-01-01', NULL, 0.00, 2785.69, 0.00, 0.00, 2785.69, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 5, 2, 0.00, 0.00, 6, 2785.69, 2785.69)
, ( 3 , NULL, '2017-01-01', NULL, 392.17, 515.17, 0.00, 0.00, 515.17, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 22, 3, 0.00, 0.00, 78, 123.00, 123.00)
, ( 4 , NULL, '2017-04-01', NULL, 0.00, 2785.69, 0.00, 0.00, 2785.69, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 5, 2, 0.00, 0.00, 6, 2785.69, 2785.69)
, ( 6 , NULL, '2018-01-01', NULL, 0.00, 186.42, 0.00, 0.00, 186.42, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 21, 2, 0.00, 0.00, 44, 186.42, 186.42  )
, ( 7 , NULL, '2018-01-01', NULL, 0.00, 186.42, 0.00, 0.00, 186.42, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 21, 2, 0.00, 0.00, 44, 186.42, 186.42  )
, ( 10, NULL, '2018-01-01', NULL, 392.17, 515.17, 0.00, 0.00, 515.17, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 22, 3, 0.00, 0.00, 78, 123.00, 123.00)

select * from MonthlySummaryRecord where masterpatientid = 1

EXEC [dbo].[spGetMonthlySummaryRecordMemberYears] 
	  @eventUserID = 2
	  , @MasterPatientID = 1 -- complete set of months

EXEC [dbo].[spGetMonthlySummaryRecordMemberYears] 
	  @eventUserID = 2
	  , @MasterPatientID = 2 -- missing 2019 becuase I deleted for testing

EXEC [dbo].[spGetMonthlySummaryRecordMemberYears] 
	  @eventUserID = 2
	  , @MasterPatientID = 4 -- gaps in months (check with Yue... does this need to be years?)

	  select * from monthlysummaryrecord where masterpatientid = 4

	   select * from monthlysummaryrecord where masterpatientid = 1 
	   -- delete from monthlysummaryrecord where masterpatientid = 2 and membermonth >= '2019-01-01'
	   select * from monthlysummaryrecord where masterpatientid = 3 
	   select * from monthlysummaryrecord where masterpatientid = 4 
	   select * from monthlysummaryrecord where masterpatientid = 6 
	   select * from monthlysummaryrecord where masterpatientid = 7 
	   select * from monthlysummaryrecord where masterpatientid = 10

-- *****************************************************************************************************
