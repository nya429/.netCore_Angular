
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyRecord] 
PRINT @returnValue 


exec [dbo].[spGetDiscrepancyRecord] 
	  @eventUserID = 2
	, @DiscrepancyID = 2

exec [dbo].[spGetDiscrepancyRecord] 
	  @eventUserID = 2
	, @DiscrepancyID = 1

exec [dbo].[spGetDiscrepancyRecord] 
	  @eventUserID = 2
	, @DiscrepancyID = 500



-- *****************************************************************************************************
