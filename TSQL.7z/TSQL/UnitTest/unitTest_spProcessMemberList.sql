
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMemberList] 
PRINT @returnValue 

select * from memberList

select * from ExecutionLog order by ExecutionLogID desc

-- *****************************************************************************************************
