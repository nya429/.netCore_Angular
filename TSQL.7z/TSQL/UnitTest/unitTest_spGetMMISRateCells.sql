
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMMISRateCells] 
PRINT @returnValue 



EXEC [dbo].[spGetMMISRateCells] 2, 'C2'  , NULL
EXEC [dbo].[spGetMMISRateCells] 2, 'CW'  , NULL
EXEC [dbo].[spGetMMISRateCells] 2, 'I1M'	, NULL

EXEC [dbo].[spGetMMISRateCells] 2, 'C2'  , 'ICO'
EXEC [dbo].[spGetMMISRateCells] 2, 'CW'  , 'ICO'
EXEC [dbo].[spGetMMISRateCells] 2, 'I1M'	, 'ICO'

EXEC [dbo].[spGetMMISRateCells] 2, 'C2'  , 'SCO'
EXEC [dbo].[spGetMMISRateCells] 2, 'CW'  , 'SCO'
EXEC [dbo].[spGetMMISRateCells] 2, 'I1M'	, 'SCO'

EXEC [dbo].[spGetMMISRateCells] 2, NULL   , 'ICO'
EXEC [dbo].[spGetMMISRateCells] 2, NULL	 , 'SCO'



DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMMISRateCells] 
	  @eventUserID      = NULL
	, @RateCell   = NULL -- 'CAD' 
	, @Product    = NULL -- 'ICO' -- 'SCO' 


	, @pageIndex        = 1
	, @pageSize         = 25
	, @sortBy           = 'MMISRateCellID' 
	, @orderBy          = 1 -- 0: ASC; 1: DESC

PRINT @returnValue 


-- *****************************************************************************************************
