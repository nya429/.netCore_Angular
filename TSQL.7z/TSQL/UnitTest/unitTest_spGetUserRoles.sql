
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetUserRoles] 
PRINT @returnValue 


select * from users

EXEC [dbo].[spGetUserRoles] NULL, 'Admin'
EXEC [dbo].[spGetUserRoles] 1

EXEC [dbo].[spGetUserRoles] NULL, 'Super'


-- eliminated pagination
EXEC [dbo].[spGetUserRoles] NULL, NULL, 1, 3 
EXEC [dbo].[spGetUserRoles] NULL, NULL, 2, 3 



-- *****************************************************************************************************
