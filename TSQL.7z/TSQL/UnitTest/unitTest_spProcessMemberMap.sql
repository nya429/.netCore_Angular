
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMemberMap] 
PRINT @returnValue 

select * from memberMap order by insertDate desc

-- Test new process
-- MemberMapID	MasterPatientID	CCAID	ActiveFlag	insertDate	updateDate
-- 50155	55953	5365634050	1	2019-09-25 11:53:54.850	2019-09-25 11:53:54.850
-- delete from MEmberMap where MemberMapID = 50155

select * from memberMap where MasterPatientID = 55953	

select * from ExecutionLog order by starttime desc, endtime desc

-- *****************************************************************************************************
