
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMMISGetPaymentFiles] 
PRINT @returnValue 


select * 
from MMISFileProcessing
order by ReportType, Product, ReportMonth 

select * -- delete 
from MMISFileProcessing
where ReportMonth = '2018-02-01'

select * from dbo.listParameters 
select * from ExecutionLog order by ExecutionLogID desc
-- *****************************************************************************************************
