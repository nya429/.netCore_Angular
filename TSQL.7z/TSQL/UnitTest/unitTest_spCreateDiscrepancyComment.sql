
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spCreateDiscrepancyComment] 
PRINT @returnValue 

DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spCreateDiscrepancyComment] 
	  @eventUserID  = 2
	, @DiscrepancyID = 1
	, @ReplyCommentID = 1 -- NULL
	, @DiscrepancyComment = 'What is the magic word?'
	, @ActiveFlag = 1 

	, @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output

PRINT @returnValue 

PRINT @NewID 
PRINT @RetCd 

-- truncate table discrepanciescomments
-- truncate table discrepanciescommentsHistory

select * from discrepanciescomments
select * from discrepanciescommentsHistory


-- *****************************************************************************************************
