
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetCCARateCells] 
PRINT @returnValue 

EXEC [dbo].[spGetCCARateCells] 2, 'C2'  , NULL
EXEC [dbo].[spGetCCARateCells] 2, 'CW'  , NULL
EXEC [dbo].[spGetCCARateCells] 2, 'I1M'	, NULL

EXEC [dbo].[spGetCCARateCells] 2, 'C2'  , 'ICO'
EXEC [dbo].[spGetCCARateCells] 2, 'CW'  , 'ICO'
EXEC [dbo].[spGetCCARateCells] 2, 'I1M'	, 'ICO'

EXEC [dbo].[spGetCCARateCells] 2, 'C2'  , 'SCO'
EXEC [dbo].[spGetCCARateCells] 2, 'CW'  , 'SCO'
EXEC [dbo].[spGetCCARateCells] 2, 'I1M'	, 'SCO'

EXEC [dbo].[spGetCCARateCells] 2, NULL   , 'ICO'
EXEC [dbo].[spGetCCARateCells] 2, NULL	 , 'SCO'


exec spGetCCARateCells
	-- Add the parameters for the stored procedure here
	@eventUserID = NULL
	, @searchRateCell = 'CW'
	, @searchProduct = NULL
/*
	, @pageIndex  = 0
	, @pageSize   = 25
	, @sortBy     = 'CCARateCellID' 
	, @orderBy    = 1 -- 0: ASC; 1: DESC
*/

-- *****************************************************************************************************
