
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMemberInfo] @MasterPatientID = 5
PRINT @returnValue 

EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 7
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 70
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 7000
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 777

-- some latency... may want to explore joins in view or staging data

-- select top 10 * from discrepancies
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 205
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 27
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 125
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 219

-- not all assigned
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 1397   
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 10102  
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 41074  
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 51673  
-- *****************************************************************************************************
