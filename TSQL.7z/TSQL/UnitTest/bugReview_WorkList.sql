use RevRec

exec spGetMemberList
@MMIS_ID = '100016467613'
, @assigneeID = 2
, @includeZeroDiscrepancy = 1



		select 
			  ml.MasterPatientID 
			, ml.MemberFirstName 
			, ml.MemberMiddleName 
			, ml.MemberLastName 
			, ml.MMIS_MMIS_ID 
			, ml.CCAID 
			, ml.Product 
			, ml.EnrollStartDate 
			, ml.EnrollEndDate 
			, ml.DOB 
			, ml.DOD 
			, ml.RatingCategory 
			, ml.Region 
			, ml.MemberEnrollmentStatus 
			, dt.TotalDiscrepancies 
			, datediff(day,dt.DiscrepancyAge, '2019-10-15 11:25:20.010') as maxAging				  
			, dt.absoluteVarianceSum 
			, d.TotalAssigned
			, count(*) over() as ResultCount
		from MemberList as ml
			left join (
				select MasterPatientID, sum(abs(variance)) as absoluteVarianceSum, min(MemberMonth) as DiscrepancyAge, count(*) as TotalDiscrepancies
				from Discrepancies as d
				inner join DiscrepancyStatuses as ds on ds.DiscrepancyStatusID = d.DiscrepancyStatusID
				inner join DiscrepancyCategories as dc on dc.DiscrepancyCategoryID = ds.DiscrepancyCategoryID
				where dc.DiscrepancyCategoryDisplay = 1
				group by MasterPatientID
			) as dt on dt.MasterPatientID = ml.MasterPatientID

		
			inner join (
				select d.MasterPatientID, d.Assigned_UserID, count(*) as TotalAssigned
				from Discrepancies as d
				inner join DiscrepancyStatuses as ds on ds.DiscrepancyStatusID = d.DiscrepancyStatusID
				inner join DiscrepancyCategories as dc on dc.DiscrepancyCategoryID = ds.DiscrepancyCategoryID
				where dc.DiscrepancyCategoryDisplay = 1
				group by d.MasterPatientID, d.Assigned_UserID
			) as d on d.MasterPatientID = ml.MasterPatientID
			and d.Assigned_UserID = 2 
			WHERE ml.MMIS_MMIS_ID  = '100016467613'

			select * from MemberList as ml where ml.MMIS_MMIS_ID  = '100016467613'
		
			select * from Discrepancies where MasterPatientID = 24395


			-- DiscrepancyID = 1592