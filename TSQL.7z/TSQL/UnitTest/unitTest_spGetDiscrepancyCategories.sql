
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyCategories] 
PRINT @returnValue 

EXEC [dbo].[spGetDiscrepancyCategories] 2 
-- no longer relevant
EXEC [dbo].[spGetDiscrepancyCategories] 2, NULL, NULL
EXEC [dbo].[spGetDiscrepancyCategories] 2, 'Working', 1
EXEC [dbo].[spGetDiscrepancyCategories] 2, 'Work'
EXEC [dbo].[spGetDiscrepancyCategories] 2, NULL, 1
EXEC [dbo].[spGetDiscrepancyCategories] 2, NULL, 0

EXEC [dbo].[spGetDiscrepancyCategories] 2 , 0, 2
EXEC [dbo].[spGetDiscrepancyCategories] 2 , 1, 2
EXEC [dbo].[spGetDiscrepancyCategories] 2 , 2, 2



DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyCategories] 
	  @eventUserID = 2 
	, @pageIndex   = 1
	, @pageSize    = 5
	, @sortBy      = '' -- 'DiscrepancyCategoryID' -- may need to check this 
	, @orderBy     = 1 -- 0: ASC; 1: DESC
	
PRINT @returnValue 

SELECT * FROM ExecutionLog ORDER BY ExecutionLogiD DESC

-- *****************************************************************************************************
