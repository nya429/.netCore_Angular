
USE [RevRec]
GO


-- *****************************************************************************************************
-- Test Execution Blocks
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMonthlySummaryRecord] 
PRINT @returnValue 


-- Validation
select count(*) from MonthlySummaryRecord
select count(*) from MonthlySummaryRecord where ccaRatecardid is null

select top 1000 * from MonthlySummaryRecord
select * from ExecutionLog order by ExecutionLogID desc

select top 1000 * from MonthlySummaryRecord
where variance is not null

select count(*) as MSRCount
from MonthlySummaryRecord

select * from monthlysummaryrecord where MasterPatientID	= 7138 and MemberMonth = '2019-04-01'

-- no duplicates	
select MasterPatientID, MemberMonth, count(*) as dupcheck
from MonthlySummaryRecord
group by MasterPatientID, MemberMonth
having count(*) > 1

select * from 7138
select * from vwCCAMemberData WHERE MMIS_ID = '100006067291'

-- *****************************************************************************************************
