
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyList] 
	@MasterPatientID = 49717 -- 16439 
PRINT @returnValue 


-- setup to test bulk
select * from discrepancies where masterpatientid = 16439 
update discrepancies set Assigned_UserID = 1 where DiscrepancyID between 1 and 1000
update discrepancies set Assigned_UserID = 2 where DiscrepancyID between 1001 and 2000
update discrepancies set Assigned_UserID = 3 where DiscrepancyID between 2001 and 3000

declare @SendAssigneeIDs as dbo.BulkID
insert into @SendAssigneeIDs (
	updateID
)
values (1)
, (2)


EXEC [dbo].[spGetDiscrepancyList]
	@AssigneeIDs = @SendAssigneeIDs 

EXEC [dbo].[spGetDiscrepancyList]
	@CCARateCellIDs = @SendAssigneeIDs 

EXEC [dbo].[spGetDiscrepancyList]
	@DiscrepancyStatusIDs = @SendAssigneeIDs 


EXEC [dbo].[spGetDiscrepancyList]
	  @eventUserID = NULL
	, @name					  = NULL
	, @CCAID				  = NULL
	, @MMIS_ID				  = NULL
	, @MasterPatientID		  = NULL
	-- , @Months				  
	-- , @Programs				  
	-- , @CCARateCellIDs		  
	-- , @DiscrepancyStatusIDs	  
	-- , @AssigneeIDs            
	, @hasComment			  = 1 -- NULL -- 0: No; 1: Yes
	, @discoverDateStart	  = '2019-09-05'
	, @discoverDateEnd		  = '2019-09-30'
	, @resolutionDateStart	  = NULL
	, @resolutionDateEnd	  = NULL
	, @includeResolved        = 0 -- 0: No; 1: Yes

	, @TypeRateCell           int = NULL  -- IDS-377	0: No; 1: Yes
	, @TypeRegion			  int = NULL  -- IDS-377	0: No; 1: Yes
	, @TypePatientPay		  int = NULL  -- IDS-377	0: No; 1: Yes
	, @TypePatientSpendDown   int = NULL  -- IDS-377	0: No; 1: Yes
	, @TypePaymentError	      int = NULL  -- IDS-377	0: No; 1: Yes

	, @memberEnrollmentStatus int = NULL  -- IDS-368   0:	'Never enrolled'; 1: 'Currently enrolled';	2: 'Not currently enrolled';


	, @memberEnrollmentStatus int = NULL 
	, @pageIndex int		  = 0
	, @pageSize int			  = 25
	, @sortBy varchar(50)	  = 'Variance' 
	, @orderBy int            = 1 -- 0: ASC; 1: DESC
	
	
		    
EXEC [dbo].[spGetDiscrepancyList]
	@name = 'mar da'


declare @SendPrograms as dbo.BulkString
insert into @SendPrograms (
	updateString
)
values ('SCO')
, ('ICO')

EXEC [dbo].[spGetDiscrepancyList]
	@Programs = @SendPrograms


declare @SendMonths as dbo.BulkDate
insert into @SendMonths  (
	updateDate
)
values ('2019-05-01')
, ('2019-03-01')

EXEC [dbo].[spGetDiscrepancyList]
	@Months = @SendMonths



declare @SendDisc as dbo.BulkID
insert into @SendDisc  (
	updateID
)
values (9) -- 'No Active MDS'


	
EXEC [dbo].[spGetDiscrepancyList]
	@name = 'felix'
	, @pagesize = 50
	, @DiscrepancyStatusIDs = @SendDisc 

-- where are the discrepancies: 100015217589

select * from DiscrepanciesComments where discrepancyID = 666

EXEC [dbo].[spGetDiscrepancyList]
@hasComment			  = 0 -- NULL -- 0: No; 1: Yes


select * from discrepanciesComments
select * from Discrepancies where DiscrepancyID = 173015

EXEC [dbo].[spGetDiscrepancyList]
@MasterPatientID = 24717


EXEC [dbo].[spGetDiscrepancyList]
@MMIS_ID = '100013525851'

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetDiscrepancyList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetDiscrepancyList]
GO

/****** Object:  StoredProcedure [dbo].[spGetDiscrepancyList]    Script Date: 09/05/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/05/2019
-- Description:	API
				Gets list of discrepancies
				Will filter on bulk

				Post unit test - 09/23/2019
					Added columns and filters for: 
						Name (first and last)
						Product
							
					Updated Model to show proper columns as returned by this procedure
					
					Updated DiscrepancyStatusIDs parameter.  was joined to DiscrepancyID instead of DiscrepancyStatusID

				Post unit test - 09/24/2019
					reassigned Assigned and Action user name with concatentated first and last name instead of UserNameAD

				Post Unit Test - 10/11/2019
					Member List - counts need to be updated, including ""drop offs""
					Discrepancy should only be showing ""visible"" status categories by default
					Money totals should change when discrepancies updated 
					Aging - Nick asked to align with member month (not system insert date) "

				Post QA - 10/16/2019
					Added sorting for Variance					
					Added considerations for including "raw" ratecells and regions when missing from rate card
					

-- Modified by: Jonathan Lewis
-- Modified dt: 01/06/2020
-- Description: ADS-3157 (release ADS-2980)
					Added HasDiscrepancyComment,CountDiscrepancyComments

-- Modified by: Shubham Pathak
-- Modified dt: 03/03/2020
-- Description: IDS-380 (release IDS-367)
					Added code for MemberMonth Sorting

-- Modified by: Shubham Pathak
-- Modified dt: 03/18/2020
-- Description: IDS-387 (release IDS-367)
					Adding parameter @varianceSign to enable filtering on the basis of 
					over payment vs under payment

-- Modified by: Shubham Pathak
-- Modified dt: 04/16/2020
-- Description: IDS-982 (release IDS-865)
					Added code for DiscrepancyStatus Sorting


-- Modified by: Yue Song
-- Modified dt: 04/22/2020
-- Description: IDS-827 (release IDS-865)
					Added DiscrepancyCategory 

-- Modified by: Yue Song
-- Modified dt: 04/30/2020
-- Description: IDS-377 (release IDS-1493)
					Added  
							TypeRateCell          
							TypeRegion			   
							TypePatientPay		   
							TypePatientSpendDown  
							TypePaymentError	
			     IDS - 983 (release IDS-865) 
					Added sort by discrepancyID  
				 IDS - 368 (release IDS-865) 
					Added EnrollmentStatus into result set and included @memberEnrollmentStatus into WHERE clause   

 -- Modified dt: 05/01/2020
 -- Description: IDS-1051 (release IDS-1493)
					-- Due to cannot find a proper approach to apply offset/fetch on condition in middle of conststruct the query
					Created 2 CTEs 
 -- Modified dt: 05/06/2020
 -- Description: IDS-374 (release IDS-1493)
						changed IDS-1051 approach, First CTE is slowing down the query due to it conducts a full scan when no filters applied, switch to use TempTable to store the result 
						made proc recompile at eachtime 
						changed m.enrollmentstatus association from enrollmentstatus(text) to enrollmentstatusId(integer)

 -- Modified dt: 05/21/2020
 -- Description: IDS-375 (release IDS-1493)
						 work with reporting Non-Member vs Member category 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetDiscrepancyList]
	-- Add the parameters for the stored procedure here
	  @eventUserID int = NULL
	, @name					  varchar(50) = NULL
	, @CCAID				  bigint = NULL
	, @MMIS_ID				  char(12) = NULL
	, @MasterPatientID		  int = NULL
	, @Months				  dbo.BulkDate readonly   	-- , @Months				  date = NULL -- List
	, @Programs				  dbo.BulkString readonly 	-- , @Programs				  char(3) = NULL -- List
	, @CCARateCellIDs		  dbo.BulkID readonly	  	-- , @CCARateCellIDs		  int = NULL -- List
	, @DiscrepancyStatusIDs	  dbo.BulkID readonly	  	-- , @DiscrepancyStatusIDs	  int = NULL -- List
	, @AssigneeIDs            dbo.BulkID readonly	  	-- , @AssigneeIDs			  int = NULL -- List
	, @hasComment			  int = 0 -- 0: All; 1: Yes
	, @discoverDateStart	  date = NULL
	, @discoverDateEnd		  date = NULL
	, @resolutionDateStart	  date = NULL
	, @resolutionDateEnd	  date = NULL
	, @varianceSign			  int = NULL
	, @includeResolved        int = 0 -- 0: No; 1: Yes

	, @TypeRateCell           int = NULL  -- IDS-377
	, @TypeRegion			  int = NULL  -- IDS-377
	, @TypePatientPay		  int = NULL  -- IDS-377
	, @TypePatientSpendDown   int = NULL  -- IDS-377
	, @TypePaymentError	      int = NULL  -- IDS-377

	, @memberEnrollmentStatusId int = NULL  -- IDS-368   0:	'Never enrolled'; 1: 'Currently enrolled';	2: 'Not currently enrolled';
	, @memberIsEnrolled         int = NULL  -- IDS-375   0:	'Non-Member'; 1: 'Member';

	, @exportAll              TINYINT = 0   -- IDS-1051 0 : No; 1: Yes 

	, @pageIndex int		  = 0
	, @pageSize int			  = 25
	, @sortBy varchar(50)	  = 'Variance' 
	, @orderBy int            = 1 -- 0: ASC; 1: DESC
		    


WITH RECOMPILE  -- IDS-374
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	DECLARE @sqlStatement varchar(max)
	DECLARE @sqlWhere varchar(max)

	DECLARE @defaultSort varchar(50) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = ('defaultSort_' + OBJECT_NAME(@@PROCID)))
	
	DECLARE @MemberFirstName varchar(20)
	DECLARE @MemberLastName varchar(30) 
	-- DECLARE @BothNamesSent bit = 0 
	
	;
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	
	-- CHECK A NAME WAS SENT AT ALL
	IF ISNULL(@Name, '') <> ''
		-- If only one name sent, use single name in both first and last tests
		/*
		IF CHARINDEX(' ',@Name,1) = 0
			BEGIN
				set @MemberFirstName = @Name
				set @MemberLastName = @Name
			END 
		ELSE
		*/
		IF CHARINDEX(' ',@Name,1) > 0
		-- If a space is included, split into first and last on the space, assuming search order is {[FirstName][ ][LastName]}
			BEGIN 
				set @MemberFirstName = SUBSTRING(@Name, 1, (CHARINDEX(' ',@Name,1) - 1)) 
				set @MemberLastName  = SUBSTRING(@Name, (CHARINDEX(' ',@Name,1) + 1), (len(@Name) - (CHARINDEX(' ',@Name,1)) ) ) 
			END



	-- ******************************
	-- STEP 1. (base query)  
	-- ******************************
BEGIN
	/*
	select 
		-- used in proof of concept
		 d.DiscrepancyID
		,d.MasterPatientID
		,d.MemberMonth
		,d.Assigned_UserID
	*/
	select 
		 d.DiscrepancyID
		,d.MonthlySummaryRecordID
		,d.MasterPatientID
		,M.MemberFirstName
		,m.MemberLastName
		,d.MemberMonth
		,m.Product
		,m.MemberEnrollmentStatus   -- IDS-368
		,d.Variance
		,ISNULL(d.PaymentError, 0.00) AS PaymentError
		,d.BaseCapitationAmount
		,d.PatientPayAmountN
		,d.PatientPayAmountSCO
		,d.PaidCapitationAmount
		,d.CCARateCellID
		,d.CCARegionID
		,coalesce(ccarc.CCARateCell, d.rawCCARateCell        , '99') as CCARateCell        
		,coalesce(ccareg.CCARegion , d.rawCCARegion        , 'NA') as CCARegion         
		,ISNULL(d.CCAPatientPay		 , 0.00) AS CCAPatientPay		 
		,ISNULL(d.CCAPatientSpendDown, 0.00) AS CCAPatientSpendDown
		,ISNULL(d.CCARateCardID, CAST(0 AS INT)) AS CCARateCardID
		,d.CCAAmount
		,d.CCANetAmount
		,ISNULL(d.MMISRateCellID , CAST(0 AS INT)) AS MMISRateCellID 
		,ISNULL(d.MMISRegionID   , CAST(0 AS INT)) AS MMISRegionID   
		-- ,isnull(mmisrc.MMISRateCell		 , '99') as MMISRateCell
		-- ,isnull(mmisreg.MMISRegion       , 'NA') as MMISRegion
		,coalesce(mmisrc.CCARateCell, d.rawMMISRateCell		 , '99') as MMISRateCell
		,coalesce(mmisreg.CCARegion , d.rawMMISRegion      , 'NA') as MMISRegion
		,d.MMISPatientPay
		,d.MMISPatientSpendDown
		,ISNULL(d.MMISRateCardID, CAST(0 AS INT)) AS MMISRateCardID
		,ISNULL(d.MMISAmount, 0.00) AS MMISAmount
		,d.MMISNetAmount
		,d.TypeRateCell
		,d.TypeRegion
		,d.TypePatientPay
		,d.TypePatientSpendDown
		,d.TypePaymentError
		,d.Assigned_UserID
		-- ,uAss.UserNameAD as Assigned_UserName
		, (uAss.UserFirstName + ' ' + uAss.UserLastName) as Assigned_UserName
		, d.Action_UserID
		-- ,uAct.UserNameAD as Action_UserName
		, (uAct.UserFirstName + ' ' + uAct.UserLastName) as Action_UserName
		,d.DiscrepancyStatusID
		,ds.DiscrepancyStatus
		,dc.DiscrepancyCategory     -- add DiscrepancyCategory for IDS-827 (A user with specialist role should NOT be able to change or update a discrepancy in a closed status)
		,d.DueDate
		,d.DiscoverDate
		,d.ResolvedDate
		,d.Balanced
		,d.ActiveFlag
		,d.insertDate
		,d.updateDate
		/*
		,dc.DiscrepancyCommentID	
		-- ,dc.DiscrepancyID	
		,dc.ReplyCommentID as ReplyDiscrepancyCommentID	
		,dc.Comment_UserID	
		,dc.DiscrepancyComment	
		,dc.ActiveFlag as DiscrepancyComment_ActiveFlag		
		,dc.insertDate as DiscrepancyComment_insertDate		
		,dc.updateDate as DiscrepancyComment_updateDate
		*/
		,m.MMIS_MMIS_ID
		,m.CCAID
		
		/** @TODO
		  *	Potential Optimising method:
		  *	count() over() performance vs sub-query 
		  *	https://www.sqlservercentral.com/articles/optimising-server-side-paging-part-ii
		*/

		, count(*) over() as ResultCount
		-- Additional columns
		, isnull(dcom.HasDiscrepancyComment		  , 0) as HasDiscrepancyComment
		, isnull(dcom.CountDiscrepancyComments, 0) as CountDiscrepancyComments
	INTO #TempResult                      -- IDS-374
	from Discrepancies as d
	inner join MemberList as m on m.MasterPatientID = d.MasterPatientID
	-- inner join vwMemberMap as mm on mm.MasterPatientID = d.MasterPatientID
	inner join DiscrepancyStatuses as ds on ds.DiscrepancyStatusID = d.DiscrepancyStatusID
	inner join DiscrepancyCategories as dc on dc.DiscrepancyCategoryID = ds.DiscrepancyCategoryID
	left join (
		select DiscrepancyID, count(*) as CountDiscrepancyComments , max(UpdateDate) as MaxCommentUpdateDate, cast(1 as bit) as HasDiscrepancyComment 
		-- may need new flag and API to mark read
		from DiscrepanciesComments
		where ActiveFlag = 1
		group by DiscrepancyID
		
	) as dcom on dcom.DiscrepancyID = d.DiscrepancyID

	left join users as uAct on uAct.UserID = d.Action_UserID
	left join users as uAss on uAss.UserID = d.Assigned_UserID

		-- join for actual vaulues... maybe reevaluate pulling it into discrepancies table itself
		left join CCARateCells   AS mmisrc  on mmisrc.CCARateCellID   = d.MMISRateCellID  -- even though says MMIS, it actually references CCA values, as that is what defines the rate card
		left join CCARegions     AS mmisreg on mmisreg.CCARegionID    = d.MMISRegionID    -- even though says MMIS, it actually references CCA values, as that is what defines the rate card
		left join CCARateCells	 AS ccarc   on ccarc.CCARateCellID     = d.CCARateCellID
		left join CCARegions     AS ccareg  on ccareg.CCARegionID      = d.CCARegionID 
		-- left join MMISMemberData as mmismem on mmismem.MasterPatientID = d.MasterPatientID

			-- bulk tables - could not handle dynamically
			left join @Months as paramMonths on paramMonths.UpdateDate = d.MemberMonth
			left join @CCARateCellIDs as paramCCARC on paramCCARC.UpdateID = d.CCARateCellID
			left join @DiscrepancyStatusIDs as paramDiscID on paramDiscID.UpdateID = d.DiscrepancyStatusID
			left join @AssigneeIDs as paramAssign on paramAssign.UpdateID = d.Assigned_UserID


			left join @Programs as paramPrograms on paramPrograms.UpdateString = m.Product
	
	WHERE 	
	
		(
			-- IF NAME IS NULL/EMPTY, do not filter
			ISNULL(@Name,'') = '' 
			OR (
				-- If Name was only sent as single string (not split into first and last), check both first and last against name
				(
					(ISNULL(@MemberFirstName,'') = '' AND ISNULL(@MemberLastName,'') = '')
					AND (
						m.MemberFirstName  LIKE @Name + '%'
						OR m.MemberLastName  LIKE @Name + '%'
					)
				)
				OR (
					(ISNULL(@MemberFirstName,'') <> '' AND ISNULL(@MemberLastName,'') <> '')
					AND (
						m.MemberFirstName  LIKE @MemberFirstName + '%'
						AND m.MemberLastName  LIKE @MemberLastName + '%'
					)
				)
			)
		)
		AND (
			@CCAID is null
			OR m.CCAID  = cast(@CCAID as varchar)
		)

		AND (
			isnull(@MMIS_ID,'') = ''
			OR m.MMIS_MMIS_ID  = @MMIS_ID 
		)

		AND (
			@MasterPatientID is null
			OR d.MasterPatientID = cast(@MasterPatientID as varchar)
		)
		AND (
			not exists (select UpdateDate from @Months)
			or paramMonths.UpdateDate is not null

		)
		AND(
			not exists (select UpdateString from @Programs)
			or paramPrograms.UpdateString is not null
		)
		AND (
			not exists (select UpdateID from @CCARateCellIDs)
			or paramCCARC.UpdateID is not null
		)
		AND (
			NOT EXISTS (select UpdateID from @DiscrepancyStatusIDs)
			or paramDiscID.UpdateID is not null
		)
		AND (
			NOT EXISTS (select UpdateID from @AssigneeIDs) 
			or paramAssign.UpdateID is not null
		) 
		AND (
			@hasComment = 0 
			or (
				@hasComment = 1
				and exists (select DiscrepancyID from DiscrepanciesComments as dc where dc.DiscrepancyID = d.DiscrepancyID)
			)
			/*
			or (
				@hasComment = 1
				and exists (select DiscrepancyID from DiscrepanciesComments as dc where dc.DiscrepancyID = d.DiscrepancyID)
			)
			*/
		)
		AND (
			(@discoverDateStart IS NULL OR @discoverDateEnd IS NULL)
			OR D.insertDate BETWEEN @discoverDateStart and @discoverDateEnd 
		)
		AND (
			(@resolutionDateStart IS NULL OR @resolutionDateEnd IS NULL)
			OR D.ResolvedDate BETWEEN @resolutionDateStart and @resolutionDateEnd 
		)
		AND (
			@includeResolved = 1
			or (
				@includeResolved = 0 
				-- AND ds.DiscrepancyStatus <> 'Resolved'
				-- and dc.DiscrepancyCategory <> 'Resolved' -- this should be taken from discrepancy category, if included
				and dc.DiscrepancyCategoryDisplay = 1
			)
		)

		AND
			(
				@varianceSign IS NULL

				or (
						@varianceSign = 1 

						and d.Variance > 0
				
					)

					or (
						
							@varianceSign = 0 

							and d.Variance < 0
				
					)
			)
        AND (
				@TypeRateCell is null
				OR d.TypeRateCell  = @TypeRateCell
		)
		AND (
				@TypeRegion is null
				OR d.TypeRegion  = @TypeRegion
		)
		AND (
				@TypePatientPay is null
				OR d.TypePatientPay  = @TypePatientPay	
		)
		AND (
				@TypePatientSpendDown is null
				OR d.TypePatientSpendDown = @TypePatientSpendDown 
		)
		AND (
				@TypePaymentError is null
				OR d.TypePaymentError  = @TypePaymentError
		)
		AND (
				@memberEnrollmentStatusId is null                                     -- IDS-374 changed case clause to MemberEnrollmentStatusId
				OR 
				m.MemberEnrollmentStatusId  =  @memberEnrollmentStatusId             
		)	
		AND (                                                                         -- IDS-375 
				@memberIsEnrolled is null
				OR  (
						@memberIsEnrolled = 1 and m.MemberEnrollmentStatusId  =  1 
					)
				OR  (
						@memberIsEnrolled = 0 and m.MemberEnrollmentStatusId  <> 1
					)             
		)	
					          		
/*
	, @resolutionDateStart	  date = NULL
	, @resolutionDateEnd	  date = NULL
	, @includeResolved        int = 0 -- 0: No; 1: Yes
*/

	IF (@exportAll = 1 )                  -- IDS-1051   @exportAll = 1: get resultset without pagination and sort
	BEGIN
		SELECT * FROM #TempResult
	END
	ELSE                                  -- IDS-1051   @exportAll = 0: get resultsetresultset with pagination and sort
	BEGIN	
		SELECT * FROM #TempResult
		
		-- how to achieve desired sort
		-- ORDER BY Variance DESC
		
		-- refrence: https://sqlperformance.com/2012/08/t-sql-queries/conditional-order-by
		ORDER BY 
			
		
			CASE WHEN @OrderBy = 0 -- ASC
				THEN
					CASE @SortBy
						WHEN  'MemberMonth'  THEN MemberMonth 
						/*ELSE MemberMonth -- is this appropraite*/
					END
			END,  
		
			CASE WHEN @OrderBy = 1 -- DESC
				THEN
					CASE @SortBy
						WHEN 'MemberMonth'   THEN MemberMonth 
						/*ELSE MemberMonth -- is this appropraite*/
					END
			END DESC,
		
		
			CASE WHEN @OrderBy = 0 -- ASC
				THEN
					CASE @SortBy
						WHEN  'DiscrepancyStatus'  THEN DiscrepancyStatus 
						/*ELSE MemberMonth -- is this appropraite*/
					END
			END,  
		
			CASE WHEN @OrderBy = 1 -- DESC
				THEN
					CASE @SortBy
						WHEN 'DiscrepancyStatus'   THEN DiscrepancyStatus 
						/*ELSE MemberMonth -- is this appropraite*/
					END
			END DESC,
		
		
			CASE WHEN @OrderBy = 0 -- ASC
				THEN
					CASE @SortBy
						WHEN 'Variance'   THEN Variance 
						ELSE Variance -- is this appropraite
					END
			END,  
		
			CASE WHEN @OrderBy = 1 -- DESC
				THEN
					CASE @SortBy
						WHEN 'Variance'   THEN Variance 
						ELSE Variance -- is this appropraite
					END
			END DESC
			, DiscrepancyID -- IDS - 983
		
		
		OFFSET (@pageSize * (@pageIndex)) ROWS
		FETCH NEXT @pageSize ROWS ONLY
	END
END

	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spGetDiscrepancyList] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetDiscrepancyList] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetDiscrepancyList] TO [webapp] 
GO
-- *****************************************************************************************************