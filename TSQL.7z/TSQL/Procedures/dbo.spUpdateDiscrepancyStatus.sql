
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spUpdateDiscrepancyStatus] 
PRINT @returnValue 


-- Full Example Test
DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spUpdateDiscrepancyStatus] 
	  @eventUserID = 2 
	, @DiscrepancyStatusID = 30
	, @DiscrepancyStatus = 'Homer Simpson'
	, @DiscrepancyCategoryID = 6
	, @DiscrepancyStatusDescription = 'all work and no play makes... someone something'
	, @ActiveFlag = 1 

	-- , @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @NewID
PRINT @RetCd

-- Confirm data tables updated appropriately
select * from DiscrepancyStatuses order by discrepancyStatusID desc
select * from ExecutionLog order by ExecutionLogID desc
select * from UserEventLog order by EventID desc

-- workaround possible API bug: update all descriptions to empty string
select * from discrepancystatuses where discrepancystatusDescription is null
update discrepancystatuses set discrepancystatusDescription = ''  where discrepancystatusDescription is null

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spUpdateDiscrepancyStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spUpdateDiscrepancyStatus]
GO

/****** Object:  StoredProcedure [dbo].[spUpdateDiscrepancyStatus]    Script Date: 08/20/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/20/2019
-- Description:	API
				Stored procedure for updating an existing DiscrepancyStatusID with new values
				Will preserve values if NULL or empty string is passed on "required" columns

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spUpdateDiscrepancyStatus]
	-- Add the parameters for the stored procedure here
	  @eventUserID int 
	, @DiscrepancyStatusID int 
	, @DiscrepancyStatus varchar(50) 
	, @DiscrepancyCategoryID int 
	, @DiscrepancyStatusDescription varchar(1000) = NULL
	-- , @DiscrepancyStatusType bit = NULL -- this should always be 1 for user entry
	, @ActiveFlag bit -- must be sent

	-- , @NewIdentity int output
	, @ReturnCode int output

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	-- DECLARE @NewIdentity int -- for create only
	-- DECLARE @ReturnCode int -- should this be an established standard
	DECLARE @EventOldData nvarchar(1000)
	DECLARE @EventNewData nvarchar(1000)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 0. Confirm appropriate values sent
	-- ******************************
	
	if not exists (
		select DiscrepancyStatusID 
		from DiscrepancyStatuses
		where DiscrepancyStatusID = @DiscrepancyStatusID 
	) 
		RAISERROR ('Discrepancy Status does not exist for passed: @DiscrepancyStatusID', 16, 1)



	-- ******************************
	-- STEP 1. Initialize EventResult Table
	-- ******************************


	if object_id('tempdb..#EventResult') is not null
		drop table #EventResult

	create table #EventResult (

		  DiscrepancyStatusID     int not null

		, old_DiscrepancyStatus             varchar(50) NULL
		, old_DiscrepancyStatusDescription  varchar(1000) NULL
		, old_DiscrepancyCategoryID         int NULL
		, old_DiscrepancyStatusType         bit NULL
		, old_ActiveFlag                    bit NULL		

		, new_DiscrepancyStatus             varchar(50) NULL
		, new_DiscrepancyStatusDescription  varchar(1000) NULL
		, new_DiscrepancyCategoryID         int NULL
		, new_DiscrepancyStatusType         bit NULL
		, new_ActiveFlag                    bit NULL		
		
	)


	-- ******************************
	-- STEP 2. Check if exact entry exists
	-- ******************************

	IF EXISTS (
		select DiscrepancyStatusID 
		from DiscrepancyStatuses
		where 
			    DiscrepancyStatus = @DiscrepancyStatus 
			and isnull(DiscrepancyStatusDescription,'') = isnull(@DiscrepancyStatusDescription, '')
			and DiscrepancyCategoryID = @DiscrepancyCategoryID 
			and ActiveFlag = @ActiveFlag
	)
		Set @ReturnCode = 1

	-- ******************************
	-- STEP 3. Update not exact match
	-- ******************************

	ELSE 
		BEGIN
			UPDATE DiscrepancyStatuses
				SET 
					  DiscrepancyStatus            = case when isnull(@DiscrepancyStatus 			, '') = '' then DiscrepancyStatus 			 else @DiscrepancyStatus 			end
					, DiscrepancyStatusDescription = case when isnull(@DiscrepancyStatusDescription	, '') = '' then DiscrepancyStatusDescription else @DiscrepancyStatusDescription	end	
					, DiscrepancyCategoryID        = case when @DiscrepancyCategoryID is null then DiscrepancyCategoryID 		 else @DiscrepancyCategoryID 		end
					-- , ActiveFlag                   = case when isnull(@ActiveFlag                   , '') = '' then ActiveFlag                   else @ActiveFlag                   end 
					, ActiveFlag = @ActiveFlag

					, updateDate                   = @spStart
			OUTPUT
				  inserted.DiscrepancyStatusID
				, deleted.DiscrepancyStatus 
				, deleted.DiscrepancyStatusDescription 
				, deleted.DiscrepancyCategoryID 
				, deleted.DiscrepancyStatusType
				, deleted.ActiveFlag 
				, inserted.DiscrepancyStatus 
				, inserted.DiscrepancyStatusDescription 
				, inserted.DiscrepancyCategoryID 
				, inserted.DiscrepancyStatusType
				, inserted.ActiveFlag 
				into #EventResult
			where 
				DiscrepancyStatusID = @DiscrepancyStatusID

			Set @ReturnCode = 2
		END 
	



	-- ******************************
	-- STEP 4. Event Log JSON preparation and storage
	-- ******************************

	select @EventOldData = '{
		     "DiscrepancyStatusID"          :'  + CAST(DiscrepancyStatusID               as varchar) 
		+ ', "DiscrepancyStatus" 		    :"' +      old_DiscrepancyStatus 		     + '"'
		+ ', "DiscrepancyStatusDescription" :"' +      old_DiscrepancyStatusDescription  + '"'
		+ ', "DiscrepancyCategoryID" 	    :'  + CAST(old_DiscrepancyCategoryID 		 as varchar) 
		+ ', "DiscrepancyStatusType"        :'  + CAST(old_DiscrepancyStatusType         as varchar) 
		
		+ ', "ActiveFlag"     :'  + case old_ActiveFlag when 0 then 'false' else 'true' end
		+ '}' 
	from #EventResult

	select @EventNewData = '{
		     "DiscrepancyStatusID"          :'  + CAST(DiscrepancyStatusID               as varchar) 
		+ ', "DiscrepancyStatus" 		    :"' +      new_DiscrepancyStatus 		     + '"'
		+ ', "DiscrepancyStatusDescription" :"' +      new_DiscrepancyStatusDescription  + '"'
		+ ', "DiscrepancyCategoryID" 	    :'  + CAST(new_DiscrepancyCategoryID 		 as varchar) 
		+ ', "DiscrepancyStatusType"        :'  + CAST(new_DiscrepancyStatusType         as varchar) 
		
		+ ', "ActiveFlag"     :'  + case new_ActiveFlag when 0 then 'false' else 'true' end
		+ '}' 
	from #EventResult

	EXEC spPutUserEventLog @eventUserID, @spProcName, @spStart, @ReturnCode, @EventOldData, @EventNewData




	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spUpdateDiscrepancyStatus] TO [Talend] 
GRANT EXECUTE ON [dbo].[spUpdateDiscrepancyStatus] TO [Support] 
GRANT EXECUTE ON [dbo].[spUpdateDiscrepancyStatus] TO [webapp] 
GO
-- *****************************************************************************************************