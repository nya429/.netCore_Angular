
USE [RevRec]
GO


/*
-- *****************************************************************************************************
-- Test Execution Block;

EXEC [dbo].[spGetRateCellMap] -- expected: entire list

EXEC [dbo].[spGetRateCellMap] 2, 'I2D', 'I2D2', 'SCO' -- expected: 1 match
EXEC [dbo].[spGetRateCellMap] 2, 'I2D', NULL, NULL  -- expected: two mappings
EXEC [dbo].[spGetRateCellMap] 2, NULL, 'I2D2', NULL -- expected: 1 match
EXEC [dbo].[spGetRateCellMap] 2, NULL, NULL, 'SCO' -- expected: all Items for 'SCO'
 							  
EXEC [dbo].[spGetRateCellMap] 2, 'I2D', 'I2D2', 'ICO' -- execpted: no matches (ICO filter prevents SCO lookup)
EXEC [dbo].[spGetRateCellMap] 2, NULL, NULL, 'ICO' -- expected: all items for 'ICO'

-- lookup via parameter names
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetRateCellMap] 

	--   @eventUserID int = NULL
	  @CCARateCell  = NULL -- 'I2D'
	, @MMISRateCell = NULL -- 'I2D2'
	, @Product      = NULL -- 'ICO' -- 'SCO'

	, @pageIndex    = 1
	, @pageSize     = 25
	, @sortBy       = 'RateCellMapID' 
	, @orderBy      = 1 -- 0: ASC; 1: DESC

PRINT @returnValue 


-- lookup via parameter names
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetRateCellMap] 

	--   @eventUserID int = NULL
	  @CCARateCell  = NULL -- 'I2D'
	, @MMISRateCell = NULL -- 'I2D2'
	, @Product      = NULL -- 'ICO' -- 'SCO'

	, @pageIndex    = 0
	, @pageSize     = 25
	, @sortBy       = NULL -- 'RateCellMapID' 
	, @orderBy      = 1 -- 0: ASC; 1: DESC

PRINT @returnValue 


exec [dbo].[spGetRateCellMap] @sortBy = 'MMISRateCell',  @orderBy = 0
exec [dbo].[spGetRateCellMap] @sortBy = 'garbage',  @orderBy = 0


-- from postman:
exec sp_executesql N'dbo.spGetRateCellMap @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7
',N'@p0 int,@p1 nvarchar(4000),@p2 nvarchar(4000),@p3 nvarchar(4000),@p4 int,@p5 int,@p6 nvarchar(4000),@p7 int',@p0=1,@p1=N'',@p2=N'',@p3=N'',@p4=0,@p5=25,@p6=N'',@p7=1


-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetRateCellMap]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetRateCellMap]
GO

/****** Object:  StoredProcedure [dbo].[spGetRateCellMap]    Script Date: 08/04/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/04/2019
-- Description:	API
				Gets Rate Cell Map between CCA Rate Cells and MMIS Rate Cells

				Post-QA 09/12/2019 
					* Need to include unmatched in results

				Post Unit-test 10/10/2019
					Corrected for using wrong execution log


-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetRateCellMap]
	-- Add the parameters for the stored procedure here
	  @eventUserID int = NULL
	, @CCARateCell varchar(50) = NULL
	, @MMISRateCell varchar(50) = NULL
	, @Product    char(3) = NULL 

	-- maybe move hardcoding into stored procedure, then can check for isnull values
	, @pageIndex int		  = 0
	, @pageSize int			  = 25
	, @sortBy varchar(50)	  = NULL 
	, @orderBy int            = 0 -- 0: ASC; 1: DESC

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	DECLARE @sqlStatement varchar(max)
	DECLARE @sqlWhere varchar(max)

	DECLARE @defaultSort varchar(50) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = ('defaultSort_' + OBJECT_NAME(@@PROCID)))
	

-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 

	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)


	-- ******************************
	-- STEP 1. (base query) Get Rate Cell Map based on the parameter list sent 
	-- ******************************

	set @sqlStatement = '
		select 
			  m.RateCellMapID	
			, m.CCARateCellID	
			, C.CCARateCell
			, C.Product as CCAProduct
			, s.MMISRateCellID	
			, S.MMISRateCell
			, S.Product as MMISProduct
			, m.ActiveFlag	
			, m.insertDate	
			, m.updateDate
			, count(*) over() as ResultCount -- generic for all multi-line get procedures
		from RateCellMap AS m
		inner join MMISRateCells as s on s.MMISRateCellID = M.MMISRateCellID
		left join CCARateCells as c on C.CCARateCellID =  M.CCARateCellID
	'

	-- ******************************
	-- STEP 2. Set where clause based on filters passed.  Have to check each one for when to insert where clause?
	-- ******************************

	IF ISNULL(@CCARateCell, '') <> ''
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + 'C.CCARateCell = ''' + @CCARateCell + ''''
	END 

	IF ISNULL(@MMISRateCell, '') <> ''
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + 'S.MMISRateCell = ''' + @MMISRateCell + ''''
	END 

	IF ISNULL(@Product, '') <> ''
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + 's.Product  = ''' + @Product + ''''
	END 



	IF @sqlWhere IS NOT NULL 
		SET @sqlStatement = @sqlStatement + @sqlWhere
	

	-- ******************************
	-- STEP 3. Set order by
	-- ******************************

	-- Check valid columns, otherwise, use default sort... need null check as a separate condition
	if isnull(@sortBy,'') = '' or @sortBy not in (
		      'RateCellMapID'	
			, 'CCARateCellID'
			, 'CCARateCell'
			, 'CCAProduct'
			, 'MMISRateCellID'
			, 'MMISRateCell'
			, 'MMISProduct'
			, 'Active'
		)
		
		set @sortBy = @defaultSort -- may need to check this 


	set @sqlStatement = @sqlStatement + '
		ORDER BY ' + @sortBy + ' ' + CASE @orderBy WHEN 1 THEN 'DESC' ELSE '' END 
		

	-- ******************************
	-- STEP 4. Set pagination, if available
	-- ******************************


	-- FIX THIS
	-- if @pageSize  = '' SET @pageSize  = NULL
	-- if @pageIndex = '' SET @pageIndex = NULL

	-- print @pageSize  
	-- print @pageIndex 


	if (isnumeric(@pageSize) = 1 and isnumeric(@pageIndex) = 1)
		set @sqlStatement = @sqlStatement + '
			OFFSET (' + cast(@pageSize as varchar) + ' * (' + cast(@pageIndex as varchar) + ')) ROWS
			FETCH NEXT ' + cast(@pageSize as varchar) + ' ROWS ONLY;
		'


	-- ******************************
	-- STEP 5. Execute dynamic statement
	-- ******************************


	print @sqlStatement

	exec(@sqlStatement)



	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************

	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()

		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart

		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spGetRateCellMap] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetRateCellMap] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetRateCellMap] TO [WebApp] 
GO
-- *****************************************************************************************************