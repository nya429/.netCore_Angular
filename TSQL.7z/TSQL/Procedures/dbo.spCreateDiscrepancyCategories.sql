
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spCreateDiscrepancyCategories] 
PRINT @returnValue 

-- new test
-- Full Example Test
DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spCreateDiscrepancyCategories] 
	  @eventUserID = 2 
	, @DiscrepancyCategory = 'XFiles4' 
	, @DiscrepancyCategoryDescription = NULL -- 'Trust No one'
	, @ActiveFlag = 1 

	, @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @NewID
PRINT @RetCd

-- Confirm data tables updated appropriately
select * from DiscrepancyCategories
select * from ExecutionLog order by ExecutionLogID desc
select * from UserEventLog order by EventID desc

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spCreateDiscrepancyCategories]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spCreateDiscrepancyCategories]
GO

/****** Object:  StoredProcedure [dbo].[spCreateDiscrepancyCategories]    Script Date: 08/22/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/22/2019
-- Description:	API
				Stored procedure for creating a new discrepancy status
				

-- Modified by: Yue Song
-- Modified dt: 5/20/2020
-- Description: IDS-1477 - Added DiscrepancyCategoryIsResolved used as Discrepancy Resolved flag. 
                It's not exposed to UI temprarily and it will be created based on discrepancyCategory input

				IDS-1501 - DiscrepancyCategories Table had new column DiscrepancyCategoryAddStatus added,  no corresponding field added in creation proc.  

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spCreateDiscrepancyCategories]
	-- Add the parameters for the stored procedure here
	  @eventUserID int 
	, @DiscrepancyCategory varchar(50) 
	, @DiscrepancyCategoryDescription varchar(1000) = NULL
	, @DiscrepancyCategoryDisplay bit = 1
	, @ActiveFlag bit = 1 

	, @NewIdentity int output
	, @ReturnCode int output


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	-- DECLARE @NewIdentity int -- for create only
	-- DECLARE @ReturnCode int -- should this be an established standard
	DECLARE @EventOldData nvarchar(1000)
	DECLARE @EventNewData nvarchar(1000)
	
	 -- IDS-1501
    
	DECLARE @DiscrepancyCategoryAddStatus   bit = CASE
											      WHEN     LOWER(@DiscrepancyCategory) = 'resolved' 
														or LOWER(@DiscrepancyCategory) = 'new' 
												  THEN 0 ELSE 1 END

    -- IDS-1477
	DECLARE @DiscrepancyCategoryIsResolved  bit = CASE LOWER(@DiscrepancyCategory) WHEN  'resolved' THEN 1 ELSE 0 END
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Initialize EventResult Table
	-- ******************************


	if object_id('tempdb..#EventResult') is not null
		drop table #EventResult

	create table #EventResult (

		  DiscrepancyCategoryID     int not null

		, new_DiscrepancyCategory             varchar(50) NULL
		, new_DiscrepancyCategoryDescription  varchar(1000) NULL
		, new_DiscrepancyCategoryDisplay      bit NULL
		, new_ActiveFlag                      bit NULL		
		
	)

	-- ******************************
	-- STEP 2. Check if unique entry exists
	-- ******************************

	IF EXISTS (
		select DiscrepancyCategoryID 
		from DiscrepancyCategories
		where 
			    DiscrepancyCategory            = @DiscrepancyCategory            
			and DiscrepancyCategoryDescription = @DiscrepancyCategoryDescription 
			and DiscrepancyCategoryDisplay     = @DiscrepancyCategoryDisplay     
			and ActiveFlag = @ActiveFlag
	)
		set @ReturnCode = 1

	-- ******************************
	-- STEP 3. Insert new if does not exist
	-- ******************************

	ELSE
		BEGIN
			INSERT INTO DiscrepancyCategories (
				  DiscrepancyCategory          
				, DiscrepancyCategoryDescription
				, DiscrepancyCategoryDisplay    
				-- IDS-1501
				, DiscrepancyCategoryAddStatus
				, ActiveFlag 
				, insertDate        
				, updateDate       
				-- IDS-1477
				, DiscrepancyCategoryIsResolved  
			) 
			OUTPUT
				  inserted.DiscrepancyCategoryID
				, inserted.DiscrepancyCategory 
				, inserted.DiscrepancyCategoryDescription 
				, inserted.DiscrepancyCategoryDisplay 
				, inserted.ActiveFlag 
				into #EventResult
			VALUES (
				  @DiscrepancyCategory          	  -- DiscrepancyCategory          
				, @DiscrepancyCategoryDescription  -- DiscrepancyCategoryDescription
				, @DiscrepancyCategoryDisplay      -- DiscrepancyCategoryDisplay  
				-- IDS-1501
				, @DiscrepancyCategoryAddStatus  
				
				, @ActiveFlag -- ActiveFlag 
				, @spStart -- insertDate
				, @spStart -- updateDate        
				
				-- IDS-1477
				, @DiscrepancyCategoryIsResolved   -- DiscrepancyCategoryIsResolved   
			)

			set @NewIdentity = @@identity
			set @ReturnCode = 3
	END 


	-- ******************************
	-- STEP 4. Event Log JSON preparation and storage
	-- ******************************

	select @EventNewData = '{
		     "DiscrepancyCategoryID"          :'  + CAST(DiscrepancyCategoryID               as varchar) 
		+ ', "DiscrepancyCategory" 		      :"' + CAST(new_DiscrepancyCategory 		     as varchar) + '"'
		+ ', "DiscrepancyCategoryDescription" :"' + CAST(isnull(new_DiscrepancyCategoryDescription,'')  as varchar) + '"'
		+ ', "DiscrepancyCategoryDisplay"     :'  + case new_DiscrepancyCategoryDisplay when 0 then 'false' else 'true' end
		+ ', "ActiveFlag"     :'  + case new_ActiveFlag when 0 then 'false' else 'true' end
		+ '}' 
	from #EventResult


	EXEC spPutUserEventLog @eventUserID, @spProcName, @spStart, @ReturnCode, @EventOldData, @EventNewData


	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spCreateDiscrepancyCategories] TO [Talend] 
GRANT EXECUTE ON [dbo].[spCreateDiscrepancyCategories] TO [Support] 
GRANT EXECUTE ON [dbo].[spCreateDiscrepancyCategories] TO [webapp] 
GO
-- *****************************************************************************************************