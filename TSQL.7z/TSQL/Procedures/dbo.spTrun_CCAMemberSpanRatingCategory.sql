
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spTrun_CCAMemberSpanRatingCategory] 
PRINT @returnValue 

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spTrun_CCAMemberSpanRatingCategory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spTrun_CCAMemberSpanRatingCategory]
GO

/****** Object:  StoredProcedure [dbo].[spTrun_CCAMemberSpanRatingCategory]    Script Date: 09/07/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		
-- Create date: 09/07/2019
-- Truncates:	CCAMemberSpanRatingCategory
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spTrun_CCAMemberSpanRatingCategory]
WITH EXECUTE AS 'dbo'


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- DECLARE @CCAMemberSpanRatingCategory varchar(100) = '[dbo].[spTrun_CCAMemberSpanRatingCategory]'
	
	TRUNCATE TABLE [dbo].[CCAMemberSpanRatingCategory]

END
GO

-- No additional permissions should be needed.  spTrun should be called from within another stored procedure with appropriate permissions



-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spTrun_CCAMemberSpanRatingCategory] TO [Talend] 
GRANT EXECUTE ON [dbo].[spTrun_CCAMemberSpanRatingCategory] TO [Support] 
GO
-- *****************************************************************************************************
