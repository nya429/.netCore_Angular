
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessValidation_SpanEnrollment] 
PRINT @returnValue 

-- unit test
select top 100 * from CCAMemberSpanEnrollment
where ccaid = 5364524640

-- mimic bad data
insert into CCAMemberSpanEnrollment (
	CCAID	
	Product	
	EnrollStartDate	
	EnrollEndDate
)
values (
	5364524640	
	, 'ICO'	
	, '2018-08-01'
	, NULL
)


-- validation
select * 
from ValidationLog as vl
where RevRecSectionType = 'Member Enrollment Span'
ORDER BY VALIDATIONLOGID DESC


select distinct RevRecSectionType 
from ValidationLog as vl

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spProcessValidation_SpanEnrollment]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spProcessValidation_SpanEnrollment]
GO

/****** Object:  StoredProcedure [dbo].[spProcessValidation_SpanEnrollment]    Script Date: 01/02/2020 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 01/07/2020
-- Description:	ADS-2915 (Release ADS-2980)
				Validates the spans are distinct

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spProcessValidation_SpanEnrollment]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	DECLARE @OpenEndDate date = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'OpenEndDate')
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)


	-- ******************************
	-- STEP 1. State insert statement with column headers.  "Union All" each result set to perform the insert.  Should ensure consistency in header usage
	-- ******************************
	
	
	-- DECLARE @spStart datetime2(3) = getdate(), @OpenEndDate date = '2999-12-31'
	insert into ValidationLog (
		  RevRecSectionType 
		, RevRecTable 
		, TableId 
		, ValidationColumn 
		, ValidationValue 
		, ValidationErrorDescription 

		-- could consider having a "table" of these values to join so not to include in each union select
		, ActiveFlag 
		, insertDate 
		, updateDate 
	)	
	
	-- ******************************
	-- STEP 2. Validate if there are multiple spans for the same start date
	-- ******************************
	
	-- DECLARE @spStart datetime2(3) = getdate()
	select
		  'Member Enrollment Span' AS RevRecSectionType 
		, 'CCAMemberSpanEnrollment' AS RevRecTable 
		, r.CCAMemberSpanEnrollID AS TableId 
		, 'EnrollStartDate' AS ValidationColumn 
		, r.EnrollStartDate AS ValidationValue 
		, 'Duplicate Start Dates' as ValidationErrorDescription 

		, 1 as ActiveFlag 
		, @spStart as insertDate 
		, @spStart as updateDate 
	
		-- debug, leave commented for execution:
		-- , r.Enrollment
	from CCAMemberSpanEnrollment as r
	where exists (
		select 
			rdup.CCAID
			, rdup.EnrollStartDate
			, count(*) as dupCheck
		from CCAMemberSpanEnrollment as rdup

		where rdup.CCAID = r.CCAID
			and rdup.EnrollStartDate = r.EnrollStartDate
			and rdup.Product is not null
		group by rdup.CCAID
			, rdup.EnrollStartDate
		having count(*) > 1

	)


	-- ******************************
	-- STEP 3. Validate if there are multiple spans for the same end date
	-- ******************************
	
	UNION ALL

	-- DECLARE @spStart datetime2(3) = getdate(), @OpenEndDate date = '2999-12-31'
	select
		  'Member Enrollment Span' AS RevRecSectionType 
		, 'CCAMemberSpanEnrollment' AS RevRecTable 
		, r.CCAMemberSpanEnrollID AS TableId 
		, 'EnrollEndDate' AS ValidationColumn 
		, r.EnrollEndDate AS ValidationValue 
		, 'Duplicate End Dates' as ValidationErrorDescription 

		, 1 as ActiveFlag 
		, @spStart as insertDate 
		, @spStart as updateDate 
	
		-- debug, leave commented for execution:
		-- , r.Enrollment
	from CCAMemberSpanEnrollment as r
	where exists (
		-- DECLARE @spStart datetime2(3) = getdate(), @OpenEndDate date = '2999-12-31'
		select 
			rdup.CCAID
			, rdup.EnrollEndDate
			, count(*) as dupCheck
		from CCAMemberSpanEnrollment as rdup

		where rdup.CCAID = r.CCAID
			and isnull(rdup.EnrollEndDate, @OpenEndDate) = isnull(r.EnrollEndDate, @OpenEndDate)
			and rdup.Product is not null
		group by rdup.CCAID
			, rdup.EnrollEndDate
		having count(*) > 1

	)

	-- ******************************
	-- STEP 4. Handle overlapping dates
	-- ******************************
	
	UNION ALL

	-- DECLARE @spStart datetime2(3) = getdate(), @OpenEndDate date = '2999-12-31'
	select
		  'Member Enrollment Span' AS RevRecSectionType 
		, 'CCAMemberSpanEnrollment' AS RevRecTable 
		, r.CCAMemberSpanEnrollID AS TableId 
		, 'EnrollStartDate' AS ValidationColumn 
		, r.EnrollStartDate AS ValidationValue 
		, 'Overlapping Start and End Date' as ValidationErrorDescription 

		, 1 as ActiveFlag 
		, @spStart as insertDate 
		, @spStart as updateDate 
	
		-- debug, leave commented for execution:
		-- , r.Enrollment
	from CCAMemberSpanEnrollment as r
	where exists (
		-- DECLARE @spStart datetime2(3) = getdate(), @OpenEndDate date = '2999-12-31'
		select 
			rovr.CCAID
			, rovr.EnrollEndDate
		from CCAMemberSpanEnrollment as rovr

		where rovr.CCAID = r.CCAID
			and rovr.EnrollStartDate <> r.EnrollStartDate
			and isnull(rovr.EnrollEndDate, @OpenEndDate) <> isnull(r.EnrollEndDate, @OpenEndDate)
			and (
				r.EnrollStartDate BETWEEN rovr.EnrollStartDate AND isnull(rovr.EnrollEndDate, @OpenEndDate)
				OR r.EnrollEndDate BETWEEN rovr.EnrollStartDate AND isnull(rovr.EnrollEndDate, @OpenEndDate)
			)

	)



	-- ******************************
	-- STEP 5. Clear invalid data from the source table
	-- ******************************

	update r
		set ActiveFlag = 0
		, updateDate = @spStart
	-- DECLARE @spStart datetime2(3) = (select max(insertDate) as MaxInsertDate from ValidationLog) select *
	from CCAMemberSpanEnrollment as r
	where exists (
		select TableId
		from ValidationLog as vl
		where RevRecSectionType = 'Member Enrollment Span'
		and insertDate = @spStart
		and vl.TableId = r.CCAMemberSpanEnrollID
	)







	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spProcessValidation_SpanEnrollment] TO [Talend] 
GRANT EXECUTE ON [dbo].[spProcessValidation_SpanEnrollment] TO [Support] 
GO
-- *****************************************************************************************************