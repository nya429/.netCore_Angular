
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessDiscrepancies] 
PRINT @returnValue 


SELECT * FROM [dbo].[Discrepancies]
-- where CCAPatientPay	is not NULL or CCAPatientSpendDown is not NULL
select * from executionLog order by executionLogID DESC

-- validate singular results
select MasterPatientID, MemberMonth, count(*) as dupCheck 
from Discrepancies 
where insertdate > '2019-09-25'
group by MasterPatientID, MemberMonth having count(*) > 1 
order by dupCheck desc, MasterPatientID

select * 
from discrepancies
where MasterPatientID	= 3029	
and MemberMonth = '2019-06-01'

select * 
from MonthlySummaryRecord
where MasterPatientID	= 3029	
and MemberMonth = '2019-06-01'

delete from discrepancies where insertdate > '2019-09-24'

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spProcessDiscrepancies]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spProcessDiscrepancies]
GO

/****** Object:  StoredProcedure [dbo].[spProcessDiscrepancies]    Script Date: 08/24/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/24/2019
-- Description:	Builds/resolves discrepancy records via monthly summary record.

				Post unit-test 10/11/2019
					Removed "worked" from re-open when discrepancies are "refound".  Could still be pending action

				Post unit-test 10/14/2019 
					Corrected updated of discrepancy status for comparison of discrepancyStatusIDs (was improperly comparing DiscrepancyID)
					Also removed condition of ignoring resolved DiscrepancyStatusID

				Post QA 10/16/2019
					removed check for CCARateCardID... this does not have to be available to identify a discrepancy.
					Added comparison for discrepancy type based upon raw values for more accurate insight
					Altered criteria for when an update is run
					Added considerations for including "raw" ratecells and regions when missing from rate card


-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spProcessDiscrepancies]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	

	-- SELECT * FROM DiscrepancyStatuses
	-- SELECT * FROM DiscrepancyCategories

	DECLARE @processMonth date

	-- get status IDs for system statuses 
	DECLARE @newStatusID	  int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'New') 
	DECLARE @reopenStatusID   int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Reopen') 
	DECLARE @pendingStatusID int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Pending')
	DECLARE @workingStatusID int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Working')
	DECLARE @completeStatusID int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Complete')
	DECLARE @resolvedStatusID int = (select discrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = 'Resolved')
	
	
	
	 
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	
	-- ******************************
	-- STEP 1. Insert new discrepancies by comparison to member's current status, where member/month entry does not currently exist in discrepancies
	-- ******************************

	insert into Discrepancies (
		MonthlySummaryRecordID
		, MasterPatientID 
		, MemberMonth 

		, Variance 
	
		-- Payment error SHOULD NOT be part of the variance calculation
		, PaymentError 

		-- from PatientPayDetail... what the state actually says they paid, based on file
		, BaseCapitationAmount	
		, PatientPayAmountN		
		, PatientPayAmountSCO	
		, PaidCapitationAmount	
	

		, CCARateCellID 
		, CCARegionID 
		, CCAPatientPay 
		, CCAPatientSpendDown 

		-- CCA's expected based on current member's rate cell and region in MP
		, CCARateCardID 
		, CCAAmount 
		, CCANetAmount 
		
		, MMISRateCellID 
		, MMISRegionID 
		, MMISPatientPay 
		, MMISPatientSpendDown 
	
		-- expected payment based on state's rate rate cell and region
		, MMISRateCardID 
		, MMISAmount 
		, MMISNetAmount 

		-- this relates to be the actual values, both CCA and MMIS keys and amounts
		, TypeRateCell 
		, TypeRegion 
		, TypePatientPay 
		, TypePatientSpendDown 
		, TypePaymentError 

		-- status columns
		, Assigned_UserID 
		, Action_UserID 
		, DiscrepancyStatusID 
		, DueDate 
		, DiscoverDate -- will match insert date, unless re-opened, then will reflect the initial re-open date; will use for aging
		, ResolvedDate -- only when a designated resolved system status/balanced bit is used; re-open, this date is cleared
		, Balanced -- will consider this for system marking complete/resolved 

		, rawMMISRateCell 
		, rawMMISRegion   
		, rawCCARateCell  
		, rawCCARegion    

		, ActiveFlag 
		, insertDate -- this can translate to discover date
		, updateDate -- could possibly used as resolution date via history in combination with the status

	)
	select 
		  msr.MonthlySummaryRecordID
		, msr.MasterPatientID 
		, msr.MemberMonth 

		, msr.Variance 
	
		-- Payment error SHOULD NOT be part of the variance calculation
		, msr.PaymentError 

		-- from PatientPayDetail... what the state actually says they paid, based on file
		, msr.BaseCapitationAmount	
		, msr.PatientPayAmountN		
		, msr.PatientPayAmountSCO	
		, msr.PaidCapitationAmount	
	

		, msr.CCARateCellID 
		, msr.CCARegionID 
		, msr.CCAPatientPay 
		, msr.CCAPatientSpendDown 

		-- CCA's expected based on current member's rate cell and region in MP
		, msr.CCARateCardID 
		, msr.CCAAmount 
		, msr.CCANetAmount 
		
		, msr.MMISRateCellID 
		, msr.MMISRegionID 
		, msr.MMISPatientPay 
		, msr.MMISPatientSpendDown 
	
		-- expected payment based on state's rate rate cell and region
		, msr.MMISRateCardID 
		, msr.MMISAmount 
		, msr.MMISNetAmount 

		-- this relates to be the actual values, both CCA and MMIS keys and amounts
		, case when isnull(msr.CCARateCellID, 0) <> isnull(msr.MMISRateCellID , 0) or isnull(msr.rawCCARateCell, '99') <> isnull(msr.rawMMISRateCell, '99') then 1 else 0 end as TypeRateCell 
		, case when isnull(msr.CCARegionID  , 0) <> isnull(msr.MMISRegionID   , 0) or isnull(msr.rawCCARegion, 'NA')   <> isnull(msr.rawMMISRegion, 'NA') then 1 else 0 end as TypeRegion 
		, case when isnull(msr.CCAPatientPay      , 0.00) <> isnull(msr.MMISPatientPay      , 0.00) then 1 else 0 end as TypePatientPay 
		, case when isnull(msr.CCAPatientSpendDown, 0.00) <> isnull(msr.MMISPatientSpendDown, 0.00) then 1 else 0 end as TypePatientSpendDown 
		, case when isnull(msr.PaymentError, 0.00) <> 0.00 then 1 else 0 end as TypePaymentError 

		-- status columns
		, NULL AS Assigned_UserID 
		, NULL AS Action_UserID 
		, @newStatusID as DiscrepancyStatusID 
		, NULL AS DueDate 
		, @spStart AS DiscoverDate -- will match insert date, unless re-opened, then will reflect the initial re-open date; will use for aging
		, NULL AS ResolvedDate -- only when a designated resolved system status/balanced bit is used; re-open, this date is cleared
		, NULL AS Balanced -- will consider this for system marking complete/resolved 

		, msr.rawMMISRateCell 
		, msr.rawMMISRegion   
		, msr.rawCCARateCell  
		, msr.rawCCARegion    

		, 1 as ActiveFlag
		, @spStart as insertDate
		, @spStart as updateDate

	-- select * from PatientPayDetail
	from MonthlySummaryRecord as msr
	where (
			(msr.Variance is not null and msr.Variance <> 0.00)
			or (msr.PaymentError is not null and msr.PaymentError <> 0.00)
		)
		and not exists (
			select DiscrepancyID 
			from Discrepancies as d
			where d.MasterPatientID = msr.MasterPatientID
				and d.MemberMonth = msr.MemberMonth
		)
		-- FOR TESTING
		-- and msr.CCARateCellID is not null

	/*
	-- should these details be part of the member summary view
	select top 10 md.*
	-- , rc.CCARateCellID, reg.CCARegionID 
	-- , rc.CCARateCell, reg.CCARegion
	from vwCCAMemberData as md
	where 
	*/


	-- ******************************
	-- STEP 2. Update Existing 
	-- ******************************

	update d
		set
			MonthlySummaryRecordID = msr.MonthlySummaryRecordID
			, Variance = msr.Variance
			, PaymentError = msr.PaymentError
			, BaseCapitationAmount	= msr.BaseCapitationAmount
			, PatientPayAmountN		= msr.PatientPayAmountN
			, PatientPayAmountSCO	= msr.PatientPayAmountSCO
			, PaidCapitationAmount	= msr.PaidCapitationAmount
	

			, CCARateCellID         = msr.CCARateCellID
			, CCARegionID 			= msr.CCARegionID 			
			, CCAPatientPay 		= msr.CCAPatientPay 		
			, CCAPatientSpendDown 	= msr.CCAPatientSpendDown 	

			-- CCA's expected based on current member's rate cell and region in MP
			, CCARateCardID         = msr.CCARateCardID         
			, CCAAmount 			= msr.CCAAmount 			
			, CCANetAmount 			= msr.CCANetAmount 			
		
			, MMISRateCellID        = msr.MMISRateCellID      
			, MMISRegionID 			= msr.MMISRegionID 			
			, MMISPatientPay 		= msr.MMISPatientPay 		
			, MMISPatientSpendDown 	= msr.MMISPatientSpendDown
	
			-- expected payment based on state's rate rate cell and region
			, MMISRateCardID        = msr.MMISRateCardID        
			, MMISAmount 			= msr.MMISAmount 			
			, MMISNetAmount 		= msr.MMISNetAmount 		

			, TypeRateCell          = case when isnull(msr.CCARateCellID, 0) <> isnull(msr.MMISRateCellID , 0) or isnull(msr.rawCCARateCell, '99') <> isnull(msr.rawMMISRateCell, '99') then 1 else 0 end  
			, TypeRegion 			= case when isnull(msr.CCARegionID  , 0) <> isnull(msr.MMISRegionID   , 0) or isnull(msr.rawCCARegion, 'NA')   <> isnull(msr.rawMMISRegion, 'NA') then 1 else 0 end 
			, TypePatientPay 		= case when isnull(msr.CCAPatientPay      , 0.00) <> isnull(msr.MMISPatientPay      , 0.00) then 1 else 0 end 
			, TypePatientSpendDown 	= case when isnull(msr.CCAPatientSpendDown, 0.00) <> isnull(msr.MMISPatientSpendDown, 0.00) then 1 else 0 end 

			/*
			-- this relates to be the actual values, both CCA and MMIS keys and amounts
			, TypeRateCell          = case when msr.CCARateCellID <> msr.MMISRateCellID then 1 else 0 end 
			, TypeRegion 			= case when msr.CCARegionID <> msr.MMISRegionID then 1 else 0 end 
			, TypePatientPay 		= case when msr.CCAPatientPay <> msr.MMISPatientPay then 1 else 0 end 
			, TypePatientSpendDown 	= case when msr.CCAPatientSpendDown <> msr.MMISPatientSpendDown then 1 else 0 end 
			*/
			, TypePaymentError 		= case when isnull(msr.PaymentError, 0.00) <> 0.00 then 1 else 0 end 

			, rawMMISRateCell = msr.rawMMISRateCell 
			, rawMMISRegion   = msr.rawMMISRegion   
			, rawCCARateCell  = msr.rawCCARateCell  
			, rawCCARegion    = msr.rawCCARegion    

			-- status columns
			, DiscrepancyStatusID 	= case 
				-- reopen when 'resolved'... reopening working will have to be reconsidered
				when (isnull(msr.Variance,0.00) <> 0.00 or isnull(msr.PaymentError, 0.00) <> 0.00) and DiscrepancyStatusID in (@resolvedStatusID)
					then @reopenStatusID
				-- mark 'resolved' when variance/payment error is $0.00 
				when (isnull(msr.Variance,0.00) = 0.00 and isnull(msr.PaymentError, 0.00) = 0.00) and DiscrepancyStatusID <> @resolvedStatusID
					then @resolvedStatusID
				else DiscrepancyStatusID
				end
																												 
			, ResolvedDate          = case 
				-- reopen when 'working' or 'resolved'
				when (isnull(msr.Variance,0.00) <> 0.00 or isnull(msr.PaymentError, 0.00) <> 0.00) and DiscrepancyStatusID in (@resolvedStatusID)
				then cast(NULL as date)

				-- mark 'resolved' when variance/payment error is $0.00 
				when (isnull(msr.Variance,0.00) = 0.00 and isnull(msr.PaymentError, 0.00) = 0.00) and DiscrepancyStatusID <> @resolvedStatusID
					--then cast(NULL as date)
					then @spStart 
				else ResolvedDate
			end 
			, Balanced              = case 
				-- mark "un"balanced when reopening
				when (isnull(msr.Variance,0.00) <> 0.00 or isnull(msr.PaymentError, 0.00) <> 0.00) and DiscrepancyStatusID in (@resolvedStatusID)
					then 0 
				-- mark balanced when resolved
				when (isnull(msr.Variance,0.00) = 0.00 and isnull(msr.PaymentError, 0.00) = 0.00) and DiscrepancyStatusID <> @resolvedStatusID
					then 1
				else Balanced
			end
			, updateDate = @spStart 
			
	from Discrepancies as d
	inner join MonthlySummaryRecord as msr 
		on msr.MasterPatientID = d.MasterPatientID 
		and msr.MemberMonth = d.MemberMonth
	-- where d.DiscrepancyStatusID <> @resolvedStatusID
	-- condition to avoid updating all discrepancies
	where (
			   d.Variance               <> msr.Variance
			or d.PaymentError           <> msr.PaymentError
			or d.BaseCapitationAmount	<> msr.BaseCapitationAmount
			or d.PatientPayAmountN		<> msr.PatientPayAmountN
			or d.PatientPayAmountSCO	<> msr.PatientPayAmountSCO
			or d.PaidCapitationAmount	<> msr.PaidCapitationAmount
	

			or d.CCARateCellID          <> msr.CCARateCellID
			or d.CCARegionID 			<> msr.CCARegionID 			
			or d.CCAPatientPay 		    <> msr.CCAPatientPay 		
			or d.CCAPatientSpendDown 	<> msr.CCAPatientSpendDown 	

			-- CCA's expected based on current member's rate cell and region in MP
			or d.CCARateCardID          <> msr.CCARateCardID         
			or d.CCAAmount 			    <> msr.CCAAmount 			
			or d.CCANetAmount 			<> msr.CCANetAmount 			
		
			or d.MMISRateCellID         <> msr.MMISRateCellID      
			or d.MMISRegionID 			<> msr.MMISRegionID 			
			or d.MMISPatientPay 		<> msr.MMISPatientPay 		
			or d.MMISPatientSpendDown 	<> msr.MMISPatientSpendDown

			-- *************************************************
			-- can we leave this out of the update?
			or d.TypeRateCell           <> case when isnull(msr.CCARateCellID, 0) <> isnull(msr.MMISRateCellID , 0) or isnull(msr.rawCCARateCell, '99') <> isnull(msr.rawMMISRateCell, '99') then 1 else 0 end  
			or d.TypeRegion 			<> case when isnull(msr.CCARegionID  , 0) <> isnull(msr.MMISRegionID   , 0) or isnull(msr.rawCCARegion, 'NA')   <> isnull(msr.rawMMISRegion, 'NA') then 1 else 0 end 
			or d.TypePatientPay 		<> case when isnull(msr.CCAPatientPay      , 0.00) <> isnull(msr.MMISPatientPay      , 0.00) then 1 else 0 end 
			or d.TypePatientSpendDown 	<> case when isnull(msr.CCAPatientSpendDown, 0.00) <> isnull(msr.MMISPatientSpendDown, 0.00) then 1 else 0 end 
			or d.TypePaymentError 		<> case when isnull(msr.PaymentError, 0.00) <> 0.00 then 1 else 0 end 
			-- *************************************************

			
			-- should we update on raw matches?  should only be necessary if another element is changed.
			-- *************************************************
			or isnull(d.rawMMISRateCell , '') <> msr.rawMMISRateCell 
			or isnull(d.rawMMISRegion   , '') <> msr.rawMMISRegion   
			or isnull(d.rawCCARateCell  , '') <> msr.rawCCARateCell  
			or isnull(d.rawCCARegion    , '') <> msr.rawCCARegion    
			-- *************************************************
	)


	-- ******************************
	-- STEP 3. Insert into status history, too
	-- ******************************

		INSERT INTO DiscrepanciesHistory(
			DiscrepancyID
			,MonthlySummaryRecordID
			,MasterPatientID
			,MemberMonth
			,Variance
			,PaymentError
			,BaseCapitationAmount
			,PatientPayAmountN
			,PatientPayAmountSCO
			,PaidCapitationAmount
			,CCARateCellID
			,CCARegionID
			,CCAPatientPay
			,CCAPatientSpendDown
			,CCARateCardID
			,CCAAmount
			,CCANetAmount
			,MMISRateCellID
			,MMISRegionID
			,MMISPatientPay
			,MMISPatientSpendDown
			,MMISRateCardID
			,MMISAmount
			,MMISNetAmount
			,TypeRateCell
			,TypeRegion
			,TypePatientPay
			,TypePatientSpendDown
			,TypePaymentError
			,Assigned_UserID
			,Action_UserID
			,DiscrepancyStatusID
			,DueDate
			,DiscoverDate
			,ResolvedDate
			,Balanced
			,Discrepancy_ActiveFlag
			,Discrepancy_insertDate
			,Discrepancy_updateDate
			,rawMMISRateCell 
			,rawMMISRegion   
			,rawCCARateCell  
			,rawCCARegion    
			,ActiveFlag  
			,insertDate  
			,updateDate  
		) 
		select 
			d.DiscrepancyID
			,d.MonthlySummaryRecordID
			,d.MasterPatientID
			,d.MemberMonth
			,d.Variance
			,d.PaymentError
			,d.BaseCapitationAmount
			,d.PatientPayAmountN
			,d.PatientPayAmountSCO
			,d.PaidCapitationAmount
			,d.CCARateCellID
			,d.CCARegionID
			,d.CCAPatientPay
			,d.CCAPatientSpendDown
			,d.CCARateCardID
			,d.CCAAmount
			,d.CCANetAmount
			,d.MMISRateCellID
			,d.MMISRegionID
			,d.MMISPatientPay
			,d.MMISPatientSpendDown
			,d.MMISRateCardID
			,d.MMISAmount
			,d.MMISNetAmount
			,d.TypeRateCell
			,d.TypeRegion
			,d.TypePatientPay
			,d.TypePatientSpendDown
			,d.TypePaymentError
			,d.Assigned_UserID
			,d.Action_UserID
			,d.DiscrepancyStatusID
			,d.DueDate
			,d.DiscoverDate
			,d.ResolvedDate
			,d.Balanced
			,d.ActiveFlag AS Discrepancy_ActiveFlag
			,d.insertDate AS Discrepancy_insertDate
			,d.updateDate AS Discrepancy_updateDate
			,d.rawMMISRateCell 
			,d.rawMMISRegion   
			,d.rawCCARateCell  
			,d.rawCCARegion    
			,1 as ActiveFlag
			,@spStart as insertDate
			,@spStart as updateDate
		from Discrepancies as d
		where d.updateDate = @spStart


	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spProcessDiscrepancies] TO [Talend] 
GRANT EXECUTE ON [dbo].[spProcessDiscrepancies] TO [Support] 
GO
-- *****************************************************************************************************