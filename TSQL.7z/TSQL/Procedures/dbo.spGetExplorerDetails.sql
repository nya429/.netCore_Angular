USE [RevRec]
GO


-- select top 100 * from MH834MemberData where MMIS_ID = '100033813559'


/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetExplorerDetails] -- MUST PASS @DiscrepancyID
PRINT @returnValue 



-- VALIDATE USE CASE
exec spGetExplorerDetails @discrepancyID = 12871

select * from CMPMemberData where ccaid = 5365618554        
SELECT * FROM MH834MemberData WHERE MMIS_ID = 100033813559	
SELECT * FROM MH834MemberDataByMonth WHERE MMIS_ID = 100033813559	
SELECT * FROM ExpectedPayments WHERE MMIS_ID = 100033813559	



-- *****************************************************************************************************
*/


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetExplorerDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetExplorerDetails]
GO

/****** Object:  StoredProcedure [dbo].[spGetExplorerDetails]    Script Date: 4/14/2020 11:15:35 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Shubham Pathak
-- Create date: 11/21/2019
-- Description:	ADS-2980/ADS-3000
				Detailed data for the explorer page in Revrec app


				Code Review: Yue: 01/10/2020
					are we going to add future months
					adjust to see all months, even if blank

				Post QA: 01/22/2020
					duplicate months for 834 data are still showing.
					created a member month breakout and will incorporate that for the data
					


-- Modified by: Yue Song
-- Modified dt: 4/17/2020
-- Description: Added default startdate and enddate with range of 2.5 years from selected discrepancy membermonth

-- EXEC TIME:	00:00:01 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetExplorerDetails]
	-- Add the parameters for the stored procedure here
	-- need to add user ID here
	  --@CCAID bigint 
	 @DiscrepancyID int  --= 165108   
	, @startDate Date = Null
    , @endDate Date = Null  
	-- do not believe we will use a range... unless we do a more narrow focused span for a member
	--, @pageIndex int		  = 0
	--, @pageSize int			  = 25
	--, @sortBy varchar(50)	  = 'UserNameAD' 
	--, @orderBy int            = 0 -- 0: ASC; 1: DESC


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
	DECLARE @MasterPatientID int = (select masterPatientID FROM Discrepancies AS dis where dis.DiscrepancyID = @DiscrepancyID)
	DECLARE @OpenEndDate date = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'OpenEndDate')
	
	-- Added default startdate and enddate  
	DECLARE @SelectedMemberMonth	DATE = (SELECT membermonth FROM Discrepancies AS dis WHERE dis.DiscrepancyID = @DiscrepancyID)    -- MemberMonth of selected discrepnacy
	DECLARE @DefaultStartDate		DATE = DATEADD(MONTH, -30, @selectedMemberMonth) 
	DECLARE @DefaultEnddate			DATE = DATEADD(MONTH,  30, @selectedMemberMonth)
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Return cross match based on member pulled from discrepancy ID
	-- ******************************

	select 
		--   mp.CCAID
		-- , mp.MMIS_ID
		memMap.CCAID
		, COALESCE(memMap.CCA_MMIS_ID , memMap.MMIS_MMIS_ID) as MMIS_ID
		, memMon.membermonth 
		, mp.ccaRateCell as MP_RateCell
		, Case When
			mp.Product = 'SCO'
			Then rcMap.MP_RatCatPrefix + RIGHT(mp.ccaRateCell,1)
			Else rcMap.MP_RatCatPrefix
		End as CMP_RateCell
		-- 834
		, mh.MH834RateCell as MH834_RateCell
		, mh.RateCellStartDate as MH834_LastAssessedDate
		-- CMP
		, cmp.CMPMDSAssessment as CMP_Source
		, cmp.AssessmentStartDate as CMP_LastAssessedDate
		--, Match_MPToCMP
		, isnull(Case 
			When mp.Product = 'SCO'
			Then 
				Case 
				When mp.ccaRateCell = rcMap.MP_RatCatPrefix + RIGHT(mp.ccaRateCell,1) 
			    Then '1'
			    Else '0'
			End
			When mp.Product = 'ICO'
			Then 
				Case 
				When mp.ccaRateCell = rcMap.MP_RatCatPrefix  
			    Then '1'
			    Else '0'
			End
		End, 0) as Match_MPToCMP
		--, Match_MPToMH834
		,isnull(Case When 
			mp.ccaRateCell = mh.MH834RateCell 
			Then '1'
			Else '0'
		End, 0) as Match_MPToMH834
		--,	Match_CMPToMH834
		,isnull(Case 
			When mp.Product = 'ICO'
			Then
			Case
				When rcMap.MP_RatCatPrefix = mh.MH834RateCell 
				Then '1'
				Else '0'
			End

				When mp.Product = 'SCO'
			Then
			Case
				When rcMap.MP_RatCatPrefix + RIGHT(mp.ccaRateCell,1)  = mh.MH834RateCell 
				Then '1'
				Else '0'
			End
		End, 0) as Match_CMPToMH834
		
		, isnull(Case 
			When mp.Product = 'SCO'
			Then 
				Case 
				When mp.ccaRateCell = rcMap.MP_RatCatPrefix + RIGHT(mp.ccaRateCell,1) 
			    Then '1'
			    Else '0'
			End
			When mp.Product = 'ICO'
			Then 
				Case 
				When mp.ccaRateCell = rcMap.MP_RatCatPrefix  
			    Then '1'
			    Else '0'
			End
		End, 0) as Match_CMPToMP
		
		,isnull(Case When 
			mp.ccaRateCell = mh.MH834RateCell 
			Then '1'
			Else '0'
		End,0) as Match_MH834ToMP
		
		,isnull(Case 
			When mp.Product = 'ICO'
			Then
			Case
				When rcMap.MP_RatCatPrefix = mh.MH834RateCell 
				Then '1'
				Else '0'
			End

				When mp.Product = 'SCO'
			Then
			Case
				When rcMap.MP_RatCatPrefix + RIGHT(mp.ccaRateCell,1)  = mh.MH834RateCell 
				Then '1'
				Else '0'
			End
		End,0) as Match_MH834ToCMP
 
	from vwMemberMonths as memMon 
	cross join vwMemberMap as memMap 


	full outer join ExpectedPayments as mp 
		on memMap.CCAID = mp.CCAID 
		and mp.MasterMemberMonth = memMon.membermonth

	/*	
	full outer join MH834MemberData as mh 
		on memMap.CCA_MMIS_ID = mh.MMIS_ID 
		AND memMon.membermonth BETWEEN mh.RateCellStartDate and mh.RateCellEndDate -- end date is always populated
	*/
	-- Post QA: 01/22/2020

	left outer join MH834MemberDataByMonth as mh 	                                                           -- change full outer to left outer join, since memberMonth table has no gap 
 
		on memMap.CCA_MMIS_ID = mh.MMIS_ID 
		AND memMon.membermonth = mh.MemberMonth
	
	left outer join CMPMemberData as cmp                                                                       -- change full outer to left outer join, since memberMonth table has no gap
		on memMap.CCAID = cmp.CCAID 
		AND memMon.membermonth BETWEEN cmp.AssessmentStartDate and isnull(cmp.AssessmentEndDate, @OpenEndDate) -- prevent ranges being left out because of missing end date, use default open end date

	left outer join CMPRateCellMap as rcMap on cmp.CMPMDSAssessment = rcMap.CMP_MDS                            -- change full outer to left outer join, since memberMonth table has no gap  
	
	-- full outer join Discrepancies as dis on memMap.MasterPatientID = dis.MasterPatientID
	
	where memMap.MasterPatientID = @MasterPatientID 
		and memMon.membermonth between COALESCE(@startDate, @DefaultStartDate) and COALESCE(@endDate, @DefaultEndDate)
	
	order by memMon.membermonth desc

	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END

GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spGetExplorerDetails] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetExplorerDetails] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetExplorerDetails] TO [Webapp] 
GO
-- *****************************************************************************************************