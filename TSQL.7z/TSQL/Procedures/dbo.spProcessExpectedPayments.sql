
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessExpectedPayments] 
PRINT @returnValue 


select * from ExpectedPayments
select  
	count(*)
	, sum(case when RateCardID is null then 0 else 1 end) as RateCardFound
	, sum(case when RateCardID is null then 1 else 0 end) as RateCardNotFound
from ExpectedPayments

select * from ExecutionLog order by ExecutionLogID desc

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spProcessExpectedPayments]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spProcessExpectedPayments]
GO

/****** Object:  StoredProcedure [dbo].[spProcessExpectedPayments]    Script Date: 10/09/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 10/09/2019
-- Description:	Process for staging Expected Payments (part of daily process)
				Will see how viable the view is on the network, but monthly summary record was processing slowly, and may be subject to nested joins.

-- Modified by: Shubham Pathak, Yue Song
-- Modified dt: 03/24/2020
-- Description: Break down view query into update statements 

-- Modified by: Yue Song
-- Modified dt: 04/14/2020
-- Description: Break down view query into update statements 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spProcessExpectedPayments]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)		
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. clear ExpectedPayments table for latest insert
	-- ******************************
	
	EXEC [dbo].[spTrun_ExpectedPayments] 

	-- ******************************
	-- STEP 2. Insert Into ExpectedPayments table
	-- ******************************


	insert into ExpectedPayments (
		MasterMemberMonth
		, CCAID
		, MMIS_ID
		, MemberFirstName
		, MemberMiddleName
		, MemberLastName
		, Gender
		, DOB
		, DOD
		, Product
		, EnrollStartDate
		, EnrollEndDate
		) 
		
		select 
		distinct -- remove duplicated records in order to only one record associated with member month 
		mm.MasterMemberMonth,
		mem.CCAID,
		mem.MMIS_ID,
		mem.MemberFirstName,
		mem.MemberMiddleName,
		mem.MemberLastName,
		mem.Gender,
		mem.DOB,
		mem.DOD,
		mem.Product,
		mem.EnrollStartDate,
		mem.EnrollEndDate
		
		from vwCCAMemberData as mem
			inner join (
						select distinct CapitationMonthYear as MasterMemberMonth 
						from PaymentDetailPaid as pdp
													cross join (
														select parameterValue as LookbackDate from 
														listParameters where parameterName = 'LookbackDate'
														) 
						as lbd 
						where pdp.CapitationMonthYear >= lbd.LookbackDate
						) as mm 
			on (mm.MasterMemberMonth between mem.EnrollStartDate and isnull(mem.EnrollEndDate, '2999-12-31')) -- Product
	-- **********************************************************
	-- STEP 3. Update Rating Category Span in ExpectedPayments table
	-- **********************************************************
	
	Update ep 
	
	set 
	RatingCategory = rcSpan.RatingCategory,
	RatingCategoryStartDate = rcSpan.RatingCategoryStartDate,
	RatingCategoryEndDate = rcSpan.RatingCategoryEndDate
	FROM ExpectedPayments as ep inner join CCAMemberSpanRatingCategory rcSpan on rcSpan.CCAID = ep.CCAID
	where (ep.MasterMemberMonth between rcSpan.RatingCategoryStartDate and isnull(rcSpan.RatingCategoryEndDate, '2999-12-31')) -- Rate Cell;

	-- **********************************************************
	-- STEP 4. Update Region Span in ExpectedPayments table
	-- **********************************************************
	Update ep 
	
	set 
	Region			= rgSpan.Region,
	RegionStartDate	= rgSpan.RegionStartDate,
	RegionEndDate	= rgSpan.RegionEndDate
	FROM ExpectedPayments as ep 
		inner join 
			CCAMemberSpanRegion rgSpan 
		on rgSpan.CCAID = ep.CCAID and (ep.MasterMemberMonth between rgSpan.RegionStartDate and isnull(rgSpan.RegionEndDate, '2999-12-31')) -- Region
	
	
	
	-- **********************************************************
	-- STEP 5. Update Patient Pay in ExpectedPayments table
	-- **********************************************************
	Update ep 
	
	set 
	 PatientPay			 = pp.PatientPay,
	 PatientPayStartDate = pp.PatientPayStartDate,
	 PatientPayEndDate   = pp.PatientPayEndDate

	
	FROM ExpectedPayments as ep 
		left join  -- for months not covered with CCAMemberSpanPatientPay
			CCAMemberSpanPatientPay pp 
		on pp.CCAID = ep.CCAID
			and (ep.MasterMemberMonth between pp.PatientPayStartDate and isnull(pp.PatientPayEndDate, '2999-12-31')) -- 
		
	-- **********************************************************
	-- STEP 6. Update Patient Spend Down in ExpectedPayments table
	-- **********************************************************
	Update ep 
	
	set 
	 PatientSpendDown			= spd.PatientSpendDown,
	 PatientSpendDownStartDate	= spd.PatientSpendDownStartDate,
	 PatientSpendDownEndDate	= spd.PatientSpendDownEndDate

	
	FROM ExpectedPayments as ep 
		left join -- for months not covered by CCAMemberSpanPatientSpendDown
			CCAMemberSpanPatientSpendDown spd 
		on spd.CCAID = ep.CCAID
			and (ep.MasterMemberMonth between spd.PatientSpendDownStartDate and isnull(spd.PatientSpendDownEndDate, '2999-12-31')) -- 

	-- **********************************************************
	-- STEP 7. Update RatingCategoryId and RegionId in in ExpectedPayments table
	-- **********************************************************
	Update ep 
	
	set 
	 CCARateCellID     = rat.CCARateCellID ,  
     CCARegionID	   = reg.CCARegionID	 

	
	FROM ExpectedPayments as ep  -- consideration rate cells and regions are maintained at this table level
		left join ccaratecells as rat 
			on rat.CCARateCell = case ep.product when 'SCO' then left(ep.RatingCategory,3) else ep.RatingCategory end
		left join ccaregions as reg 
		    on reg.CCARegion = ep.Region

	-- **********************************************************
	-- STEP 8. Update Rate Card Details in ExpectedPayments table
	-- **********************************************************

	Update ep set 
	
	  RateCardID = rc.RateCardID
	--, CCARateCellID = rc.CCARateCellID
	, CCARateCell   =rc.CCARateCell
	--, CCARegionID	=rc.CCARegionID
	, CCARegion		=rc.CCARegion
	, StartDate		=rc.StartDate
	, EndDate		=rc.EndDate
	, Amount		=rc.Amount
	, RateCardLabel	=rc.RateCardLabel
	, Eligibility	=rc.Eligibility
	, EligibilityStatus =  rc.EligibilityStatus
						
	/*from RateCard rc where rc.RateCardID = RateCardID*/ 

	from  ExpectedPayments as ep 
		inner join 
			vwRateCard as rc
		on rc.CCARateCellID = ep.CCARateCellID 
			and rc.CCARegionID = ep.CCARegionID
			and ep.MasterMemberMonth between rc.StartDate and isnull(rc.EndDate, '2999-12-31')
	where rc.ActiveFlag = 1
		

	-- **********************************************************
	-- STEP 8. Update rest of the columns in ExpectedPayments table
	-- **********************************************************

	Update ExpectedPayments set

	 ActiveFlag = 1
   , insertDate = @spStart
   , updateDate = @spStart


	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spProcessExpectedPayments] TO [Talend] 
GRANT EXECUTE ON [dbo].[spProcessExpectedPayments] TO [Support] 
GO
-- *****************************************************************************************************