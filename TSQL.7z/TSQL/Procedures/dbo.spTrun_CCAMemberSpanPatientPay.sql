
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spTrun_CCAMemberSpanPatientPay] 
PRINT @returnValue 

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spTrun_CCAMemberSpanPatientPay]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spTrun_CCAMemberSpanPatientPay]
GO

/****** Object:  StoredProcedure [dbo].[spTrun_CCAMemberSpanPatientPay]    Script Date: 09/07/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		
-- Create date: 09/07/2019
-- Truncates:	CCAMemberSpanPatientPay
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spTrun_CCAMemberSpanPatientPay]
WITH EXECUTE AS 'dbo'


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- DECLARE @CCAMemberSpanPatientPay varchar(100) = '[dbo].[spTrun_CCAMemberSpanPatientPay]'
	
	TRUNCATE TABLE [dbo].[CCAMemberSpanPatientPay]

END
GO

-- No additional permissions should be needed.  spTrun should be called from within another stored procedure with appropriate permissions



-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spTrun_CCAMemberSpanPatientPay] TO [Talend] 
GRANT EXECUTE ON [dbo].[spTrun_CCAMemberSpanPatientPay] TO [Support] 
GO
-- *****************************************************************************************************
