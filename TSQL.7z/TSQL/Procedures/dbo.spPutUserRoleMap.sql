
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spPutUserRoleMap] 
PRINT @returnValue 

select * from changetable(changes [UserRoleMap],NULL) as ct order by sys_change_version


select * from PartnerExchange.dbo.pe_di_logs order by starttime desc, endtime desc
select * from dbo.listParameters where parameterName = 'ExecutionLogging'
select * from ExecutionLog order by ExecutionLogID desc

SELECT * FROM users
select * from userroles
exec spGetUsers

select * from usereventlog order by eventid desc

select * from userRoleMap

DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spPutUserRoleMap] 2
PRINT @returnValue 


DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spPutUserRoleMap] 2, NULL, 9, 1
PRINT @returnValue 

DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spPutUserRoleMap] 2, NULL, 9, 1, 0
PRINT @returnValue 

DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spPutUserRoleMap] 2, 10, NULL, NULL, 1
PRINT @returnValue 

DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spPutUserRoleMap] 2, 10, NULL, NULL, 0
PRINT @returnValue 

select * from userEventLog ORDER BY EVENTID DESC

			EXEC spPutUserRoleMap
			  @eventUserID = 2
			, @putUserID = 9
			, @putUserRoleID = 3


-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spPutUserRoleMap]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spPutUserRoleMap]
GO

/****** Object:  StoredProcedure [dbo].[spPutUserRoleMap]    Script Date: 08/12/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan	
-- Create date: 08/12/2019
-- Description:	Sub-API
				Processed called by the create/update user processes to add the roles assigned through that process

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spPutUserRoleMap]
	-- Add the parameters for the stored procedure here
	  @eventUserID int 
	, @putUserRoleMapID int = NULL
	, @putUserID    int = NULL
	, @putUserRoleID    int = NULL
	, @putActiveFlag bit = 1


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
	DECLARE @ReturnCode int -- should this be an established standard
	DECLARE @EventOldData nvarchar(1000)
	DECLARE @EventNewData nvarchar(1000)


-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)


	-- ******************************
	-- STEP 1. Confirm appropriate values sent.
	-- May also want to confirm primary or unique key was provided, so single row is planned for update
	-- ******************************
	
	if @eventUserID is null 
		RAISERROR ('Parameter cannot be null: @eventUserID', 16, 1)
		
	if (@putUserRoleMapID IS NULL and @putUserID is null and @putUserRoleID is null)
		RAISERROR ('Parameters must bet sent as follows: Either @putUserRoleMapID or both @putUserID and @putUserRoleID', 16, 1)


	-- ******************************
	-- STEP 2. Initialize EventResult Table
	-- ******************************


	if object_id('tempdb..#EventResult') is not null
		drop table #EventResult

	create table #EventResult (

		UserRoleMapID int
		, old_UserID     int
		, old_UserRoleID int    
		, old_ActiveFlag bit 
		, new_UserID     int
		, new_UserRoleID int    
		, new_ActiveFlag bit 

	)

	-- ******************************
	-- STEP 3. Check if exact entry exists
	-- ******************************

	IF EXISTS (
		select UserRoleMapID 
		from UserRoleMap
		where 
			(@putUserRoleMapID is null 
				AND UserID = @putUserID    
				AND UserRoleID = @putUserRoleID    
				AND ActiveFlag = @putActiveFlag 
			)
			OR (@putUserRoleMapID IS NOT NULL
				AND UserRoleMapID = @putUserRoleMapID 
				AND ActiveFlag = @putActiveFlag 
			)
	)
		set @ReturnCode = 1

	-- ******************************
	-- STEP 4. Check if new insert or update
	-- ******************************

	ELSE IF EXISTS (
		select UserRoleMapID 
		from UserRoleMap
		where 
			(@putUserRoleMapID is null 
				AND UserID = @putUserID    
				AND UserRoleID = @putUserRoleID    
			)
			OR (@putUserRoleMapID IS NOT NULL
				AND UserRoleMapID = @putUserRoleMapID 
			)
	)
		BEGIN
			UPDATE UserRoleMap
				SET 
					-- UserNameAD = @putUserNameAD 
					ActiveFlag = @putActiveFlag
					, updateDate = @spStart
			OUTPUT
				  inserted.UserRoleMapID
				, deleted.UserID
				, deleted.UserRoleID
				, deleted.ActiveFlag
				, inserted.UserID
				, inserted.UserRoleID
				, inserted.ActiveFlag
				into #EventResult
		where 
			(@putUserRoleMapID is null 
				AND UserID = @putUserID    
				AND UserRoleID = @putUserRoleID    
			)
			OR (@putUserRoleMapID IS NOT NULL
				AND UserRoleMapID = @putUserRoleMapID 
			)
			
			set @ReturnCode = 2
		END 
	ELSE
		BEGIN
			INSERT INTO UserRoleMap (
				UserID    
				, UserRoleID    
				, ActiveFlag 
				, insertDate        
				, updateDate        
			) 
			OUTPUT
				  inserted.UserRoleMapID
				, NULL -- deleted.UserID
				, NULL -- deleted.UserRoleID
				, NULL -- deleted.ActiveFlag
				, inserted.UserID
				, inserted.UserRoleID
				, inserted.ActiveFlag
				into #EventResult
			VALUES (
				@putUserID    
				, @putUserRoleID    
				, @putActiveFlag -- ActiveFlag 
				, @spStart -- insertDate
				, @spStart -- updateDate        
			)
	
			
			set @ReturnCode = 3
		END 


	-- ******************************
	-- STEP 5. Event Log JSON preparation and storage
	-- ******************************


-- @EventOldData
	select @EventOldData = '{
		     "UserRoleMapID":' + CAST(UserRoleMapID  AS varchar)
		+ ', "UserID"       :' + CAST(old_UserID     AS varchar)
		+ ', "UserRoleID"   :' + CAST(old_UserRoleID AS varchar)
		+ ', "ActiveFlag"   :' + case old_ActiveFlag when 0 then 'false' else 'true' end
		+ '}' -- as EventOldData
	from #EventResult


-- @EventNewData
	select @EventNewData = '{
		     "UserRoleMapID":' + cast(UserRoleMapID  as varchar)
		+ ', "UserID"       :' + cast(new_UserID     as varchar)
		+ ', "UserRoleID"   :' + cast(new_UserRoleID as varchar)
		+ ', "ActiveFlag"   :' + case new_ActiveFlag when 0 then 'false' else 'true' end
		+ '}' -- as EventNewData
	from #EventResult
	

	EXEC spPutUserEventLog @eventUserID, @spProcName, @spStart, @ReturnCode, @EventOldData, @EventNewData

	Return @ReturnCode

	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spPutUserRoleMap] TO [Talend] 
GRANT EXECUTE ON [dbo].[spPutUserRoleMap] TO [Support] 
GRANT EXECUTE ON [dbo].[spPutUserRoleMap] TO [webapp] 
GO
-- *****************************************************************************************************