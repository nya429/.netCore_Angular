USE [RevRec]
GO


/*
-- *****************************************************************************************************
-- Test Execution Block
EXEC [dbo].[spGetReportFinancial]

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetReportFinancial]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetReportFinancial]
SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Yue Song
-- Create date: 05/08/2020
-- Description:	API
				


-- Modified by:     Yue Song
-- Modified dt:     05/21/2020
-- Description: 	IDS-371 (release 1493) RevRec_Reports_Exclude never enrolled member from the operational report.
					Never-enrolled members has been excluded from GetdiscrepancyList / GetMemberList,  
					in order to let report numbers align with discrepancyList/MemberList,  temprarily 
					exclude never-enrolled member from report results by applying same join clause used by  
					GetdiscrepancyList / GetMemberList.

					IDS-1477 (release 1493) use DiscrepancyCategoryIsResolved as Resolved status indicator
-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetReportFinancial]
	-- Add the parameters for the stored procedure here
	    @UserID			 int  = NULL
	  , @startDate		 Date = Null
      , @endDate		 Date = Null  
	  
	  /*
	  , @pageIndex int		  = 0
	  , @pageSize int			  = 25
	  , @sortBy varchar(50)	  = '' 
	  , @orderBy int            = 0 -- 0: ASC; 1: DESC
	  */


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	


	DECLARE @todayDate              date = getdate()
		DECLARE @DefaultStartDate   varchar(10) = ISNULL(@startDate, CONVERT(varchar(10), DATEADD(MONTH, -25, @todayDate), 120))
	DECLARE @DefaultEndDate			varchar(10) = ISNULL(@endDate,   CONVERT(varchar(10), @todayDate, 120))

	DECLARE @sqlStatement           NVARCHAR(MAX)
	DECLARE @cols                   NVARCHAR(MAX)
	DECLARE @colsIsNull             NVARCHAR(MAX)
	
	-- Hardcoded values
	--DECLARE @resolvedCategoryIds     varchar(50) = (SELECT DiscrepancyCategoryID FROM discrepancyCategories dc WHERE dc.DiscrepancyCategoryDisplay = 0) -- #TEMP use DiscrepancyCategoryDisplay as resolved categories indicator, should have a delicated indicator 
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	

	-- ******************************
	-- STEP 0. Fetch discrepancyCategory columns
	-- ******************************
	SET @cols  = STUFF(
					(SELECT 
					     -- DISTINCT ',' + QUOTENAME(cast(DiscrepancyCategoryID AS varchar) + '_' + col) 
						 -- FROM DiscrepancyCategories
						 DISTINCT ',' + QUOTENAME(cast(X.a  AS varchar) + '_' + col) 
						 FROM (VALUES ('MR'), ('NR'), ('MU'), ('NU')) AS X(a)
						 CROSS APPLY 
						 (
							SELECT 'overpay_sum' AS col
							UNION ALL
							SELECT 'underpay_sum'
							UNION ALL
							SELECT 'overpay_count'
							UNION ALL
							SELECT 'underpay_count'
						 ) AS c
						 FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
					,1,1,''
				  )
	
	 print @cols
	-- ******************************
	-- STEP 1. Base query
	-- ******************************
	/*
	SET @sqlStatement = 
		'SELECT 
	   		d.MemberMonth,  
	   		ds.DiscrepancyCategoryID,   
	   		SUM(case when d.variance >= 0 THEN  d.variance else 0 end) AS overpay, 
	   		SUM(case when d.variance <  0 THEN  d.variance else 0 end) AS underpay
	   	 FROM 
	   		discrepancies d 
	   		INNER JOIN 
	   		DiscrepancyStatuses ds ON d.DiscrepancyStatusID = ds.DiscrepancyStatusID
		 WHERE
			d.MemberMonth > ''' + @DefaultStartDate + ''' 
			AND
			d.MemberMonth <= ''' + @DefaultEndDate + ''' 
	   	 GROUP BY MemberMonth, DiscrepancyCategoryID'

		 */

	SET @sqlStatement = 
	'SELECT 
			d.MemberMonth, 
			d.Variance,
			-- m.memberenrollmentStatus,
			-- m.memberenrollmentStatusId,
			--  d.DiscrepancyStatusID,
			-- cast(rc.resolved as varchar) + cast(m.memberenrollmentStatusId as varchar) as category
			CASE WHEN m.memberenrollmentStatusId = 1 THEN ''M'' ELSE ''N'' END + CASE WHEN dc.DiscrepancyCategoryIsResolved = 1 THEN ''R'' ELSE ''U'' END  AS category
		FROM discrepancies d 
			 INNER JOIN 
			 DiscrepancyStatuses ds ON d.DiscrepancyStatusID = ds.DiscrepancyStatusID
			 INNER JOIN  
			 DiscrepancyCategories dc ON ds.DiscrepancyCategoryID = dc.DiscrepancyCategoryID  -- IDS-1477 
			 INNER JOIN      -- IDS-371
			 /** when we fixed never-enrolled member use: 
			     -- LEFT JOIN  -
			  */
			 Memberlist m ON d.MasterPatientID = m.MasterPatientID
		 WHERE
			d.MemberMonth >= ''' + @DefaultStartDate + ''' 
			AND
			d.MemberMonth <= ''' + @DefaultEndDate + ''' 
	'

	SET @sqlStatement = 
	'SELECT 
		raw.MemberMonth  
	 -- , ds.DiscrepancyCategoryID  
		, raw.category
	 -- , dc.DiscrepancyCategory
		, CAST( SUM(CASE WHEN raw.variance > 0 THEN  raw.variance ELSE 0 END) AS DECIMAL(18,2)) AS overpay_sum 
		, CAST( SUM(CASE WHEN raw.variance > 0 THEN  1            ELSE 0 END) AS DECIMAL(18,2)) AS overpay_count
		, CAST( SUM(CASE WHEN raw.variance < 0 THEN  raw.variance ELSE 0 END) AS DECIMAL(18,2)) AS underpay_sum
		, CAST( SUM(CASE WHEN raw.variance < 0 THEN  1            ELSE 0 END) AS DECIMAL(18,2)) AS underpay_count
	 --	, COUNT(raw.category) AS total
	 FROM ('+ @sqlStatement +') as raw
	 GROUP BY  MemberMonth, raw.category'

     --print @sqlStatement
	-- ******************************
	-- STEP 2. Pivot query
	-- ******************************
	SET @sqlStatement = '
	    SELECT *
	   	FROM
	   	(
	   		SELECT 
	   		    MemberMonth as Month
	   			-- ,CAST(DiscrepancyCategoryID AS VARCHAR) + ''_'' + col col
			    , CAST(category AS VARCHAR) + ''_'' + col col
	   			, value
	   		FROM  
	   		(' + @sqlStatement + ') as rawg 
	   		UNPIVOT
	   		(
	   			value
	   			FOR col IN (overpay_sum, overpay_count, underpay_sum, underpay_count)
	   		) AS unpiv
	   	) AS unpiv_col
	   	PIVOT(
	   		SUM(value)
	   		FOR col IN 
	   			(' + @cols + ')
	   			--[1_overpay],[1_underpay],[15_overpay],[15_underpay],...--
	   	)
	    AS pivot_table'

	--print @sqlStatement
	-- ******************************
	-- STEP 3. Execute dynamic statement
	-- ******************************
	exec(@sqlStatement)


	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END

GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
-- GRANT EXECUTE ON [dbo].[spGetReportFinancial] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetReportFinancial] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetReportFinancial] TO [webapp] 
GO
-- *****************************************************************************************************

