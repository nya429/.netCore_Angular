
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spTrun_PaymentDetail] 
PRINT @returnValue 

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spTrun_PaymentDetail]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spTrun_PaymentDetail]
GO

/****** Object:  StoredProcedure [dbo].[spTrun_PaymentDetail]    Script Date: 10/09/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		
-- Create date: 10/09/2019
-- Truncates:	PaymentDetail
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spTrun_PaymentDetail]
WITH EXECUTE AS 'dbo'


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- DECLARE @PaymentDetail varchar(100) = '[dbo].[spTrun_PaymentDetail]'
	
	TRUNCATE TABLE [dbo].[PaymentDetail]

END
GO

-- No additional permissions should be needed.  spTrun should be called from within another stored procedure with appropriate permissions



-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spTrun_PaymentDetail] TO [Talend] 
GRANT EXECUTE ON [dbo].[spTrun_PaymentDetail] TO [Support] 
GO
-- *****************************************************************************************************
