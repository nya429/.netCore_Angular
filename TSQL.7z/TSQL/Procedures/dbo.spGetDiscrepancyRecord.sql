
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyRecord] 
PRINT @returnValue 


exec [dbo].[spGetDiscrepancyRecord] 
	  @eventUserID = 2
	, @DiscrepancyID = 2

exec [dbo].[spGetDiscrepancyRecord] 
	  @eventUserID = 2
	, @DiscrepancyID = 1

exec [dbo].[spGetDiscrepancyRecord] 
	  @eventUserID = 2
	, @DiscrepancyID = 500



-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetDiscrepancyRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetDiscrepancyRecord]
GO

/****** Object:  StoredProcedure [dbo].[spGetDiscrepancyRecord]    Script Date: 09/05/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/05/2019
-- Description:	API
				Gets a single discrepancy record via passed DiscrepancyID

-- Modified by: Jonathan Lewis
-- Modified dt: 12/31/2019
-- Description: ADS-3160 (release ADS-2980)
					Add Rate Cell and Region values to Discrepancy Record
					Added 4 new columns for CCA Rate cell and region and MMIS rate cell and region
					Also addressed null payment, varience, and error values similar to GetDiscrepancyList
					Finally, added assigned and action username like GetDiscrepancyList

-- Modified by: Jonathan Lewis
-- Modified dt: 01/06/2020
-- Description: ADS-3157 (release ADS-2980)
					Added HasDiscrepancyComment,CountDiscrepancyComments
					


-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetDiscrepancyRecord]
	-- Add the parameters for the stored procedure here

	  @eventUserID int = NULL
	, @DiscrepancyID int -- must be passed	
	/*
	-- not necessary... single return?
	  -- maybe move hardcoding into stored procedure, then can check for isnull values
	, @pageIndex int		  = 0
	, @pageSize int			  = 25
	, @sortBy varchar(50)	  = 'DiscrepancyID' 
	, @orderBy int            = 1 -- 0: ASC; 1: DESC
	*/

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Get Discrepancy Recrod
	-- ******************************

	select 
		 d.DiscrepancyID
		,d.MonthlySummaryRecordID
		,d.MasterPatientID
		,d.MemberMonth
		,d.Variance
		,ISNULL(d.PaymentError, 0.00) AS PaymentError
		,d.BaseCapitationAmount
		,d.PatientPayAmountN
		,d.PatientPayAmountSCO
		,d.PaidCapitationAmount
		,d.CCARateCellID
		,d.CCARegionID
		,coalesce(ccarc.CCARateCell, d.rawCCARateCell        , '99') as CCARateCell        
		,coalesce(ccareg.CCARegion , d.rawCCARegion        , 'NA') as CCARegion         
		,ISNULL(d.CCAPatientPay		 , 0.00) AS CCAPatientPay		 
		,ISNULL(d.CCAPatientSpendDown, 0.00) AS CCAPatientSpendDown
		,ISNULL(d.CCARateCardID, CAST(0 AS INT)) AS CCARateCardID
		,d.CCAAmount
		,d.CCANetAmount
		,d.MMISRateCellID
		,d.MMISRegionID
		,coalesce(mmisrc.CCARateCell, d.rawMMISRateCell		 , '99') as MMISRateCell
		,coalesce(mmisreg.CCARegion , d.rawMMISRegion      , 'NA') as MMISRegion
		,d.MMISPatientPay
		,d.MMISPatientSpendDown
		,ISNULL(d.MMISRateCardID, CAST(0 AS INT)) AS MMISRateCardID
		,ISNULL(d.MMISAmount, 0.00) AS MMISAmount
		,d.MMISNetAmount
		,d.TypeRateCell
		,d.TypeRegion
		,d.TypePatientPay
		,d.TypePatientSpendDown
		,d.TypePaymentError
		,d.Assigned_UserID
		, (uAss.UserFirstName + ' ' + uAss.UserLastName) as Assigned_UserName
		,d.Action_UserID
		, (uAct.UserFirstName + ' ' + uAct.UserLastName) as Action_UserName
		,d.DiscrepancyStatusID
		,d.DueDate
		,d.DiscoverDate
		,d.ResolvedDate
		,d.Balanced
		,d.ActiveFlag
		,d.insertDate
		,d.updateDate
		,ds.DiscrepancyStatus
		-- ,u.UserNameAD as AssignedUserName -- this alias may need to become full first/last if no AD plugin

		, isnull(dcom.HasDiscrepancyComment		  , 0) as HasDiscrepancyComment		  
		, isnull(dcom.CountDiscrepancyComments, 0) as CountDiscrepancyComments
	from Discrepancies as d
	inner join DiscrepancyStatuses as ds on ds.DiscrepancyStatusID = d.DiscrepancyStatusID
	left join (
		select DiscrepancyID, count(*) as CountDiscrepancyComments , max(UpdateDate) as MaxCommentUpdateDate, cast(1 as bit) as HasDiscrepancyComment 
		-- may need new flag and API to mark read
		from DiscrepanciesComments
		where ActiveFlag = 1
		group by DiscrepancyID
		
	) as dcom on dcom.DiscrepancyID = d.DiscrepancyID

		-- join for actual vaulues... maybe reevaluate pulling it into discrepancies table itself
		left join CCARateCells   AS mmisrc  on mmisrc.CCARateCellID   = d.MMISRateCellID  -- even though says MMIS, it actually references CCA values, as that is what defines the rate card
		left join CCARegions     AS mmisreg on mmisreg.CCARegionID    = d.MMISRegionID    -- even though says MMIS, it actually references CCA values, as that is what defines the rate card
		left join CCARateCells	 AS ccarc   on ccarc.CCARateCellID     = d.CCARateCellID
		left join CCARegions     AS ccareg  on ccareg.CCARegionID      = d.CCARegionID 

	-- left join Users as u on u.userID = d.assigned_UserID
	left join users as uAct on uAct.UserID = d.Action_UserID
	left join users as uAss on uAss.UserID = d.Assigned_UserID

	where d.DiscrepancyID = @DiscrepancyID


	/*
	-- do not need pagination

		, count(*) over() as ResultCount -- generic for all multi-line get procedures

		
	ORDER BY 1 -- @sortBy -- need to consider this can be a column numeric representation, but would require dynamic SQL to incorporate the column name
	
	-- apply page retrieval 
	OFFSET (@pageSize * (@pageIndex)) ROWS
	FETCH NEXT @pageSize ROWS ONLY;
	*/


	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spGetDiscrepancyRecord] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetDiscrepancyRecord] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetDiscrepancyRecord] TO [webapp] 
GO
-- *****************************************************************************************************