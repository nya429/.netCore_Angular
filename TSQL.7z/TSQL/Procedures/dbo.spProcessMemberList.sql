
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMemberList] 
PRINT @returnValue 

select * from memberList

select * from ExecutionLog order by ExecutionLogID desc

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spProcessMemberList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spProcessMemberList]
GO

/****** Object:  StoredProcedure [dbo].[spProcessMemberList]    Script Date: 09/16/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/16/2019
-- Description:	Processing procedure to stage the member list data for better API/UI performance

				Unit-test: 10/07/2019
					Removed join to MMISMemberData, not used and not be confused with new MasterPatientManagement for MasterPatientID


-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spProcessMemberList]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	DECLARE @todayDate date = getdate()
	DECLARE @openEndDate date = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'OpenEndDate')
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Truncate member list
	-- ******************************

	EXEC dbo.spTrun_MemberList


	-- ******************************
	-- STEP 2. process member list
	-- ******************************
	
	insert into MemberList (
		  MasterPatientID 
		, MemberFirstName 
		, MemberMiddleName 
		, MemberLastName 
		, MMIS_MMIS_ID 
		, CCAID 
		, Product 
		, EnrollStartDate 
		, EnrollEndDate 
		, DOB 
		, DOD 
		, RatingCategory 
		, Region 
		, MemberEnrollmentStatus 
		, MemberEnrollmentStatusId
		, TotalDiscrepancies 
		, maxAging 
		, absoluteVarianceSum 
	)


	select 
		m.MasterPatientID       -- ID
		-- was CCA before
		, isnull(m.CCA_MemberFirstName , m.MMIS_MemberFirstName  ) as MemberFirstName -- NAME
		, isnull(m.CCA_MemberMiddleName, m.MMIS_MemberMiddleName ) as MemberMiddleName-- NAME
		, isnull(m.CCA_MemberLastName  , m.MMIS_MemberLastName   ) as MemberLastName  -- NAME 
		, m.MMIS_MMIS_ID		  -- MMIS_ID
		, m.CCAID				  -- CCAID
		, ccaMem.Product          -- Program
		, ccaMem.EnrollStartDate  -- enrollmentStart
		, ccaMem.EnrollEndDate    -- enrollmentEnd
		, ccaMem.DOB              -- dateOfBirth
		, NULL as DOD               -- dateOfDeath -- needs to be added to member
		, ccaMem.RatingCategory   -- 
		, ccaMem.Region
		, case 
			when m.CCAID is null
				then 'Never enrolled' -- 0
			when '' + cast(@todayDate as varchar) + '' between ccaMem.EnrollStartDate and isnull(ccaMem.EnrollEndDate, '' + cast(@openEndDate as varchar) + '')
				then 'Currently enrolled' -- 1 
			else 'Not currently enrolled' -- 2
		end as MemberEnrollmentStatus
		, case 
			when m.CCAID is null
				then  0
			when '' + cast(@todayDate as varchar) + '' between ccaMem.EnrollStartDate and isnull(ccaMem.EnrollEndDate, '' + cast(@openEndDate as varchar) + '')
				then  1 
			else 2
		end as MemberEnrollmentStatusId
		, d.TotalDiscrepancies
		, datediff(day,d.DiscrepancyAge, '' + cast(@spStart as varchar) + '') as maxAging				  
		, d.absoluteVarianceSum
		-- , count(*) over() as ResultCount

	from vwMemberMap as m
	left join (
		select MasterPatientID, sum(abs(variance)) as absoluteVarianceSum, min(insertDate) as DiscrepancyAge, count(*) as TotalDiscrepancies
		from Discrepancies 
		group by MasterPatientID
	) as d on d.MasterPatientID = m.MasterPatientID
	-- left join vwCCAMemberData as ccaMem on ccaMem.CCAID = m.CCAID -- original join, before rank
	left join (
		select 
				mem.CCAID
			, mem.Product          -- Program
			, mem.EnrollStartDate  -- enrollmentStart
			, mem.EnrollEndDate    -- enrollmentEnd
			, mem.DOB              -- dateOfBirth
			, NULL as DOD               -- dateOfDeath -- needs to be added to member
			, mem.RatingCategory   -- 
			, mem.Region
			-- do we need end date desc, too?... other date ranges should not be used... already aligned in the view
			, row_number() over (partition by mem.CCAID order by mem.EnrollStartDate           desc) as rnEnroll
			-- , row_number() over (partition by mem.CCAID order by mem.RatingCategoryStartDate   desc) as rnRatingCategory
			-- , row_number() over (partition by mem.CCAID order by mem.RegionStartDate           desc) as rnRegion
			-- , row_number() over (partition by mem.CCAID order by mem.PatientPayStartDate       desc) as rnPatientPay
			-- , row_number() over (partition by mem.CCAID order by mem.PatientSpendDownStartDate desc) as rnPatientSpendDown
		from vwCCAMemberData as mem
	) as ccaMem on ccaMem.CCAID = m.CCAID
		and ccaMem.rnEnroll           = 1
		-- and ccaMem.rnRatingCategory   = 1
		-- and ccaMem.rnRegion           = 1
		-- and ccaMem.rnPatientPay       = 1
		-- and ccaMem.rnPatientSpendDown = 1
	-- left join MMISMemberData as mmisMem on mmisMem.MasterPatientID = m.MasterPatientID





	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spProcessMemberList] TO [Talend] 
GRANT EXECUTE ON [dbo].[spProcessMemberList] TO [Support] 
GO
-- *****************************************************************************************************