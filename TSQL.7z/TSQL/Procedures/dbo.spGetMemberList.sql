
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMemberList] 
PRINT @returnValue 

DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMemberList] 
	  @MasterPatientID        = NULL -- 125
	-- , @Name                   = NULL -- 'JACO'         -- unit test: confirmed... much faster now that data is staged rather than joined in realtime
	, @Name                   = 'JACO'         -- unit test: confirmed... much faster now that data is staged rather than joined in realtime
	-- , @Name                   = 'Sand Woo'
	, @CCAID                  = NULL -- 5365566023     -- unit test: confirmed
	, @MMIS_ID                = NULL -- '100009285841' -- unit test: confirmed       
	, @includeZeroDiscrepancy = 0 					   -- unit test: pending test data
	, @AssigneeID             = NULL
	, @pageIndex              = 0                      -- unit test: confirmed
	, @pageSize               = 25                     -- unit test: confirmed
	, @sortBy                 = 'absoluteVarianceSum'  -- unit test: pending test data
	, @orderBy                = 1 					   -- unit test: pending test data
PRINT @returnValue 

select * 
from MMISMemberData
where masterpatientid in (
	  27  -- 100000113132
	, 125 -- 100000150019
	, 205 -- 100000019537
	, 219 -- 100000100386
	, 502 -- 100001046661
	, 570 -- 100000976678
)


-- examples to review
EXEC [dbo].[spGetMemberList] @MasterPatientID = 1397 , @AssigneeID = 1 -- 6 0
EXEC [dbo].[spGetMemberList] @MasterPatientID = 10102, @AssigneeID = 1 -- 15 3
EXEC [dbo].[spGetMemberList] @MasterPatientID = 41074, @AssigneeID = 3 -- 6 3
EXEC [dbo].[spGetMemberList] @MasterPatientID = 51673, @AssigneeID = 2 -- 0 14

EXEC [dbo].[spGetMemberList] @AssigneeID = 1 , @mmis_id = '100012762744'-- 6 0  
EXEC [dbo].[spGetMemberList] @AssigneeID = 2 , @mmis_id = '100012762744'-- 0 14 
EXEC [dbo].[spGetMemberList] @AssigneeID = 3 , @mmis_id = '100012762744'-- 6 3	 

EXEC [dbo].[spGetMemberList] @mmis_id = '100012762744' -- 20, 19
EXEC [dbo].[spGetMemberList] @mmis_id = '100012762744', @AssigneeID = 2 -- 20, 6

EXEC [dbo].[spGetMemberList] @CCAID = 5364521807


SELECT * FROM DISCREPANCIES WHERE MASTERPATIENTID = 1397   
SELECT * FROM DISCREPANCIES WHERE MASTERPATIENTID = 10102  
SELECT * FROM DISCREPANCIES WHERE MASTERPATIENTID = 41074  
SELECT * FROM DISCREPANCIES WHERE MASTERPATIENTID = 51673  

-- *****************************************************************************************************
*/


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetMemberList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetMemberList]
GO

/****** Object:  StoredProcedure [dbo].[spGetMemberList]    Script Date: 08/01/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/01/2019
-- Description:	Return member list for use with UI
				MemberEnrollmentStatus
					0 - Never enrolled
					1 - Currently enrolled
					2 - Not currently enrolled

					expectation vs truth
					CCA name or MMIS name when not there
						old way was to display as non-Member

				Unit test observation - 09/17/2019
					Rating Category (unsplit Ratingcategory with both Rate Cell and Region is returned) 
						will discuss removing, but think it is acceptable to remain this way

				Post Unit Test - API Feature request - 09/23/2019
					Added AssigneeID as filter option
					Return TotalAssigned count for discrepancies (by member)
						or, if assignee ID is not sent, indicate total discrepancies assigned to anyone vs total discrepancies for a member

				Post Unit Test - 09/27/2019
					Total assigned was not calculating correctly for when an assigned user was chosen
					Adjusted by changing the dynamic join based on the passed assignee parameter

				Post Unit Test - 10/11/2019
					Member List - counts need to be updated, including ""drop offs""
					Discrepancy should only be showing ""visible"" status categories by default
					Money totals should change when discrepancies updated 
					Aging - Nick asked to align with member month (not system insert date) "
					Added TotalAssigned as sort option 

				Post Unit Test - 10/15/2019
					updated to compare against real-time counts when include zero discrepancies
 
 -- Modified by: Yue Song
 -- Modified dt: 05/07/2020
 -- Description: IDS-1051 (release IDS-865)
					-- added @exportAll to identify whether pull all records
					   apply pagination and sort on condtion ( @exportAll )
-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetMemberList]
	-- Add the parameters for the stored procedure here
	 @eventUserID int = NULL
	 , @MasterPatientID int = NULL
	 , @Name varchar(51) = NULL -- to accomodate space in last name.  20 char for first + 30 char for last + 1 space
	 , @CCAID bigint = NULL
	 , @MMIS_ID char(12) = NULL
	 , @includeZeroDiscrepancy int = 0 -- 0: NO; 1: YES
	 , @AssigneeID int = NULL

	 , @exportAll  TINYINT = 0   -- IDS-1051   0 : No; 1: Yes 
	 
	 , @pageIndex int = 0
	 , @pageSize int = 25
	 , @sortBy varchar(50) = 'absoluteVarianceSum' -- toatalDiscrepancies , absoluteVarianceSum
	 , @orderBy int = 1 -- 0: ASC; 1: DESC


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	DECLARE @todayDate date = getdate()
	DECLARE @openEndDate date = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'OpenEndDate')

	DECLARE @sqlStatement varchar(max)
	DECLARE @sqlWhere varchar(max)

	DECLARE @defaultSort varchar(50) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = ('defaultSort_' + OBJECT_NAME(@@PROCID)))
	
	DECLARE @MemberFirstName varchar(20)
	DECLARE @MemberLastName varchar(30) 


-- *****************************************************************************************************
	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 

	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 0. Split name into first/last  
	-- ******************************
	
	/*

	MemberFirstName	MemberMiddleName	MemberLastName
	SANDRA	A	WOODRING
	JEMELLE	NULL	ONEILL
	RAFAEL	R	ROMAN
	FELIX	I	SANTANA
	*/

	/*
	DECLARE @n  varchar(51) 
	DECLARE @fn varchar(20) 
	DECLARE @ln varchar(30) 

	set @n = 'first last'
	set @n = 'firstOnly'
	
	-- maybe make this a user defined function
	select @n
		, CHARINDEX(' ',@n,1) as spaceLocation
		, SUBSTRING(@n, 1, (CHARINDEX(' ',@n,1) - 1)) as subFirstName
		, SUBSTRING(@n, (CHARINDEX(' ',@n,1) + 1), (len(@n) - (CHARINDEX(' ',@n,1)) ) ) as subLastName
	*/

	-- CHECK A NAME WAS SENT AT ALL
	IF ISNULL(@Name, '') <> ''
		-- If only one name sent, use single name in both first and last tests
		/*
		IF CHARINDEX(' ',@Name,1) = 0
			BEGIN
				set @MemberFirstName = @Name
				set @MemberLastName = @Name
			END 
		ELSE
		*/
		IF CHARINDEX(' ',@Name,1) > 0
		-- If a space is included, split into first and last on the space, assuming search order is {[FirstName][ ][LastName]}
			BEGIN 
				set @MemberFirstName = SUBSTRING(@Name, 1, (CHARINDEX(' ',@Name,1) - 1)) 
				set @MemberLastName  = SUBSTRING(@Name, (CHARINDEX(' ',@Name,1) + 1), (len(@Name) - (CHARINDEX(' ',@Name,1)) ) ) 
			END

	-- print @MemberFirstName 
	-- print @MemberLastName  

	-- ******************************
	-- STEP 1. (base query)  
	-- ******************************

	set @sqlStatement = '
		select 
			  ml.MasterPatientID 
			, ml.MemberFirstName 
			, ml.MemberMiddleName 
			, ml.MemberLastName 
			, ml.MMIS_MMIS_ID 
			, ml.CCAID 
			, ml.Product 
			, ml.EnrollStartDate 
			, ml.EnrollEndDate 
			, ml.DOB 
			, ml.DOD 
			, ml.RatingCategory 
			, ml.Region 
			, ml.MemberEnrollmentStatus 
			, dt.TotalDiscrepancies 
			, datediff(day,dt.DiscrepancyAge, ''' + cast(@spStart as varchar) + ''') as maxAging				  
			, dt.absoluteVarianceSum 
			, d.TotalAssigned
			, count(*) over() as ResultCount
		from MemberList as ml
			left join (
				select MasterPatientID, sum(abs(variance)) as absoluteVarianceSum, min(MemberMonth) as DiscrepancyAge, count(*) as TotalDiscrepancies
				from Discrepancies as d
				inner join DiscrepancyStatuses as ds on ds.DiscrepancyStatusID = d.DiscrepancyStatusID
				inner join DiscrepancyCategories as dc on dc.DiscrepancyCategoryID = ds.DiscrepancyCategoryID
				where dc.DiscrepancyCategoryDisplay = 1
				group by MasterPatientID
			) as dt on dt.MasterPatientID = ml.MasterPatientID

		'
		
	IF @AssigneeID is not null
		BEGIN
			SET @sqlStatement = @sqlStatement + '
					inner join (
				select d.MasterPatientID, d.Assigned_UserID, count(*) as TotalAssigned
				from Discrepancies as d
				inner join DiscrepancyStatuses as ds on ds.DiscrepancyStatusID = d.DiscrepancyStatusID
				inner join DiscrepancyCategories as dc on dc.DiscrepancyCategoryID = ds.DiscrepancyCategoryID
				where dc.DiscrepancyCategoryDisplay = 1
				group by d.MasterPatientID, d.Assigned_UserID
			) as d on d.MasterPatientID = ml.MasterPatientID
			and d.Assigned_UserID = ' + cast(@AssigneeID as varchar)
		END 
	ELSE
		BEGIN
			SET @sqlStatement = @sqlStatement + '
					left join (
				select 
				d.MasterPatientID
				, sum(case when d.Assigned_UserID is null then 0 else 1 end) as TotalAssigned
				, sum(case when d.Assigned_UserID is null then 1 else 0 end) as TotalUnAssigned
				from Discrepancies as d
				inner join DiscrepancyStatuses as ds on ds.DiscrepancyStatusID = d.DiscrepancyStatusID
				inner join DiscrepancyCategories as dc on dc.DiscrepancyCategoryID = ds.DiscrepancyCategoryID
				where dc.DiscrepancyCategoryDisplay = 1
				group by d.MasterPatientID
			) as d on d.MasterPatientID = ml.MasterPatientID
			'
		END

	-- how to join back to get the count of total discrepancies to assignee or all assigned vs not assigned
	-- ******************************
	-- STEP 2. Set where clause based on filters passed.  Have to check each one for when to insert where clause?
	-- ******************************


	IF @MasterPatientID is not null
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + 'ml.MasterPatientID = ' + cast(@MasterPatientID as varchar)
	END 

	IF @CCAID is not null
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + 'ml.CCAID  = ' + cast(@CCAID as varchar)
	END 

	IF isnull(@MMIS_ID,'') <> ''
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + 'ml.MMIS_MMIS_ID  = ''' + @MMIS_ID + ''''
	END

	/*
	IF ISNULL(@Name,'') <> '' 
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + '
			   ml.MemberFirstName  LIKE ''' + @Name + '%''
			OR ml.MemberLastName   LIKE ''' + @Name + '%''
		'
	END
	*/
	
	IF ISNULL(@Name,'') <> '' and ISNULL(@MemberFirstName,'') = '' and ISNULL(@MemberLastName,'') = ''
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + ' (
			   ml.MemberFirstName  LIKE ''' + @Name + '%''
			   OR ml.MemberLastName  LIKE ''' + @Name + '%''
		)'
	END

	
	IF ISNULL(@MemberFirstName,'') <> '' 
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + '
			   ml.MemberFirstName  LIKE ''' + @MemberFirstName + '%''
		'
	END

	IF ISNULL(@MemberLastName,'') <> '' 
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + '
			   ml.MemberLastName  LIKE ''' + @MemberLastName + '%''
		'
	END
	-- was ml
	IF @includeZeroDiscrepancy = 0 
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + '
			   ISNULL(dt.TotalDiscrepancies, 0) <> 0  
		'
	END

	
	IF @sqlWhere IS NOT NULL 
		SET @sqlStatement = @sqlStatement + @sqlWhere

	-- print @sqlWhere


		/*
		-- original
		AND (
			                                                 @todayDate between ccaMem.EnrollStartDate           and isnull(ccaMem.EnrollEndDate, @openEndDate)
			and (ccaMem.RatingCategoryStartDate is null   or @todayDate between ccaMem.RatingCategoryStartDate   and isnull(ccaMem.RatingCategoryEndDate, @openEndDate))
			and (ccaMem.RegionStartDate is null           or @todayDate between ccaMem.RegionStartDate           and isnull(ccaMem.RegionEndDate, @openEndDate))
			and (ccaMem.PatientPayStartDate is null       or @todayDate between ccaMem.PatientPayStartDate       and isnull(ccaMem.PatientPayEndDate, @openEndDate))
			and (ccaMem.PatientSpendDownStartDate is null or @todayDate between ccaMem.PatientSpendDownStartDate and isnull(ccaMem.PatientSpendDownEndDate, @openEndDate))
		)
		*/



	IF (@exportAll = 0) 
	BEGIN

		-- ******************************
		-- STEP 3. Set order by
		-- ******************************

		-- Check valid columns, otherwise, use default sort... need null check as a separate condition
		if isnull(@sortBy,'') = '' or @sortBy not in (
				'TotalAssigned'
				, 'TotalDiscrepancies'
				, 'maxAging'
				, 'absoluteVarianceSum'
			)
			
			set @sortBy = @defaultSort -- may need to check this 


		set @sqlStatement = @sqlStatement + '
			ORDER BY ' + @sortBy + ' ' + CASE @orderBy WHEN 1 THEN 'DESC' ELSE '' END 
			

		-- ******************************
		-- STEP 4. Set pagination, if available
		-- ******************************


		-- FIX THIS
		-- if @pageSize  = '' SET @pageSize  = NULL
		-- if @pageIndex = '' SET @pageIndex = NULL

		-- print @pageSize  
		-- print @pageIndex 


		if (isnumeric(@pageSize) = 1 and isnumeric(@pageIndex) = 1)
			set @sqlStatement = @sqlStatement + '
				OFFSET (' + cast(@pageSize as varchar) + ' * (' + cast(@pageIndex as varchar) + ')) ROWS
				FETCH NEXT ' + cast(@pageSize as varchar) + ' ROWS ONLY;
			'
	END


	-- ******************************
	-- STEP 5. Execute dynamic statement
	-- ******************************


	print @sqlStatement

	exec(@sqlStatement)



	-- select * from vwRateCard
	-- SELECT * FROM CCARATECELLS







	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************

	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()

		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart

		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spGetMemberList] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetMemberList] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetMemberList] TO [webapp] 
GO
-- *****************************************************************************************************