
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyCategories] 
PRINT @returnValue 

EXEC [dbo].[spGetDiscrepancyCategories] 2 
-- no longer relevant
EXEC [dbo].[spGetDiscrepancyCategories] 2, NULL, NULL
EXEC [dbo].[spGetDiscrepancyCategories] 2, 'Working', 1
EXEC [dbo].[spGetDiscrepancyCategories] 2, 'Work'
EXEC [dbo].[spGetDiscrepancyCategories] 2, NULL, 1
EXEC [dbo].[spGetDiscrepancyCategories] 2, NULL, 0

EXEC [dbo].[spGetDiscrepancyCategories] 2 , 0, 2
EXEC [dbo].[spGetDiscrepancyCategories] 2 , 1, 2
EXEC [dbo].[spGetDiscrepancyCategories] 2 , 2, 2



DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyCategories] 
	  @eventUserID = 2 
	, @pageIndex   = 1
	, @pageSize    = 5
	, @sortBy      = '' -- 'DiscrepancyCategoryID' -- may need to check this 
	, @orderBy     = 1 -- 0: ASC; 1: DESC
	
PRINT @returnValue 

SELECT * FROM ExecutionLog ORDER BY ExecutionLogiD DESC

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetDiscrepancyCategories]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetDiscrepancyCategories]
GO

/****** Object:  StoredProcedure [dbo].[spGetDiscrepancyCategories]    Script Date: 08/09/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/09/2019
-- Description:	API 
				Procedure to get Discrepancy Categories list for user interface

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetDiscrepancyCategories]
	-- Add the parameters for the stored procedure here
	  @eventUserID int = NULL

	-- , @DiscrepancyCategoryID int = NULL -- removed per updated API document

	-- NOT IN API EITHER?
	-- , @DiscrepancyCategory varchar(50) = NULL
	-- , @DiscrepancyCategoryDisplay bit = NULL -- 0 = not displayed by default in front end; 1 = always display in front end
	
	-- , @includeAll 1 Active,2 Inactive,3 All
	
	-- maybe move hardcoding into stored procedure, then can check for isnull values
	, @pageIndex int		  = 0
	, @pageSize int			  = NULL
	, @sortBy varchar(50)	  = 'DiscrepancyCategory' -- 'DiscrepancyCategoryID' -- may need to check this 
	, @orderBy int            = 0 -- 0: ASC; 1: DESC

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
	DECLARE @sqlStatement varchar(max)
	DECLARE @sqlWhere varchar(max)

	DECLARE @defaultSort varchar(50) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = ('defaultSort_' + OBJECT_NAME(@@PROCID)))

-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)


	-- ******************************
	-- STEP 1. Set base query
	-- ******************************

	set @sqlStatement = '
		select 
			  dc.DiscrepancyCategoryID
			, dc.DiscrepancyCategory
			, dc.DiscrepancyCategoryDescription
			, dc.DiscrepancyCategoryDisplay
			, dc.ActiveFlag
			, dc.insertDate
			, dc.updateDate
			, count(*) over() as ResultCount 
		from DiscrepancyCategories as dc
		'

	-- ******************************
	-- STEP 2. Set where clause based on filters passed.  Have to check each one for when to insert where clause?
	-- ******************************



	-- ******************************
	-- STEP 3. Set order by
	-- ******************************

	-- Check valid columns, otherwise, use default sort... need null check as a separate condition
	if isnull(@sortBy,'') = '' or @sortBy not in (
			  'DiscrepancyCategoryID'
			, 'DiscrepancyCategory'
			, 'DiscrepancyCategoryDescription'
			, 'DiscrepancyCategoryDisplay'
			, 'ActiveFlag'

		)
		
		set @sortBy = @defaultSort -- may need to check this 


	set @sqlStatement = @sqlStatement + '
		ORDER BY ' + @sortBy + ' ' + CASE @orderBy WHEN 1 THEN 'DESC' ELSE '' END 
		

	-- ******************************
	-- STEP 4. Set pagination, if available
	-- ******************************


	-- FIX THIS
	-- if @pageSize  = '' SET @pageSize  = NULL
	-- if @pageIndex = '' SET @pageIndex = NULL

	-- print @pageSize  
	-- print @pageIndex 


	if (isnumeric(@pageSize) = 1 and isnumeric(@pageIndex) = 1)
		set @sqlStatement = @sqlStatement + '
			OFFSET (' + cast(@pageSize as varchar) + ' * (' + cast(@pageIndex as varchar) + ')) ROWS
			FETCH NEXT ' + cast(@pageSize as varchar) + ' ROWS ONLY;
		'


	-- ******************************
	-- STEP 5. Execute dynamic statement
	-- ******************************

	print @sqlStatement

	exec(@sqlStatement)




	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spGetDiscrepancyCategories] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetDiscrepancyCategories] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetDiscrepancyCategories] TO [webapp] 
GO
-- *****************************************************************************************************