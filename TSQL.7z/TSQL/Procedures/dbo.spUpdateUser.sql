
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spUpdateUser] 
PRINT @returnValue 

-- Full Example Test
DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spUpdateUser] 
	  @eventUserID = 2 
	, @UserID = 18

	, @UserNameAD = 'jbrown'
	, @UserEmail = 'jbrown@celtics.com'
	, @UserFirstName = 'Jaylen'
	, @UserLastName = 'Brown'

	, @RoleAdministrator = 0
	, @RoleHelpdesk = 1
	, @RoleSupervisor = 0
	, @RoleSpecialist = 1

	, @ActiveFlag = 1 


	-- , @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @NewID
PRINT @RetCd



-- Full Example Test
DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spUpdateUser] 
	  @eventUserID = 2 
	, @UserID = 18

	, @RoleAdministrator = 1
	, @RoleHelpdesk = 1
	, @RoleSupervisor = 0
	, @RoleSpecialist = 0

	, @ActiveFlag = 1 


	-- , @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @NewID
PRINT @RetCd

-- Full Example Test
DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spUpdateUser] 
	  @eventUserID = 2 
	, @UserID = 18

	, @UserNameAD = 'jtatum'
	, @UserEmail = 'jtatum@celtics.com'
	, @UserFirstName = 'Jayson'
	, @UserLastName = 'Tatum'

	, @RoleAdministrator = 0
	, @RoleHelpdesk = 1
	, @RoleSupervisor = 0
	, @RoleSpecialist = 1

	, @ActiveFlag = 1 


	-- , @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @NewID
PRINT @RetCd


-- Confirm data tables updated appropriately

EXEC dbo.spGetUsers @UserID = 18 

SELECT * FROM UserRoles
SELECT * FROM Users
SELECT * FROM UserRoleMap

select * from ExecutionLog order by ExecutionLogID desc
select * from UserEventLog order by EventID desc



-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spUpdateUser]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spUpdateUser]
GO

/****** Object:  StoredProcedure [dbo].[spUpdateUser]    Script Date: 09/13/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/13/2019
-- Description:	API
				Procedure for updating a user detail

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spUpdateUser]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0
	@eventUserID int 
	, @UserID int
	, @UserNameAD varchar(50) = NULL
	, @UserEmail varchar(100) = NULL -- 	include parameter: "domain Email address" - store '@commonwealthcare.org' to suffix all UserNameAD to create e-mail address in stored procedure view
	, @UserFirstName varchar(50) = NULL
	, @UserLastName  varchar(50) = NULL

	, @RoleAdministrator bit = NULL
	, @RoleHelpdesk bit = NULL
	, @RoleSupervisor bit = NULL
	, @RoleSpecialist bit = NULL

	, @ActiveFlag bit = NULL 

	-- , @NewIdentity int output
	, @ReturnCode int output



AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
	-- DECLARE @NewIdentity int -- for create only
	-- DECLARE @ReturnCode int -- should this be an established standard
	DECLARE @EventOldData nvarchar(1000)
	DECLARE @EventNewData nvarchar(1000)

	DECLARE @newRoleAdministrator int = (select UserRoleID from UserRoles where UserRole = 'Administrator')
	DECLARE @newRoleHelpdesk      int = (select UserRoleID from UserRoles where UserRole = 'Helpdesk')
	DECLARE @newRoleSupervisor    int = (select UserRoleID from UserRoles where UserRole = 'Supervisor')
	DECLARE @newRoleSpecialist    int = (select UserRoleID from UserRoles where UserRole = 'Specialist')


-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 0. Confirm appropriate values sent
	-- ******************************
	
	if not exists (
		select UserID 
		from Users
		where UserID = @UserID 
	) 
		RAISERROR ('User does not exist for passed: @UserID', 16, 1)

	-- ******************************
	-- STEP 1. Initialize EventResult Table
	-- ******************************


	if object_id('tempdb..#EventResult') is not null
		drop table #EventResult

	create table #EventResult (

		  UserID    int  NOT NULL
		, new_UserNameAD varchar(50) NOT NULL
		, new_UserEmail varchar(100) NULL 
		, new_UserFirstName varchar(50) NULL
		, new_UserLastName  varchar(50) NULL
		, new_ActiveFlag bit NULL

		, old_UserNameAD varchar(50) NOT NULL
		, old_UserEmail varchar(100) NULL 
		, old_UserFirstName varchar(50) NULL
		, old_UserLastName  varchar(50) NULL
		, old_ActiveFlag bit NULL
	)

/*
	-- ******************************
	-- STEP 2. Check if exact entry exists
	
	-- NOTE: avoid this check to avoid conflict because of sub-call to user roles
	-- ******************************


	IF EXISTS (
		select UserID 
		from Users
		where 
			UserID = @UserID 
			AND UserNameAD = @UserNameAD 
			AND UserEmail = @UserEmail 
			AND UserFirstName = @UserFirstName 
			AND UserLastName = @UserLastName  
			AND ActiveFlag = @ActiveFlag 
	)
		Set @ReturnCode = 1
*/


	-- ******************************
	-- STEP 3. Update not exact match

	-- NOTE: Will update with same values if value is not passed
	-- ******************************


		UPDATE Users
			SET 
				  UserNameAD    = case when isnull(@UserNameAD 	  , '') = '' then UserNameAD 	else @UserNameAD 	end
				, UserEmail     = case when isnull(@UserEmail 	  , '') = '' then UserEmail 	else @UserEmail 	end
				, UserFirstName = case when isnull(@UserFirstName , '') = '' then UserFirstName else @UserFirstName end
				, UserLastName  = case when isnull(@UserLastName  , '') = '' then UserLastName  else @UserLastName  end
				, ActiveFlag    = case when isnull(@ActiveFlag    , '') = '' then ActiveFlag    else @ActiveFlag    end
				, updateDate    = @spStart
			OUTPUT
				  inserted.UserID
				, deleted.UserNameAD
				, deleted.UserEmail 
				, deleted.UserFirstName
				, deleted.UserLastName 
				, deleted.ActiveFlag 
				, inserted.UserNameAD
				, inserted.UserEmail 
				, inserted.UserFirstName
				, inserted.UserLastName 
				, inserted.ActiveFlag 
				into #EventResult
		where 
			UserID = @UserID

		Set @ReturnCode = 2


	-- ******************************
	-- STEP 4. Event Log JSON preparation and storage
	-- ******************************

	select @EventOldData = '{
			 "UserID"        :'  + CAST(UserID               as varchar) 
		+ ', "UserNameAD"    :"' + CAST(old_UserNameAD       as varchar) + '"'
		+ ', "UserEmail"     :"' + CAST(old_UserEmail        as varchar) + '"'
		+ ', "UserFirstName" :"' + CAST(old_UserFirstName    as varchar) + '"'
		+ ', "UserLastName"  :"' + CAST(old_UserLastName     as varchar) + '"'
		
		+ ', "ActiveFlag"     :'  + case new_ActiveFlag when 0 then 'false' else 'true' end
		+ '}' 
	from #EventResult

	select @EventNewData = '{
			 "UserID"        :'  + CAST(UserID               as varchar) 
		+ ', "UserNameAD"    :"' + CAST(new_UserNameAD       as varchar) + '"'
		+ ', "UserEmail"     :"' + CAST(new_UserEmail        as varchar) + '"'
		+ ', "UserFirstName" :"' + CAST(new_UserFirstName    as varchar) + '"'
		+ ', "UserLastName"  :"' + CAST(new_UserLastName     as varchar) + '"'
		
		+ ', "ActiveFlag"     :'  + case new_ActiveFlag when 0 then 'false' else 'true' end
		+ '}' 
	from #EventResult

	EXEC spPutUserEventLog @eventUserID, @spProcName, @spStart, @ReturnCode, @EventOldData, @EventNewData

	drop table #EventResult

	-- ******************************
	-- STEP 5. Call user role specific assignments where appropriate
	-- ******************************

	  
		EXEC spPutUserRoleMap
			@eventUserID = @eventUserID
		, @putUserID = @UserID
		, @putUserRoleID = @newRoleAdministrator 
		, @putActiveFlag = @RoleAdministrator

		EXEC spPutUserRoleMap
			@eventUserID = @eventUserID
		, @putUserID = @UserID
		, @putUserRoleID = @newRoleHelpdesk 
		, @putActiveFlag = @RoleHelpdesk 

		EXEC spPutUserRoleMap
			@eventUserID = @eventUserID
		, @putUserID = @UserID
		, @putUserRoleID = @newRoleSupervisor
		, @putActiveFlag = @RoleSupervisor 

		EXEC spPutUserRoleMap
			@eventUserID = @eventUserID
		, @putUserID = @UserID
		, @putUserRoleID = @newRoleSpecialist
		, @putActiveFlag = @RoleSpecialist 




	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spUpdateUser] TO [Talend] 
GRANT EXECUTE ON [dbo].[spUpdateUser] TO [Support] 
GRANT EXECUTE ON [dbo].[spUpdateUser] TO [webapp] 
GO
-- *****************************************************************************************************