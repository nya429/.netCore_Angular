
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [pm].[spProcessObjectManagement] 
PRINT @returnValue 

-- truncate table pm.ObjectManagement
SELECT * FROM pm.ObjectManagement
-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pm].[spProcessObjectManagement]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pm].[spProcessObjectManagement]
GO

/****** Object:  StoredProcedure [pm].[spProcessObjectManagement]    Script Date: 09/09/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		
-- Create date: 09/09/2019
-- Description:	

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [pm].[spProcessObjectManagement]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec_PM' 
	DECLARE @appLogType char(1) = 'A' -- (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO PartnerExchange.dbo.PE_DI_Logs( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Build temp table with all object names
	-- ******************************

	if object_id('tempdb..#allObjects') is not null
		drop table #allObjects


	select 
		  JiraTag	
		, AppSection	
		, ObjectType	
		, ObjectName
		, ObjectFunction	
		, ObjectActive	
		, CodeReview	
		, ObjectStatus	
		, APIStatus 	
		, IntegrationStatus
	into #allObjects
	from (
		select 
			  NULL as JiraTag	
			, NULL as AppSection	
			, NULL as ObjectFunction	
			, 'TABLES' as ObjectType	
			, (schema_name(schema_id) + '.' + name + '.sql') as ObjectName
			, NULL as ObjectActive	
			, NULL as CodeReview	
			, NULL as ObjectStatus	
			, NULL as APIStatus 	
			, NULL as IntegrationStatus
		from sys.tables	 AS t where type = 'U'
	
	
		union all
		select 
			  NULL as JiraTag	
			, NULL as AppSection	
			, NULL as ObjectFunction	
			, 'VIEWS' as ObjectType	
			, (schema_name(schema_id) + '.' + name + '.sql') as ObjectName
			, NULL as ObjectActive	
			, NULL as CodeReview	
			, NULL as ObjectStatus	
			, NULL as APIStatus 	
			, NULL as IntegrationStatus
		from sys.views		 AS v 
	
	
		union all
		select 
			  NULL as JiraTag	
			, NULL as AppSection	
			, NULL as ObjectFunction	
			, 'PROCEDURES' as ObjectType	
			, (schema_name(schema_id) + '.' + name + '.sql') as ObjectName
			, NULL as ObjectActive	
			, NULL as CodeReview	
			, NULL as ObjectStatus	
			, NULL as APIStatus 	
			, NULL as IntegrationStatus
		from sys.procedures AS p 
	) as a

	-- ******************************
	-- STEP 2. Insert objects where found
	-- ******************************


	insert into pm.ObjectManagement (
		  JiraTag	
		, AppSection	
		, ObjectType	
		, ObjectName
		, ObjectFunction	
		, ObjectActive	
		, CodeReview	
		, ObjectStatus	
		, APIStatus 	
		, IntegrationStatus
	)
	select 
		  JiraTag	
		, AppSection	
		, ObjectType	
		, ObjectName
		, ObjectFunction	
		, ObjectActive	
		, CodeReview	
		, ObjectStatus	
		, APIStatus 	
		, IntegrationStatus
	from #allObjects as a
	where not exists (
		select ObjectManagementID
		from pm.ObjectManagement as o
		where 
			o.ObjectType = a.ObjectType
			and o.ObjectName = a.ObjectName
	)




	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update PartnerExchange.dbo.PE_DI_Logs
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO PartnerExchange.dbo.PE_DI_Logs ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update PartnerExchange.dbo.PE_DI_Logs
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO

/*
-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [pm].[spProcessObjectManagement] TO [Talend] 
GRANT EXECUTE ON [pm].[spProcessObjectManagement] TO [Support] 
GO
-- *****************************************************************************************************
*/