
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetUserByAD]  'jlewis'
PRINT @returnValue 

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetUserByAD]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetUserByAD]
GO

/****** Object:  StoredProcedure [dbo].[spGetUserByAD]    Script Date: 09/30/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/30/2019
-- Description:	API
				Get user detail by UserNameAD

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetUserByAD]
	-- Add the parameters for the stored procedure here
	-- @eventUserID int = NULL 
	@UserNameAD varchar(50) -- must be passed


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Get user record based on UserNameAD
	-- ******************************


		select 
			  u.UserID	
			, u.UserNameAD
			, u.UserEmail
			, u.UserFirstName
			, u.UserLastName
			, isnull(purm.Administrator, 0) as Administrator
			, isnull(purm.Helpdesk     , 0) as Helpdesk     
			, isnull(purm.Specialist   , 0) as Specialist   
			, isnull(purm.Supervisor   , 0) as Supervisor   
			-- do we need this detail?
			, u.ActiveFlag
			, u.insertDate
			, u.updateDate
		from users as u
		-- this may need to be thought through more... user roles have to coincide with application access, so release fixes may be required when adding a role?
		left join (
			select 
				  urm.UserID
				, max(case ur.UserRoleID when 1 then urm.ActiveFlag else 0 end) as Administrator
				, max(case ur.UserRoleID when 2 then urm.ActiveFlag else 0 end) as Helpdesk
				, max(case ur.UserRoleID when 3 then urm.ActiveFlag else 0 end) as Supervisor
				, max(case ur.UserRoleID when 4 then urm.ActiveFlag else 0 end) as Specialist
			from UserRoleMap as urm
			inner join UserRoles as ur on ur.UserRoleID = urm.UserRoleID
			group by urm.UserID

		) as purm -- pivoted user role map
			on purm.UserID = u.UserID
		where u.UserNameAD = @UserNameAD




	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spGetUserByAD] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetUserByAD] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetUserByAD] TO [webapp] 
GO
-- *****************************************************************************************************