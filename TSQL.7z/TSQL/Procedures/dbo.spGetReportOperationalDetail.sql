USE [RevRec]
GO


/*
-- *****************************************************************************************************
-- Test Execution Block
EXEC [dbo].[spGetReportOperationalDetail] @month = '2019-01-01'
EXEC [dbo].[spGetReportOperationalDetail] @month = '2019-01-01', @isEnrolled  = 1, @isResolved  = 1
EXEC [dbo].[spGetReportOperationalDetail] @month = '2019-01-01', @isEnrolled  = 1, @isResolved  = 0
EXEC [dbo].[spGetReportOperationalDetail] @month = '2019-01-01', @isEnrolled  = 0, @isResolved  = 0

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetReportOperationalDetail]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetReportOperationalDetail]
SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Yue Song
-- Create date: 05/14/2020
-- Description:	API API IDS-375 (release 1493)
				


-- Modified by:     Yue Song
-- Modified dt:     05/21/2020
-- Description: 	IDS-371 (release 1493) RevRec_Reports_Exclude never enrolled member from the operational report.
					Never-enrolled members has been excluded from GetdiscrepancyList / GetMemberList,  
					in order to let report numbers align with discrepancyList/MemberList,  temprarily 
					exclude never-enrolled member from report results by applying same join clause used by  
					GetdiscrepancyList / GetMemberList.

					IDS-1477 (release 1493) use DiscrepancyCategoryIsResolved as Resolved status indicator
-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetReportOperationalDetail]
	-- Add the parameters for the stored procedure here
	    @userID			               int  = NULL
	  , @month		                   Date = Null
	  , @isEnrolled                    int  = NULL
	  , @isResolved                    int  = NULL
	  /*
	  , @pageIndex int		  = 0
	  , @pageSize int			  = 25
	  , @sortBy varchar(50)	  = '' 
	  , @orderBy int            = 0 -- 0: ASC; 1: DESC
	  */


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	

	--DECLARE @todayDate                     date = getdate()
	--DECLARE @DefaultStartDate		varchar(10) = CONVERT(varchar(10), DATEADD(MONTH, -36, @todayDate), 120)
	--DECLARE @DefaultEndDate			varchar(10) = CONVERT(varchar(10), @todayDate, 120)

	-- Hardcoded values
	--DECLARE @resolvedCategoryIds     varchar(50) = (SELECT DiscrepancyCategoryID FROM discrepancyCategories dc WHERE dc.DiscrepancyCategoryDisplay = 0) -- #TEMP use DiscrepancyCategoryDisplay as resolved categories indicator, should have a delicated indicator 
-- *****************************************************************************************************
	
	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	-- ******************************
	-- STEP 1. Base query
	-- ******************************
	
	 SELECT 
		ds.DiscrepancyStatusID
		, ds.DiscrepancyStatus
		, ISNULL(agg.VarianceCount, 0) AS VarianceCount
		, ISNULL(agg.VarianceSum, 0)   AS VarianceSum
	 FROM 
	 DiscrepancyStatuses ds
	 left join 
	
	 (
		SELECT 
			--ds.DiscrepancyStatus
	   		 ds.DiscrepancyStatusID
			, COUNT(d.DiscrepancyID) AS VarianceCount
			, SUM(Variance)          AS VarianceSum
	   	FROM 
			discrepancies d 
	   		INNER JOIN 
	   		DiscrepancyStatuses     ds ON d.DiscrepancyStatusID = ds.DiscrepancyStatusID
			INNER JOIN 
	   		DiscrepancyCategories dc ON ds.DiscrepancyCategoryID = dc.DiscrepancyCategoryID
			-- LEFT JOIN      -- use left join since currently non_enroll processing is wrong
			INNER JOIN -- IDS-371
			Memberlist m ON d.MasterPatientID = m.MasterPatientID
		WHERE
			d.MemberMonth = @Month
			AND (
				@isEnrolled is null  
				OR ( @isEnrolled =  1 AND m.MemberEnrollmentStatusId  = 1 )  -- 'Currently Enrolled'
				OR ( @isEnrolled =  0 AND ( m.MemberEnrollmentStatusId <> 1 OR m.MemberEnrollmentStatusId IS NULL  ))  -- 'Non Member' 		
			)	
			AND (
				@isResolved is null  
				/**
				OR ( @isResolved = 1 AND  LOWER(dc.DiscrepancyCategory) = LOWER('resolved') ) -- 'resolved'
				OR ( @isResolved = 0 AND  LOWER(dc.DiscrepancyCategory) <> LOWER('resolved') ) -- 'not resolved'
				*/
				-- IDS-1477 
				OR
				dc.DiscrepancyCategoryIsResolved = @isResolved 
			
			)
	   	GROUP BY ds.DiscrepancyStatusID
	) AS agg
	ON agg.DiscrepancyStatusID = ds.DiscrepancyStatusID
	OPTION (RECOMPILE)


	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END

GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
-- GRANT EXECUTE ON [dbo].[spGetReportOperationalDetail] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetReportOperationalDetail] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetReportOperationalDetail] TO [webapp] 
GO
-- *****************************************************************************************************

