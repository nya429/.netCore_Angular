
USE [RevRec]
GO





/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyStatus] 
PRINT @returnValue 

EXEC [dbo].[spGetDiscrepancyStatus] 2, 
EXEC [dbo].[spGetDiscrepancyStatus] 2, NULL, NULL, NULL
EXEC [dbo].[spGetDiscrepancyStatus] 2, 'new', 1, 1
EXEC [dbo].[spGetDiscrepancyStatus] 2, 'new', 1, 1
EXEC [dbo].[spGetDiscrepancyStatus] 2,  'new', 5, 1
EXEC [dbo].[spGetDiscrepancyStatus] 2,  'resol', 5, 1
EXEC [dbo].[spGetDiscrepancyStatus] 2,  'resol', 5, 0
EXEC [dbo].[spGetDiscrepancyStatus] 2,  NULL, 4, 1
EXEC [dbo].[spGetDiscrepancyStatus] 2,  NULL, NULL, 1

EXEC [dbo].[spGetDiscrepancyStatus] 2, NULL, NULL, 1, 0, 25, 'DiscrepancyStatus'
EXEC [dbo].[spGetDiscrepancyStatus] 2, NULL, NULL, 1, 0, 25, 'DiscrepancyCategory'

update discrepancyStatuses 
set DiscrepancyStatusType = 0
WHERE DISCREPANCYstatusID in (1,2)

update discrepancyStatuses 
set ActiveFlag = 0
WHERE DISCREPANCYstatusID in (

20
,21
,22
,23
,24
,25
)

DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyStatus] 
	  @eventUserID = NULL
	, @DiscrepancyStatus     = NULL -- 'Resol'
	, @DiscrepancyCategoryID = NULL
	, @DiscrepancyStatusType = NULL -- 1

	-- maybe move hardcoding into stored procedure, then can check for isnull values
	, @pageIndex = 0
	, @pageSize = 25
	, @sortBy = 'DiscrepancyStatusID' 
	, @orderBy = 1 -- 0: ASC; 1: DESC
PRINT @returnValue 

select * from discrepancystatuses order by DiscrepancyStatusID desc


-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetDiscrepancyStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetDiscrepancyStatus]
GO

/****** Object:  StoredProcedure [dbo].[spGetDiscrepancyStatus]    Script Date: 08/09/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/09/2019
-- Description:	API 
				Procedure to get Discrepancy status list for user interface

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetDiscrepancyStatus]
	-- Add the parameters for the stored procedure here
	  @eventUserID int = NULL
	-- , @DiscrepancyStatusID int = NULL 
	, @DiscrepancyStatus varchar(50) = NULL
	, @DiscrepancyCategoryID int = NULL -- reporting category: i.e. new, resolved, completed... possibly will create another table for this and let the put procedure perform the insert/update to map appropriately
	, @DiscrepancyStatusType bit = NULL -- 0 = system maintenance; 1 = user entered

	-- maybe move hardcoding into stored procedure, then can check for isnull values
	, @pageIndex int		  = 0
	, @pageSize int			  = 25
	, @sortBy varchar(50)	  = 'DiscrepancyStatus' 
	, @orderBy int            = 0 -- 0: ASC; 1: DESC


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	DECLARE @sqlStatement varchar(max)
	DECLARE @sqlWhere varchar(max)

	DECLARE @defaultSort varchar(50) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = ('defaultSort_' + OBJECT_NAME(@@PROCID)))

-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Set base query
	-- ******************************

	set @sqlStatement = '
		select 
			  ds.DiscrepancyStatusID
			, ds.DiscrepancyStatus
			, ds.DiscrepancyStatusDescription
			, ds.DiscrepancyCategoryID
			, ds.DiscrepancyStatusType
			, ds.ActiveFlag
			, ds.insertDate
			, ds.updateDate
			, dc.DiscrepancyCategory
			, dc.DiscrepancyCategoryDescription
			, count(*) over() as ResultCount -- was countRateCard, made generic
		from discrepancyStatuses as ds
		left join DiscrepancyCategories as dc on dc.DiscrepancyCategoryID = ds.DiscrepancyCategoryID
	'

	-- ******************************
	-- STEP 2. Set where clause based on filters passed.  Have to check each one for when to insert where clause?
	-- ******************************

	-- where u.ActiveFlag = 1

	IF isnull(@DiscrepancyStatus, '') <> '' 
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + 'ds.DiscrepancyStatus LIKE ''%' + @DiscrepancyStatus + '%''' 
	END 

	IF @DiscrepancyCategoryID is not null
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + 'dc.DiscrepancyCategoryID = ' + cast(@DiscrepancyCategoryID as varchar) 
	END 

	IF @DiscrepancyStatusType is not null
	BEGIN
		SET @sqlWhere = isnull(@sqlWhere,'') + CASE ISNULL(@sqlWhere,'') WHEN '' THEN ' WHERE ' ELSE ' AND ' END
		SET @sqlWhere = @sqlWhere + 'ds.DiscrepancyStatusType = '+ cast(@DiscrepancyStatusType as varchar) 
	END 

	IF @sqlWhere IS NOT NULL 
		SET @sqlStatement = @sqlStatement + @sqlWhere

	-- print @sqlWhere




	-- ******************************
	-- STEP 3. Set order by
	-- ******************************

	-- Check valid columns, otherwise, use default sort... need null check as a separate condition
	if isnull(@sortBy,'') = '' or @sortBy not in (
			  'DiscrepancyStatusID'
			, 'DiscrepancyStatus'
			, 'DiscrepancyStatusDescription'
			, 'DiscrepancyCategoryID'
			, 'DiscrepancyStatusType'
			, 'ActiveFlag'
			, 'insertDate'
			, 'updateDate'
			, 'DiscrepancyCategory'
			, 'DiscrepancyCategoryDescription'

		)
		
		set @sortBy = @defaultSort -- may need to check this 


	set @sqlStatement = @sqlStatement + '
		ORDER BY ' + @sortBy + ' ' + CASE @orderBy WHEN 1 THEN 'DESC' ELSE '' END 
		

	-- ******************************
	-- STEP 4. Set pagination, if available
	-- ******************************


	-- FIX THIS
	-- if @pageSize  = '' SET @pageSize  = NULL
	-- if @pageIndex = '' SET @pageIndex = NULL

	-- print @pageSize  
	-- print @pageIndex 


	if (isnumeric(@pageSize) = 1 and isnumeric(@pageIndex) = 1)
		set @sqlStatement = @sqlStatement + '
			OFFSET (' + cast(@pageSize as varchar) + ' * (' + cast(@pageIndex as varchar) + ')) ROWS
			FETCH NEXT ' + cast(@pageSize as varchar) + ' ROWS ONLY;
		'


	-- ******************************
	-- STEP 5. Execute dynamic statement
	-- ******************************

	print @sqlStatement

	exec(@sqlStatement)


	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spGetDiscrepancyStatus] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetDiscrepancyStatus] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetDiscrepancyStatus] TO [webapp] 
GO
-- *****************************************************************************************************