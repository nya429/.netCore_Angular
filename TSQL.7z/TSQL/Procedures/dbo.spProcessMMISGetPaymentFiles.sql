
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMMISGetPaymentFiles] 
PRINT @returnValue 


select * 
from MMISFileProcessing
order by ReportType, Product, ReportMonth 

select * -- delete 
from MMISFileProcessing
where ReportMonth = '2018-02-01'

select * from dbo.listParameters 
select * from ExecutionLog order by ExecutionLogID desc
-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spProcessMMISGetPaymentFiles]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spProcessMMISGetPaymentFiles]
GO

/****** Object:  StoredProcedure [dbo].[spProcessMMISGetPaymentFiles]    Script Date: 09/20/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/20/2019
-- Description:	Process for collecting unprocessed files
				Use lookback date for "floor" in listParameters

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spProcessMMISGetPaymentFiles]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
	DECLARE @LookbackDate varchar(50) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'LookbackDate')
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)


	-- ******************************
	-- STEP 1. Get file list per lookback date
	-- ******************************

	-- 	DECLARE @LookbackDate varchar(50) = (select parameterValue from dbo.listParameters where ApplicationName = 'RevRec' and parameterName = 'LookbackDate')
	-- update dbo.listParameters set parameterValue = '2018-01-01' where ApplicationName = 'RevRec' and parameterName = 'LookbackDate'

	if object_id('tempdb..#MMISAllFiles') is not null
		drop table #MMISAllFiles
	
		SELECT 
			ReportName
			, case RIGHT(ReportName,1) when 'A' then 'SCO' when 'B' then 'ICO' else RIGHT(ReportName,1) end AS Product
			, case datediff(month,PaymentPeriodStart, PaymentPeriodEnd) when 0 then 'M' when 2 then 'Q' when 11 then 'A' else cast(datediff(month,PaymentPeriodStart, PaymentPeriodEnd) as varchar) end as ReportType
			, case datediff(month,PaymentPeriodStart, PaymentPeriodEnd) when 0 then PaymentPeriodStart else DATEADD(DAY,1,PaymentPeriodEnd) end AS ReportMonth
			, PaymentPeriodStart
			, PaymentPeriodEnd
			-- , CapitationMonthYear -- this skews results
			, count(*) as ReportRowCount
		into #MMISAllFiles
		from PDRIN.DBO.MMIS8200MDetail
		where -- better way?
			case datediff(month,PaymentPeriodStart, PaymentPeriodEnd) when 0 then PaymentPeriodStart else DATEADD(DAY,1,PaymentPeriodEnd) end >= cast(@LookbackDate as date)
		-- need to pull by month received, not month addressed 		
		-- CapitationMonthYear >= @LookbackDate -- '2019-01-01'
		GROUP BY 
			ReportName
			, case datediff(month,PaymentPeriodStart, PaymentPeriodEnd) when 0 then 'M' when 2 then 'Q' when 11 then 'A' else cast(datediff(month,PaymentPeriodStart, PaymentPeriodEnd) as varchar) end
			, case RIGHT(ReportName,1) when 'A' then 'SCO' when 'B' then 'ICO' else RIGHT(ReportName,1) end 
			, case datediff(month,PaymentPeriodStart, PaymentPeriodEnd) when 0 then PaymentPeriodStart else DATEADD(DAY,1,PaymentPeriodEnd) end 
			, PaymentPeriodStart
			, PaymentPeriodEnd
		
	

	-- ******************************
	-- STEP 2. Get file list where not loaded currently
	-- ******************************

	-- DECLARE @spStart datetime2(3)  = getdate()
	
	insert into MMISFileProcessing (
		-- MMIS specific columns 
		  ReportName          -- char(21)     not null
		, Product             -- char(3)      not null
		, ReportType          -- char(1)      not null -- (M)onthly, (Q)uarterly, (A)nnually
		, ReportMonth         -- date         not null -- month downloaded, will help identify gaps
		, PaymentPeriodStart  -- date         not null
		, PaymentPeriodEnd	  -- date         not null
		, ReportRowCount      -- int          null
		, ProcessIndicator    -- char(1)      not null -- Y - already processed - ignore; N - first time process; R - marked for reprocessing
		, IdentifiedDate      -- datetime2(3) null
		-- , ProcessedDate       -- datetime2(3) null
	)
	select 
		ReportName	
		, Product	
		, ReportType	
		, ReportMonth	
		, PaymentPeriodStart	
		, PaymentPeriodEnd	
		, ReportRowCount
		, 'N' as ProcessIndicator
		, @spStart as IdentifiedDate

	from #MMISAllFiles as a -- order by ReportType, Product, ReportMonth -- , CapitationMonthYear
	where not exists (
		
		select
			  Product	
			, ReportType	
			, ReportMonth	
			, PaymentPeriodStart	
			, PaymentPeriodEnd	
		from MMISFileProcessing as fp
		where
			    fp.Product	            = a.Product	    -- these could be replaced by ReportName         
			and fp.ReportType		    = a.ReportType	-- these could be replaced by ReportName	    
			and fp.ReportMonth		    = a.ReportMonth		    
			and fp.PaymentPeriodStart	= a.PaymentPeriodStart	 
			and fp.PaymentPeriodEnd	    = a.PaymentPeriodEnd	    
	)





	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spProcessMMISGetPaymentFiles] TO [Talend] 
GRANT EXECUTE ON [dbo].[spProcessMMISGetPaymentFiles] TO [Support] 
GO
-- *****************************************************************************************************