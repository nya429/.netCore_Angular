
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessValidation_RateCard] 
PRINT @returnValue 

select * from ExecutionLog order by starttime desc
select * from ValidationLog where RevRecSectionType = 'Rate Card'


-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spProcessValidation_RateCard]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spProcessValidation_RateCard]
GO

/****** Object:  StoredProcedure [dbo].[spProcessValidation_RateCard]    Script Date: 09/09/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 10/04/2019
-- Description:	Will check for overlapping rate card start and end dates

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spProcessValidation_RateCard]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. State insert statement with column headers.  "Union All" each result set to perform the insert.  Should ensure consistency in header usage
	-- ******************************
	
	
	insert into ValidationLog (
		  RevRecSectionType 
		, RevRecTable 
		, TableId 
		, ValidationColumn 
		, ValidationValue 
		, ValidationErrorDescription 

		-- could consider having a "table" of these values to join so not to include in each union select
		, ActiveFlag 
		, insertDate 
		, updateDate 
	)	



	-- ******************************
	-- STEP 2. Identify Rate Card date range overlaps for start date
	-- ******************************

	select
		  'Rate Card' AS RevRecSectionType 
		, 'RateCard' AS RevRecTable 
		, rcOvl.RateCardID AS TableId 
		, 'StartDate' AS ValidationColumn 
		, rcOvl.StartDate AS ValidationValue 
		, 'Overlap in rate card start date' as ValidationErrorDescription 

		, 1 as ActiveFlag 
		, @spStart as insertDate 
		, @spStart as updateDate 

-- 	select 
-- 		rc.RateCardID, rc.CCARateCellID, rc.CCARegionID, rc.StartDate, rc.EndDate, rc.Amount, rc.RateCardLabel, rc.Eligibility, rc.Product, rc.ActiveFlag, rc.insertDate, rc.updateDate
-- 		, rcOvl.RateCardID, rcOvl.CCARateCellID, rcOvl.CCARegionID, rcOvl.StartDate, rcOvl.EndDate, rcOvl.Amount, rcOvl.RateCardLabel, rcOvl.Eligibility, rcOvl.Product, rcOvl.ActiveFlag, rcOvl.insertDate, rcOvl.updateDate
	from RateCard as rc
	inner join RateCard as rcOvl 
		on  rcOvl.CCARateCellID  = rc.CCARateCellID
		and rcOvl.CCARegionID    = rc.CCARegionID 
	where 
		rcOvl.RateCardID <> rc.RateCardID
		/*
		and (
			rcOvl.StartDate between rc.StartDate and rc.EndDate
			or rcOvl.EndDate between rc.StartDate and rc.EndDate
		)
		*/
		and rcOvl.StartDate between rc.StartDate and rc.EndDate
		and rc.ActiveFlag = 1
		and rcOvl.ActiveFlag = 1



	-- ******************************
	-- STEP 3. Identify Rate Card date range overlaps for end date
	-- ******************************
	union all 

	select
		  'Rate Card' AS RevRecSectionType 
		, 'RateCard' AS RevRecTable 
		, rcOvl.RateCardID AS TableId 
		, 'EndDate' AS ValidationColumn 
		, rcOvl.EndDate AS ValidationValue 
		, 'Overlap in rate card end date' as ValidationErrorDescription 

		, 1 as ActiveFlag 
		, @spStart as insertDate 
		, @spStart as updateDate 

-- 	select 
-- 		rc.RateCardID, rc.CCARateCellID, rc.CCARegionID, rc.StartDate, rc.EndDate, rc.Amount, rc.RateCardLabel, rc.Eligibility, rc.Product, rc.ActiveFlag, rc.insertDate, rc.updateDate
-- 		, rcOvl.RateCardID, rcOvl.CCARateCellID, rcOvl.CCARegionID, rcOvl.StartDate, rcOvl.EndDate, rcOvl.Amount, rcOvl.RateCardLabel, rcOvl.Eligibility, rcOvl.Product, rcOvl.ActiveFlag, rcOvl.insertDate, rcOvl.updateDate
	from RateCard as rc
	inner join RateCard as rcOvl 
		on  rcOvl.CCARateCellID  = rc.CCARateCellID
		and rcOvl.CCARegionID    = rc.CCARegionID 
	where 
		rcOvl.RateCardID <> rc.RateCardID
		and rcOvl.EndDate between rc.StartDate and rc.EndDate
		and rc.ActiveFlag = 1
		and rcOvl.ActiveFlag = 1






	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spProcessValidation_RateCard] TO [Talend] 
GRANT EXECUTE ON [dbo].[spProcessValidation_RateCard] TO [Support] 
GO
-- *****************************************************************************************************