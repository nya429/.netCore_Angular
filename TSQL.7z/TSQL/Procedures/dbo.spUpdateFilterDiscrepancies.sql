
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spUpdateFilterDiscrepancies] 
PRINT @returnValue 

declare @SendAssigneeIDs as dbo.BulkID
insert into @SendAssigneeIDs (
	updateID
)
values (1)
, (2)

declare @SendMemberMonths as dbo.BulkDate
insert into @SendMemberMonths (
	updateDate
)
values ('2019-05-01')

/*
EXEC [dbo].[spUpdateFilterDiscrepancies]
	@AssigneeIDs = @SendAssigneeIDs 

EXEC [dbo].[spUpdateFilterDiscrepancies]
	@CCARateCellIDs = @SendAssigneeIDs 

EXEC [dbo].[spUpdateFilterDiscrepancies]
	@DiscrepancyStatusIDs = @SendAssigneeIDs 
*/



DECLARE @returnValue as INT, @NewID int, @RetCd int

EXEC [dbo].[spUpdateFilterDiscrepancies]
	  @eventUserID = 2
	, @CCAID				  = NULL
	, @MMIS_ID				  = NULL
	, @MasterPatientID		  = NULL
	, @Months = @SendMemberMonths 
	-- , @Programs				  
	-- , @CCARateCellIDs		  
	-- , @DiscrepancyStatusIDs	  
	, @AssigneeIDs = @SendAssigneeIDs 
	, @hasComment			  = 0 -- NULL -- 0: No; 1: Yes
	, @discoverDateStart	  = '2019-09-04'
	, @discoverDateEnd		  = '2019-09-30'
	, @resolutionDateStart	  = NULL
	, @resolutionDateEnd	  = NULL

	, @DiscrepancyStatusId = 14
	, @Assigned_UserID = 4
	, @DueDate = '2019-09-26'

	, @DiscrepancyComment = 'Filter test test here... this could be crazy'

	, @ReturnCode = @RetCd  output
	
	-- Confirm proper results returned
	PRINT @returnValue
	PRINT @RetCd


	-- validate results
	select * from discrepancies          where updatedate > '2019-09-23'
	select * from discrepanciescomments	 where updatedate > '2019-09-23'
	select * from discrepancystatuses


-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spUpdateFilterDiscrepancies]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spUpdateFilterDiscrepancies]
GO

/****** Object:  StoredProcedure [dbo].[spUpdateFilterDiscrepancies]    Script Date: 09/22/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/22/2019
-- Description:	API
				Used to update discrepancy status via a filter

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spUpdateFilterDiscrepancies]
	-- Add the parameters for the stored procedure here
	@eventUserID int 
	, @CCAID				  bigint = NULL
	, @MMIS_ID				  char(12) = NULL
	, @MasterPatientID		  int = NULL
	, @Months				  dbo.BulkDate readonly   	-- , @Months				  date = NULL -- List
	, @Programs				  dbo.BulkString readonly 	-- , @Programs				  char(3) = NULL -- List
	, @CCARateCellIDs		  dbo.BulkID readonly	  	-- , @CCARateCellIDs		  int = NULL -- List
	, @DiscrepancyStatusIDs	  dbo.BulkID readonly	  	-- , @DiscrepancyStatusIDs	  int = NULL -- List
	, @AssigneeIDs            dbo.BulkID readonly	  	-- , @AssigneeIDs			  int = NULL -- List
	, @hasComment			  int = NULL -- 0: No; 1: Yes
	, @discoverDateStart	  date = NULL
	, @discoverDateEnd		  date = NULL

	-- Questionable API columns
	, @resolutionDateStart	  date = NULL -- if resolved, should we be updating
	, @resolutionDateEnd	  date = NULL -- if resolved, should we be updating
	, @DiscrepancyIDs dbo.BulkID readonly -- if they chose individual discrepancies, shouldn't we use the other API/procedure

	-- parameters used for updating
	, @DiscrepancyStatusId int = NULL 
	, @Assigned_UserID int = NULL
	, @DueDate date = NULL
	, @DiscrepancyComment varchar(2000) = NULL
	
	, @ReturnCode int output



AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
	DECLARE @RetCd int
	DECLARE @SendDiscrepancyIDs as dbo.BulkID
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)


	-- ******************************
	-- STEP 1. Get discrepancy IDs based on filter(s) provided.
	-- ******************************
	if exists(select UpdateID from @DiscrepancyIDs)
		begin
			insert into @SendDiscrepancyIDs (
				updateID
			)
			select d.DiscrepancyID
			from Discrepancies as d
			inner join @DiscrepancyIDs as dl on dl.UpdateID = d.DiscrepancyID -- do this join to verify IDs passed are appropriate
			
			-- print 'found exact'
		end
	else
		begin
		
			-- print 'using filter'
			
			insert into @SendDiscrepancyIDs (
				updateID
			)
			select d.DiscrepancyID
			from Discrepancies as d
			inner join vwMemberMap as mm on mm.MasterPatientID = d.MasterPatientID
			left join DiscrepancyStatuses as ds on ds.DiscrepancyStatusID = d.DiscrepancyStatusID
			left join users as uAct on uAct.UserID = d.Action_UserID
			left join users as uAss on uAss.UserID = d.Assigned_UserID

				-- join for actual vaulues... maybe reevaluate pulling it into discrepancies table itself
				left join MMISRateCells	 AS mmisrc  on mmisrc.MMISRateCellID   = d.MMISRateCellID
				left join MMISRegions	 AS mmisreg on mmisreg.MMISRegionID    = d.MMISRegionID
				left join CCARateCells	 AS ccarc   on ccarc.CCARateCellID     = d.CCARateCellID
				left join CCARegions     AS ccareg  on ccareg.CCARegionID      = d.CCARegionID 
				-- left join MMISMemberData as mmismem on mmismem.MasterPatientID = d.MasterPatientID

					-- bulk tables - could not handle dynamically
					left join @Months as paramMonths on paramMonths.UpdateDate = d.MemberMonth
				 -- left join @Programs as paramPrograms on paramPrograms.UpdateString = d.
					left join @CCARateCellIDs as paramCCARC on paramCCARC.UpdateID = d.CCARateCellID
					left join @DiscrepancyStatusIDs as paramDiscID on paramDiscID.UpdateID = d.DiscrepancyID
					left join @AssigneeIDs as paramAssign on paramAssign.UpdateID = d.Assigned_UserID
	
			WHERE (
					@CCAID is null
					OR mm.CCAID  = cast(@CCAID as varchar)
				)

				AND (
					isnull(@MMIS_ID,'') = ''
					OR mm.MMIS_MMIS_ID  = @MMIS_ID 
				)

				AND (
					@MasterPatientID is null
					OR d.MasterPatientID = cast(@MasterPatientID as varchar)
				)
				AND (
					not exists (select UpdateDate from @Months)
					or paramMonths.UpdateDate is not null

				)
				-- @Programs as paramPrograms 
				AND (
					not exists (select UpdateID from @CCARateCellIDs)
					or paramCCARC.UpdateID is not null
				)
				AND (
					NOT EXISTS (select UpdateID from @DiscrepancyStatusIDs)
					or paramDiscID.UpdateID is not null
				)
				AND (
					NOT EXISTS (select UpdateID from @AssigneeIDs) 
					or paramAssign.UpdateID is not null
				) 
				AND (
					@hasComment IS NULL 
					or (
						@hasComment = 0
						and not exists (select DiscrepancyID from DiscrepanciesComments as dc where dc.DiscrepancyID = d.DiscrepancyID)
					)
					or (
						@hasComment = 1
						and exists (select DiscrepancyID from DiscrepanciesComments as dc where dc.DiscrepancyID = d.DiscrepancyID)
					)
				)
				AND (
					(@discoverDateStart IS NULL OR @discoverDateEnd IS NULL)
					OR D.insertDate BETWEEN @discoverDateStart and @discoverDateEnd 
				)
				AND (
					(@resolutionDateStart IS NULL OR @resolutionDateEnd IS NULL)
					OR D.ResolvedDate BETWEEN @resolutionDateStart and @resolutionDateEnd 
				)
		end

		-- select * from @SendDiscrepancyIDs


	-- ******************************
	-- STEP 2. Update discrepancy based on IDs identified in step 1
	-- ******************************
	

	-- Re-use bulk disrepancy stored procedure
	-- DECLARE @returnValue as INT, @NewID int, @RetCd int
	-- EXEC @returnValue = [dbo].[spUpdateBulkDiscrepancies] 

	EXEC [dbo].[spUpdateBulkDiscrepancies] 
		  @eventUserID = @eventUserID
		, @DiscrepancyIDs = @SendDiscrepancyIDs

		, @DiscrepancyStatusId = @DiscrepancyStatusId
		, @Assigned_UserID = @Assigned_UserID
		, @DueDate = @DueDate

		, @DiscrepancyComment = @DiscrepancyComment

		, @ReturnCode = @RetCd  output
	
	-- Confirm proper results returned
	-- PRINT @returnValue
	-- PRINT @RetCd

	
	SET @ReturnCode = @RetCd



	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spUpdateFilterDiscrepancies] TO [Talend] 
GRANT EXECUTE ON [dbo].[spUpdateFilterDiscrepancies] TO [Support] 
GRANT EXECUTE ON [dbo].[spUpdateFilterDiscrepancies] TO [webapp] 
GO
-- *****************************************************************************************************