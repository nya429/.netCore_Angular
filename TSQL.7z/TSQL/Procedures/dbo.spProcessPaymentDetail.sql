
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessPaymentDetail] 
PRINT @returnValue 

select top 100 * from PaymentDetail
select count(*) from PaymentDetail
select * from ExecutionLog order by ExecutionLogID desc
-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spProcessPaymentDetail]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spProcessPaymentDetail]
GO

/****** Object:  StoredProcedure [dbo].[spProcessPaymentDetail]    Script Date: 10/09/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 10/09/2019
-- Description:	Process for reloading PaymentDetail.  Primarily used in MonthlySummaryRecord.

				Post QA - 10/16/2019
					Need to consider PaymentIndicator to either use values sent from state or zero out
					Will continue to use raw Paid amount from state in case there is a true variance from state where they say there is a full take back and there is not


-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	0:19 seconds 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spProcessPaymentDetail]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Truncate PaymentDetail
	-- ******************************

	EXEC [dbo].[spTrun_PaymentDetail] 

	-- ******************************
	-- STEP 2. Insert into stage table PaymentDetail
	-- ******************************

	insert into PaymentDetail (
		Product
		, ReportType
		, ReportMonth
		, MemberID
		, CapitationMonthYear
		, RateCell
		, MCRegion
		, BaseCapitationAmount
		, Paid
		, PatientPay
		, SpendDown
		, Remit
		, RateCardID
		, CCARateCell
		, CCARateCellID
		, CCARegion
		, CCARegionID
		, StartDate
		, EndDate
		, Amount
		, ActiveFlag
		, rnCurrentPaidAmount
	)
	SELECT 
		Product
		, ReportType
		, ReportMonth
		, MemberID
		, CapitationMonthYear
		, case when PaymentIndicator <> 0 then RateCell else '99' end as RateCell
		, case when PaymentIndicator <> 0 then MCRegion else 'NA' end as MCRegion 
		, case when PaymentIndicator <> 0 then BaseCapitationAmount else 0.00 end as BaseCapitationAmount 
		, Paid
		, case when PaymentIndicator <> 0 then PatientPay else 0.00 end as PatientPay 
		, case when PaymentIndicator <> 0 then SpendDown else 0.00 end as SpendDown 
		, Remit
		-- willl this work as expected... if not a payment, do not want a match
		, case when PaymentIndicator <> 0 then RateCardID	   else NULL end as RateCardID	   
		, case when PaymentIndicator <> 0 then CCARateCell	   else NULL end as CCARateCell	   
		, case when PaymentIndicator <> 0 then CCARateCellID	   else NULL end as CCARateCellID	   
		, case when PaymentIndicator <> 0 then CCARegion		   else NULL end as CCARegion		   
		, case when PaymentIndicator <> 0 then CCARegionID	   else NULL end as CCARegionID	   
		, case when PaymentIndicator <> 0 then StartDate		   else NULL end as StartDate		   
		, case when PaymentIndicator <> 0 then EndDate		   else NULL end as EndDate		   
		, case when PaymentIndicator <> 0 then Amount		   else NULL end as Amount		   
		, case when PaymentIndicator <> 0 then ActiveFlag       else NULL end as ActiveFlag       
		, rnCurrentPaidAmount
	FROM vwPaymentDetail
	where rnCurrentPaidAmount = 1



	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spProcessPaymentDetail] TO [Talend] 
GRANT EXECUTE ON [dbo].[spProcessPaymentDetail] TO [Support] 
GO
-- *****************************************************************************************************