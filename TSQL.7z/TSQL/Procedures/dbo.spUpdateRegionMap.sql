
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spUpdateRegionMap] 
PRINT @returnValue 

DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spUpdateRegionMap] 
	  @eventUserID = 2
	, @RegionMapID = 6 -- 
	, @CCARegionID = 2 -- test w/1, was 2
	-- , @MMISRegionID int -- must be sent
	, @ActiveFlag = 1 -- default to 1 for active

	-- , @NewIdentity int output
	, @ReturnCode = @RetCd  output

-- Confirm proper results returned
PRINT @returnValue
PRINT @NewID
PRINT @RetCd

-- Confirm data tables updated appropriately
select * from    regionmap
select * from  vwregionmap
select * from ccaregions
select * from ExecutionLog order by ExecutionLogID desc
select * from UserEventLog order by EventID desc


-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spUpdateRegionMap]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spUpdateRegionMap]
GO

/****** Object:  StoredProcedure [dbo].[spUpdateRegionMap]    Script Date: 08/28/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/28/2019
-- Description:	API
				Routine for updating an existing region map
				Setup to only change CCA Region, mapped to an MMIS Region that will remain static with the Map ID

				Post Unit-test 10/10/2019
					Corrected for using wrong execution log

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spUpdateRegionMap]
	-- Add the parameters for the stored procedure here
	  @eventUserID int
	, @RegionMapID int -- must be sent
	, @CCARegionID int -- must be sent
	-- , @MMISRegionID int -- must be sent
	, @ActiveFlag  bit = 1 -- default to 1 for active

	-- , @NewIdentity int output
	, @ReturnCode int output


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	DECLARE @EventOldData nvarchar(1000)
	DECLARE @EventNewData nvarchar(1000)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Initialize EventResult Table
	-- ******************************


	if object_id('tempdb..#EventResult') is not null
		drop table #EventResult

	create table #EventResult (

		  RegionMapID           int not null
			
		, old_CCARegionID	    int null
		, old_MMISRegionID		int null
		, old_ActiveFlag        bit NULL		

		, new_CCARegionID	    int null
		, new_MMISRegionID		int null
		, new_ActiveFlag        bit NULL		
		
	)


	-- ******************************
	-- STEP 2. Check if exact entry exists
	-- ******************************

	IF EXISTS (
		select RegionMapID 
		from RegionMap
		where 
			    RegionMapID	    = @RegionMapID
			and CCARegionID	    = @CCARegionID
			and ActiveFlag		= @ActiveFlag
	)
		set @ReturnCode = 1

	-- ******************************
	-- STEP 3. Update if not exact
	-- ******************************

	ELSE 	
		BEGIN UPDATE RegionMap
				SET 
					CCARegionID	= @CCARegionID
					, ActiveFlag = @ActiveFlag
					, updateDate = @spStart
			output
				inserted.RegionMapID        
				, deleted.CCARegionID
				, deleted.MMISRegionID
				, deleted.ActiveFlag   
				, inserted.CCARegionID
				, inserted.MMISRegionID
				, inserted.ActiveFlag   
			into #EventResult
			where RegionMapID	    = @RegionMapID

			set @ReturnCode = 2
		END 

	-- ******************************
	-- STEP 5. Event Log JSON preparation and storage
	-- ******************************


-- @EventOldData
	select @EventOldData = '{
		     "RegionMapID"    :' + CAST(RegionMapID         AS VARCHAR)
		+ ', "CCARegionID"    :' + CAST(old_CCARegionID 	AS VARCHAR) 
		+ ', "MMISRegionID"   :' + CAST(old_MMISRegionID	AS VARCHAR) 
		+ ', "ActiveFlag"     :' + case old_ActiveFlag when 0 then 'false' else 'true' end
		+ '}' -- as EventOldData
	from #EventResult


-- @EventNewData
	select @EventNewData = '{
		     "RegionMapID"    :' + CAST(RegionMapID         AS VARCHAR)
		+ ', "CCARegionID"    :' + CAST(new_CCARegionID 	AS VARCHAR) 
		+ ', "MMISRegionID"   :' + CAST(new_MMISRegionID	AS VARCHAR) 
		+ ', "ActiveFlag"     :' + case new_ActiveFlag when 0 then 'false' else 'true' end
		+ '}' -- as EventNewData
	from #EventResult
	

	EXEC spPutUserEventLog @eventUserID, @spProcName, @spStart, @ReturnCode, @EventOldData, @EventNewData






	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spUpdateRegionMap] TO [Talend] 
GRANT EXECUTE ON [dbo].[spUpdateRegionMap] TO [Support] 
GRANT EXECUTE ON [dbo].[spUpdateRegionMap] TO [webapp] 
GO
-- *****************************************************************************************************