
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMemberInfo] @MasterPatientID = 5
PRINT @returnValue 

EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 7
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 70
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 7000
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 777

-- some latency... may want to explore joins in view or staging data

-- select top 10 * from discrepancies
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 205
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 27
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 125
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 219

-- not all assigned
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 1397   
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 10102  
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 41074  
EXEC [dbo].[spGetMemberInfo] @MasterPatientID = 51673  
-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetMemberInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetMemberInfo]
GO

/****** Object:  StoredProcedure [dbo].[spGetMemberInfo]    Script Date: 08/28/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/28/2019
-- Description:	API
				Procedure for returning specific member set
				Returns latest member detail
				Expect only one row to be returned

				Unit test observation - 09/17/2019
					Rating Category (unsplit Ratingcategory with both Rate Cell and Region is returned) 
						will discuss removing, but think it is acceptable to remain this way

				Post Unit Test - API Feature request - 09/23/2019
					Return TotalAssigned count for discrepancies (by member)

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetMemberInfo]
	-- Add the parameters for the stored procedure here
	@eventUserID int = NULL
	, @MasterPatientID int -- must be sent

	/*
	-- required for single row?
	-- maybe move hardcoding into stored procedure, then can check for isnull values
	, @pageIndex int		  = 0
	, @pageSize int			  = 25
	, @sortBy varchar(50)	  = 'MasterPatientID' 
	, @orderBy int            = 1 -- 0: ASC; 1: DESC
	*/

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Get Member info based on passed master patient ID
	-- ******************************

	select 
		  m.MasterPatientID
		, m.CCAID
		, m.MMIS_MMIS_ID
		, m.MemberFirstName
		, m.MemberMiddleName
		, m.MemberLastName
		, m.Gender
		, m.DOB
		, m.DOD
		, m.Product
		, m.EnrollStartDate
		, m.EnrollEndDate
		, m.RatingCategory
		, m.RatingCategoryStartDate
		, m.RatingCategoryEndDate
		, m.Region
		, m.RegionStartDate
		, m.RegionEndDate
		, m.PatientPay
		, m.PatientPayStartDate
		, m.PatientPayEndDate
		, m.PatientSpendDown
		, m.PatientSpendDownStartDate
		, m.PatientSpendDownEndDate
		, m.RateCardID
		, m.CCARateCellID
		, m.CCARegionID
		, m.Amount
		, m.StartDate
		, m.EndDate
		, m.ActiveFlag
		, m.MemberEnrollmentStatus
		, ml.totalDiscrepancies
		, ml.maxAging
		, ml.absoluteVarianceSum
		, d.TotalAssigned
		-- , count(*) over() as ResultCount -- for API paging; required for single row?
	from MemberList as ml
	inner join vwMemberData as m on m.MasterPatientID = ml.MasterPatientID
	left join (
		select 
		MasterPatientID
		, sum(case when Assigned_UserID is null then 0 else 1 end) as TotalAssigned
		, sum(case when Assigned_UserID is null then 1 else 0 end) as TotalUnAssigned
		from Discrepancies
		group by MasterPatientID
	) as d on d.MasterPatientID = m.MasterPatientID

	-- from MemberList as m
	where m.MasterPatientID = @MasterPatientID

	-- should validation be put here in case more than one result is returned?

	/*
	ORDER BY 1 -- @sortBy -- MasterPatientID -- CASE WHEN @orderBy = 1 THEN MasterPatientID DESC ELSE MasterPatientID END
	
	-- apply page retrieval 
	OFFSET (@pageSize * (@pageIndex - 1)) ROWS
	FETCH NEXT @pageSize ROWS ONLY;
	*/


	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spGetMemberInfo] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetMemberInfo] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetMemberInfo] TO [webapp] 
GO
-- *****************************************************************************************************