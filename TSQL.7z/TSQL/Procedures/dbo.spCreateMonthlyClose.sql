
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spCreateMonthlyClose] 
PRINT @returnValue 

DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spCreateMonthlyClose] 
	  @eventUserID = 2 

	, @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @NewID
PRINT @RetCd


-- truncate table MonthlyCloseHeader
-- truncate table MonthlyCloseRecord
-- select * from dbo.listParameters
-- UPDATE MonthlyCloseHeader SET ReportMonth = '2019-08-01' WHERE MonthlyCloseHeaderID = 2

-- Confirm data tables updated appropriately
select * from MonthlyCloseHeader
select top 10 * from MonthlyCloseRecord WHERE MonthlyCloseHeaderID = (SELECT MAX(MonthlyCloseHeaderID) AS MAX_MonthlyCloseHeaderID FROM MonthlyCloseHeader)
select count(*) from MonthlyCloseRecord
select count(*) from MonthlyCloseRecord
select * from ExecutionLog order by ExecutionLogID desc
select * from UserEventLog order by EventID desc

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spCreateMonthlyClose]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spCreateMonthlyClose]
GO

/****** Object:  StoredProcedure [dbo].[spCreateMonthlyClose]    Script Date: 09/22/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/22/2019
-- Description:	Process for closing monthly process and providing data for Finance data warehouse

-- Modified by: Jonathan Lewis
-- Modified dt: 10/31/2019
-- Description: ADS-2937
				Added raw column values


-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spCreateMonthlyClose]
	-- Add the parameters for the stored procedure here
	  @eventUserID int 

	, @NewIdentity int output
	, @ReturnCode int output


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
	DECLARE @CloseMonth date 

	DECLARE @EventOldData nvarchar(1000)
	DECLARE @EventNewData nvarchar(1000)

-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Get close details from monthly summary record
	-- ******************************

	select @CloseMonth = max(ReportMonth) from MMISFileProcessing

	-- ******************************
	-- STEP 2. Confirm Report Month not already processed
	-- ******************************

	if exists (select ReportMonth from MonthlyCloseHeader where ReportMonth = @CloseMonth)
	BEGIN
		-- RAISERROR ('Monthly Process already complete, cannot process', 16, 1)
		set @ReturnCode = 1
		set @NewIdentity = (select MonthlyCloseHeaderID from MonthlyCloseHeader where ReportMonth = @CloseMonth)

	END
	-- ******************************
	-- STEP 3. Insert Header detail for close record
	-- ******************************
	
	else
	BEGIN
		insert into MonthlyCloseHeader (
			  UserID 
			, ReportMonth
			, ProcessIndicator     
			, ActiveFlag 
			, insertDate 
			, updateDate 
		)
		values (
			@eventUserID --   UserID 
			, @CloseMonth -- , ReportMonth 
			, 'N' -- ProcessIndicator     
			, 1 -- , ActiveFlag 
			, @spStart -- , insertDate 
			, @spStart -- , updateDate 
		)

		set @NewIdentity = @@identity
		
		
	-- ******************************
	-- STEP 4. Insert Details for close record
	-- ******************************

	-- msr.MonthlySummaryRecordID -- this key will actually get re-run when next monthly summary record run

	insert into MonthlyCloseRecord (
		  MonthlyCloseHeaderID  
		, MasterPatientID
		, MMIS_ID
		, MemberMonth
		, Variance
		, PaymentError
		, BaseCapitationAmount
		, PatientPayAmountN
		, PatientPayAmountSCO
		, PaidCapitationAmount
		, Remit
		, CCARateCellID
		, CCARegionID
		, CCAPatientPay
		, CCAPatientSpendDown
		, CCARateCardID
		, CCAAmount
		, CCANetAmount
		, MMISRateCellID
		, MMISRegionID
		, MMISPatientPay
		, MMISPatientSpendDown
		, MMISRateCardID
		, MMISAmount
		, MMISNetAmount
		, rawMMISRateCell 
		, rawMMISRegion 
		, rawCCARateCell
		, rawCCARegion 

	)


	select 
		@NewIdentity
		, msr.MasterPatientID
		, msr.MMIS_ID
		, msr.MemberMonth
		, msr.Variance
		, msr.PaymentError
		, msr.BaseCapitationAmount
		, msr.PatientPayAmountN
		, msr.PatientPayAmountSCO
		, msr.PaidCapitationAmount
		, msr.Remit
		, msr.CCARateCellID
		, msr.CCARegionID
		, msr.CCAPatientPay
		, msr.CCAPatientSpendDown
		, msr.CCARateCardID
		, msr.CCAAmount
		, msr.CCANetAmount
		, msr.MMISRateCellID
		, msr.MMISRegionID
		, msr.MMISPatientPay
		, msr.MMISPatientSpendDown
		, msr.MMISRateCardID
		, msr.MMISAmount
		, msr.MMISNetAmount
		, msr.rawMMISRateCell 
		, msr.rawMMISRegion 
		, msr.rawCCARateCell
		, msr.rawCCARegion 
	from MonthlySummaryRecord as msr
	
	set @ReturnCode = 3



		
	-- ******************************
	-- STEP 4. Update Header record to indicate process completed
	-- ******************************

	update MonthlyCloseHeader
		set ProcessIndicator = 'Y'
	WHERE MonthlyCloseHeaderID  = @NewIdentity
	 

	END



	-- ******************************
	-- STEP 5. Event Log JSON preparation and storage
	-- ******************************

	select @EventNewData = '{
		     "MonthlyCloseHeaderID"          :'  + CAST(@NewIdentity  as varchar) 
		+ ', "ReportMonth" 		             :"' + CAST(@CloseMonth   as varchar) + '"'
		+ '}' 


	EXEC spPutUserEventLog @eventUserID, @spProcName, @spStart, @ReturnCode, @EventOldData, @EventNewData


	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spCreateMonthlyClose] TO [Talend] 
GRANT EXECUTE ON [dbo].[spCreateMonthlyClose] TO [Support] 
GO
-- *****************************************************************************************************