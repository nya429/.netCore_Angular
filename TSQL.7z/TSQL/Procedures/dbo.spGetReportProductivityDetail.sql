USE [RevRec]
GO


/*
-- *****************************************************************************************************
-- Test Execution Block
EXEC [dbo].[spGetReportProductivityDetail] 1, 1, 'D' , '2020-04-27', '2020-06-05'
EXEC [dbo].[spGetReportProductivityDetail] 1, 36, 'W', '2020-05-01', '2020-06-03'
EXEC [dbo].[spGetReportProductivityDetail] 1, 1, 'M', '2020-05-01', '2020-07-01'


-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetReportProductivityDetail]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetReportProductivityDetail]
SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Yue Song
-- Create date: 05/29/2020
-- Description:	API IDS-375 
				


-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetReportProductivityDetail]
	-- Add the parameters for the stored procedure here
	    @eventUserID	 int  = NULL
	  , @userID			 int  = NULL
	  , @checkPointType  varchar(1) = NULL   -- D: 'daily'  ;  W: 'weekly'  ; M: 'monthly'  
	  , @startDate		 Date = Null
      , @endDate		 Date = Null  
	  
	  
	  , @pageIndex int		  = 0
	  , @pageSize int		  = 25
	  , @sortBy varchar(50)	  = '' 
	  , @orderBy int          = 0 -- 0: ASC; 1: DESC
	  


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	

	DECLARE @todayDate                     date = getdate()
	-- the first day of the current month
	DECLARE @DefaultStartDate		       date = ISNULL(
															(CASE
																	WHEN  @checkPointType = 'W' THEN (DATEADD(day, 1-DATEPART(WEEKDAY,  @startDate),  @startDate))
																	WHEN  @checkPointType = 'M' THEN DATEADD(month, DATEDIFF(month, 0, @startDate), 0)
																	ELSE @startDate
															END),
															DATEADD(month, DATEDIFF(month, 0, @todayDate), 0)
														 ) 
	-- ISNULL(@startDate, CONVERT(varchar(10), DATEADD(day, -30, @todayDate), 120))
	-- the first day of the current month
	DECLARE @DefaultEndDate			       date = ISNULL(@endDate,   @todayDate) 

	--DECLARE @sqlStatement           NVARCHAR(MAX)
	--DECLARE @cols                   NVARCHAR(MAX)
	--DECLARE @colsIsNull             NVARCHAR(MAX)
	
	-- Hardcoded values
	--DECLARE @resolvedCategoryIds     varchar(50) = (SELECT DiscrepancyCategoryID FROM discrepancyCategories dc WHERE dc.DiscrepancyCategoryDisplay = 0) -- #TEMP use DiscrepancyCategoryDisplay as resolved categories indicator, should have a delicated indicator 
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	IF OBJECT_ID( 'tempdb..#DC' ) IS NOT NULL DROP TABLE #DC
	IF OBJECT_ID( 'tempdb..#T'  ) IS NOT NULL DROP TABLE #T 
	IF OBJECT_ID( 'tempdb..#TC' ) IS NOT NULL DROP TABLE #TC
	-- ******************************
	-- STEP 1. Store Check Points
	-- ******************************
	BEGIN
	    SELECT 
		     DATEADD(day, -1, @DefaultStartDate) [Date]
			 , DATEADD(day,  0, @DefaultStartDate)  [NextDate]
		INTO #DC

		IF @checkPointType = 'D'
		BEGIN
			INSERT INTO #DC
			SELECT 
			     DATEADD(day, number,      @DefaultStartDate) [Date]
			   , DATEADD(day, number + 1,  @DefaultStartDate) [NextDate]
		
			FROM mASter..spt_values
			WHERE type = 'P'
			AND DATEADD(DAY,number,@DefaultStartDate) <= @DefaultEndDate
		END

		-- CheckPoints_Weekly (including start date)
		ELSE IF  @checkPointType = 'W'
		BEGIN
		    INSERT INTO #DC
			SELECT 
				DATEADD (week, number,     (DATEADD(DAY, 1-DATEPART(WEEKDAY, @DefaultStartDate), @DefaultStartDate))) [Date]
			  , DATEADD (week, number + 1, (DATEADD(DAY, 1-DATEPART(WEEKDAY, @DefaultStartDate), @DefaultStartDate))) [NextDate]
			-- INTO #DC
			FROM mASter..spt_values
			WHERE type = 'P'
			AND DATEADD(week, number, (DATEADD(DAY, 1-DATEPART(WEEKDAY,  @DefaultStartDate),  @DefaultStartDate))) <= DATEADD(DAY, 1-DATEPART(WEEKDAY, @DefaultEndDate), @DefaultEndDate)
		END
		-- CheckPoints_Monthly (including start date)
		ELSE IF @checkPointType = 'M'
		BEGIN
		  INSERT INTO #DC
		  SELECT 
			  DATEADD (month, number, DATEADD(month, DATEDIFF(month, 0, @DefaultStartDate), 0)) [Date]
			, DATEADD(month,number + 1,    DATEADD(month, DATEDIFF(month, 0, @DefaultStartDate), 0)) [NextDate]
		  -- INTO #DC
		  FROM mASter..spt_values
		  WHERE type = 'P'
		  AND DATEADD(month, number, DATEADD(month, DATEDIFF(month, 0, @DefaultStartDate), 0)) <=  DATEADD(month, DATEDIFF(month, 0, @DefaultEndDate), 0)
		END

		ELSE IF @checkPointType is null
		BEGIN
		  INSERT INTO #DC
		  SELECT 
			  @DefaultStartDate [Date]
			, DATEADD(day, 1, @DefaultEndDate)  [NextDate]

		END
	END

	-- ******************************
	-- STEP 2. Store Triage
	-- ******************************
	SELECT
	*	
	INTO #T
	FROM 
	(
		SELECT 
		       --*
			   checkpoints.date as date
			   -- ,checkpoints_sum.date as date_sum
			   ,DiscrepancyID
			   ,DiscrepancyHistoryID
			   ,discrepancy_updateDate
			   --,next_updatedate
			   ,DiscrepancyStatusID
			   ,DiscrepancyCategoryID
			   ,Assigned_UserID
			   ,prev_Assigned_UserID              -- Prev UserID used for Triage
			   ,prev_Assigned_UserID_changed      -- Prev UserID used for Triage
			   -- what does rank mean here?
		       --,RANK() OVER (PARTITION BY DiscrepancyID, checkpoints.date ORDER BY updateDate DESC) AS Rank  
		FROM
			(         
				SELECT       
			            d.* 
						--,lead(d.discrepancy_updateDate) OVER (PARTITION BY d.DiscrepancyID ORDER BY discrepancy_updateDate) AS next_updatedate
						,ISNULL(lag(d.ASsigned_UserID) OVER (PARTITION BY d.DiscrepancyID ORDER BY discrepancy_updateDate) , 0) prev_Assigned_UserID
					    ,CASE 
							WHEN ISNULL(
											lag(d.ASsigned_UserID) OVER (PARTITION BY d.DiscrepancyID ORDER BY discrepancy_updateDate) 
											, 0
										) = Assigned_UserID 
								THEN 0 
							ELSE 1 
						 END AS prev_Assigned_UserID_changed
						,ds.DiscrepancyCategoryID
						,ds.DiscrepancyStatus
				        ,u.UserID
				 FROM  
						users u   
						LEFT JOIN
						DiscrepanciesHistory d ON u.UserID = d.Assigned_UserID						
						LEFT JOIN
						DiscrepancyStatuses ds ON d.DiscrepancyStatusID = ds.DiscrepancyStatusID
		) AS raw
		RIGHT JOIN #DC AS checkpoints   
		ON 
		( 
			discrepancy_updateDate >= checkpoints.date 
			and 
			-- TimeSpan offset => daily 1 weekly 7 monthly ?
			-- discrepancy_updateDate < DATEADD(DAY, 1,checkpoints.date)
			discrepancy_updateDate < checkpoints.nextDate   --- only apply to first valid checkpoint
		)
		WHERE Assigned_UserID = @UserID
		AND prev_Assigned_UserId_changed = 1
	) AS raw2

	--select * from #T 
  --ORDER BY  Date desc

	-- ******************************
	-- STEP 3. Store Grouped Data
	-- ******************************
		SELECT
	      UserID
		   ,date
		   ,COUNT(discrepancyID) AS count_discrepancy
		   -- This part need to be dynamic
		   ,SUM(CASE WHEN DiscrepancyCategoryID = 5 THEN 1 ELSE 0 END)            AS count_discrepancy_resolved
		   ,SUM(CASE WHEN DiscrepancyCategoryID = 4 THEN 1 ELSE 0 END)            AS count_discrepancy_Complete
		   ,SUM(CASE WHEN DiscrepancyCategoryID = 3 THEN 1 ELSE 0 END)            AS count_discrepancy_Worked
		   ,SUM(CASE WHEN DiscrepancyCategoryID = 2 THEN 1 ELSE 0 END)            AS count_discrepancy_Pending
		   ,SUM(CASE WHEN DiscrepancyCategoryID = 1 THEN 1 ELSE 0 END)            AS count_discrepancy_New
	          -- ,sum(cASe when DiscrepancyCategoryID not in (3,4,5) then 1 else 0 end) AS count_discrepancy_pending*/
		 INTO #TC
		 FROM  
		 (
		 	SELECT  
		 	    d.*
		 	    ,lead(d.discrepancy_updateDate) OVER (PARTITION BY d.DiscrepancyID ORDER BY discrepancy_updateDate) AS next_updatedate
		 	    ,ds.DiscrepancyCategoryID
		 	    ,ds.DiscrepancyStatus
		 		,u.UserID
		 	FROM   
		 	 	users u   
		 	 	LEFT JOIN 
		 	 	DiscrepanciesHistory d ON u.UserID = d.ASsigned_UserID						
		 	   	LEFT JOIN
		 	    DiscrepancyStatuses ds ON d.DiscrepancyStatusID = ds.DiscrepancyStatusID
		 ) AS raw 
		 RIGHT JOIN #DC AS checkpoints 
		 ON
		 ( 
		 	discrepancy_updateDate <= checkpoints.nextDate 
		 	AND 
			-- next update pass checkpoint, meaning the latest status of discrepancy by the checkpoint
		 	(next_updatedate >  checkpoints.nextDate   OR next_updatedate IS NULL) 
		 ) 
		 where Assigned_UserID = @UserID
		 GROUP BY date ,UserID		

		--select * from #TC where userID = @userID
		---  ORDER BY  Date desc
	--print @sqlStatement
	-- ******************************
	-- STEP 4. Execute  statement
	-- ******************************

	-- OutStanding = PrevOutStanding + Inflow - Outflow - Triage
	-- Count       = PrevCount + Inflow  - Triage

	SELECT 
		* 
		,count(*) over() as ResultCount
	FROM 
	(
		SELECT 
			grouped.UserID
			, grouped.date as DateTime
			, DATEADD(day, - 1, checkpoints.nextdate) as EndDate
			, count_discrepancy  AS CountDiscrepancy
			, ISNULL(InFlow, 0) AS CountInFlow
			,(count_discrepancy_Complete -	ISNULL(lag(count_discrepancy_Complete) OVER (PARTITION BY grouped.UserID ORDER BY grouped.Date),0))
				+ (count_discrepancy_Worked -	ISNULL(lag(count_discrepancy_Worked)   OVER (PARTITION BY grouped.UserID ORDER BY grouped.Date),0))
			    + (count_discrepancy_resolved -	ISNULL(lag(count_discrepancy_resolved) OVER (PARTITION BY grouped.UserID ORDER BY grouped.Date),0)) AS CountOutFlow
			-- ,count_discrepancy_Pending -	ISNULL(lag(count_discrepancy_Pending)  OVER (PARTITION BY grouped.UserID ORDER BY grouped.Date),0)  AS Pending	
				, count_discrepancy_New + count_discrepancy_Pending AS CountOutStanding
			, ISNULL(InFlow, 0) - (count_discrepancy - ISNULL(lag(count_discrepancy) OVER (PARTITION BY grouped.UserID ORDER BY grouped.Date)  ,0)) AS CountTriage
			--, count(*) over() as ResultCount
		FROM
		(
			  SELECT
			  	Date
			  	, Assigned_UserID
			  	,COUNT(DISTINCT discrepancyID ) AS InFlow
			  FROM #T
			  WHERE Date IS NOT NULL -- AND prev_Assigned_UserId_changed = 1- -AND Assigned_UserID IN ( @UserID )
			  GROUP BY Date, Assigned_UserID 
		) AS inflow
		RIGHT JOIN #TC AS grouped 
			 ON grouped.date = inflow.date AND inflow.Assigned_UserID = grouped.UserID
		LEFT JOIN  #DC as checkpoints
			 ON grouped.date = checkpoints.date
	) as raw_bound
    WHERE DateTime <> (select min(date) from #DC)
    ORDER BY UserID, DateTime desc
    OFFSET (@pageSize * (@pageIndex)) ROWS
    FETCH NEXT @pageSize ROWS ONLY;




	--exec(@sqlStatement)


	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END

GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
-- GRANT EXECUTE ON [dbo].[spGetReportProductivityDetail] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetReportProductivityDetail] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetReportProductivityDetail] TO [webapp] 
GO
-- *****************************************************************************************************