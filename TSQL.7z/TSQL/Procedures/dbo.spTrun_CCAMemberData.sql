
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spTrun_CCAMemberData] 
PRINT @returnValue 

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spTrun_CCAMemberData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spTrun_CCAMemberData]
GO

/****** Object:  StoredProcedure [dbo].[spTrun_CCAMemberData]    Script Date: 09/07/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		
-- Create date: 09/07/2019
-- Truncates:	CCAMemberData
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spTrun_CCAMemberData]
WITH EXECUTE AS 'dbo'


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- DECLARE @CCAMemberData varchar(100) = '[dbo].[spTrun_CCAMemberData]'
	
	TRUNCATE TABLE [dbo].[CCAMemberData]

END
GO

-- No additional permissions should be needed.  spTrun should be called from within another stored procedure with appropriate permissions



-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spTrun_CCAMemberData] TO [Talend] 
GRANT EXECUTE ON [dbo].[spTrun_CCAMemberData] TO [Support] 
GO
-- *****************************************************************************************************
