
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Blocks
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMonthlySummaryRecord] 
PRINT @returnValue 


-- Validation
select count(*) from MonthlySummaryRecord
select count(*) from MonthlySummaryRecord where ccaRatecardid is null

select top 1000 * from MonthlySummaryRecord
select * from ExecutionLog order by ExecutionLogID desc

select top 1000 * from MonthlySummaryRecord
where variance is not null

select count(*) as MSRCount
from MonthlySummaryRecord

select * from monthlysummaryrecord where MasterPatientID	= 7138 and MemberMonth = '2019-04-01'

-- no duplicates	
select MasterPatientID, MemberMonth, count(*) as dupcheck
from MonthlySummaryRecord
group by MasterPatientID, MemberMonth
having count(*) > 1

select * from 7138
select * from vwCCAMemberData WHERE MMIS_ID = '100006067291'

select MemberMonth, Count(*) as CountByMemberMonth from MonthlySummaryRecord group by MemberMonth order by MemberMonth

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spProcessMonthlySummaryRecord]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spProcessMonthlySummaryRecord]
GO

/****** Object:  StoredProcedure [dbo].[spProcessMonthlySummaryRecord]    Script Date: 08/02/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/02/2019
-- Description:	Procedure processes monthly summary record, based on patient payment detail

				Unit-test: 10/07/2019
					Added join to MasterPatientManagement for MasterPatientID

				Post Unit-test: 10/09/2019
					Re-did joins to include CCA member months expected payments
					Modified payment details to include rate card, eliminating need for joins in this procedure
					This has had a performance hit, increasing the exection time significantly.  
					Have staged the expected payment data.
					May experiment with staging payment detail data to see if performance is improved there.

				Post unit-test: 10/16/2019
					Modified to represent variance as follows:
						overpayment (positive amount) State - CCA Expected (was reverse)
					Modified payment error to subtract base amount from paid amount (state)
						removed rate card "amount" from isnull consideration
					Recalculated MMIS amount and net based on true MMIS amounts, not rate card joined
						causing problems with UI expectations
					Do not process beyond lookback date
					Added Raw CCA and MMIS rate cells and regions, for more accurate evaluation from UI


-- Modified by: Yue Song
-- Modified dt: 5/11/2020
-- Description: Added a where clause act as the Safe Guard to prevent membermonth from nullable


-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 0:22 seconds
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spProcessMonthlySummaryRecord]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	DECLARE @LookbackDate varchar(50) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'LookbackDate')
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 

	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	
	-- ******************************
	-- STEP 1.  Trunate Monthly summary record for each run
	-- ******************************

	EXEC [dbo].[spTrun_MonthlySummaryRecord] 


	-- ******************************
	-- STEP 2.  process data imported and computed from MMIS state payment files
	-- ******************************

	insert into MonthlySummaryRecord (

		MasterPatientID 
		, MemberMonth 
		, MMIS_ID
		, Variance 
	
		-- Payment error SHOULD NOT be part of the variance calculation
		, PaymentError 

		-- from PatientPayDetail... what the state actually says they paid, based on file
		, BaseCapitationAmount	
		, PatientPayAmountN		
		, PatientPayAmountSCO	
		, PaidCapitationAmount	
		, Remit

		, CCARateCellID 
		, CCARegionID 
		-- values are numeric?
		, CCAPatientPay 
		, CCAPatientSpendDown 



		-- CCA's expected based on current member's rate cell and region in MP
		, CCARateCardID 
		, CCAAmount 
		, CCANetAmount 
		
		, MMISRateCellID 
		, MMISRegionID 
		, MMISPatientPay 
		, MMISPatientSpendDown 
	
		-- expected payment based on state's rate rate cell and region
		, MMISRateCardID 
		, MMISAmount 
		, MMISNetAmount 

		, rawMMISRateCell
		, rawMMISRegion	

		, rawCCARateCell
		, rawCCARegion	

	)

	select 
		mpm.MasterPatientID as MasterPatientID
		, isnull(pd.CapitationMonthYear, ep.MasterMemberMonth) as MemberMonth
		-- , pd.MemberID as MMIS_ID
		, mpm.MMIS_ID as MMIS_ID

		-- conversion for varchar > numeric errors
		, (
			-- substract 0 when no rate card amount
			-- - (pd.BaseCapitationAmount - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00)) as Variance -- altered this to reflect variance in paid, not base capitation amount
			(pd.Paid)
			- isnull(
			(ep.Amount - case when ep.PatientPay like '%[0-9].[0-9][0-9]' then cast(ep.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when ep.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(ep.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end)
			, 0.00)  
		) as Variance 
		-- , (pd.BaseCapitationAmount - pd.Amount) as PaymentError  -- Payment error SHOULD NOT be part of the variance calculation... should consider patient pay and spend down
		-- , coalesce(pd.Amount, pd.BaseCapitationAmount,0.00) - (pd.Paid + isnull(pd.PatientPay,0.00) + isnull(pd.SpendDown,0.00)) as PaymentError  -- Payment error SHOULD NOT be part of the variance calculation; altered this to reflect actual paid vs base amount
		, coalesce(pd.BaseCapitationAmount,0.00) - (pd.Paid + isnull(pd.PatientPay,0.00) + isnull(pd.SpendDown,0.00)) as PaymentError  -- Payment error SHOULD NOT be part of the variance calculation; altered this to reflect actual paid vs base amount
		/*
		-- option B: 
		, CASE WHEN pd.Amount IS NULL 
			THEN 0.00 ELSE 
			(
			isnull(
			(pd.Paid + isnull(pd.PatientPay,0.00) + isnull(pd.SpendDown,0.00)) - pd.Amount
			,0.00)
		) END as PaymentError  -- Payment error SHOULD NOT be part of the variance calculation; altered this to reflect actual paid vs base amount
		*/
		-- from PatientPayDetail... what the state actually says they paid, based on file
		-- is zero when null appropriate... needed for discrepancy processing
		, isnull(pd.BaseCapitationAmount, 0.00) as BaseCapitationAmount	
		, isnull(pd.PatientPay          , 0.00) as PatientPayAmountN		
		, isnull(pd.SpendDown           , 0.00) as PatientPayAmountSCO	
		, isnull(pd.Paid                , 0.00) as PaidCapitationAmount
		, pd.Remit	
	

		, ep.CCARateCellID as CCARateCellID 
		, ep.CCARegionID as CCARegionID 
		-- conversion for varchar > numeric errors
		, case when ep.PatientPay like '%[0-9].[0-9][0-9]' then cast(ep.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end as CCAPatientPay 
		, case when ep.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(ep.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end as CCAPatientSpendDown 


		-- CCA's expected based on current member's rate cell and region in MP
		, ep.RateCardID as CCARateCardID 
		, ep.Amount as CCAAmount 

		-- conversion for varchar > numeric errors
		, (isnull(ep.Amount,0.00) - case when ep.PatientPay like '%[0-9].[0-9][0-9]' then cast(ep.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when ep.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(ep.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end) as CCANetAmount 
		
		, pd.CCARateCellID as MMISRateCellID 
		, pd.CCARegionID as MMISRegionID 
		, pd.PatientPay as MMISPatientPay 
		, pd.SpendDown as MMISPatientSpendDown 
	
		-- expected payment based on state's rate rate cell and region
		, pd.RateCardID as MMISRateCardID 
		, pd.BaseCapitationAmount as MMISAmount 
		, (isnull(pd.BaseCapitationAmount ,0.00) - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00))  as MMISNetAmount 

		-- these values are not supposed to be used anyway
		-- , pd.Amount as MMISAmount 
		-- , (isnull(pd.Amount,0.00) - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00))  as MMISNetAmount 

		, isnull(mmisRC.CCARateCell,pd.RateCell) as rawMMISRateCell
		, isnull(mmisReg.CCARegion,pd.MCRegion) as rawMMISRegion

		, case when ep.Product = 'SCO' then left(ep.RatingCategory, 3) else ep.RatingCategory end	as rawCCARateCell
		, ep.Region			as rawCCARegion


	-- select mpm.*, md.MemberMonth -- select count(*)
	from MasterPatientManagement as mpm
	-- get member months for all members
	inner join (
		-- pre-build this list for performance: total rows: 716299
		select mpm.MasterPatientID, pd.CapitationMonthYear as MemberMonth 
		from MasterPatientManagement as mpm
		inner join PaymentDetail as pd on pd.MemberID = mpm.MMIS_ID -- 683164
		-- where pd.rnCurrentPaidAmount = 1 -- staging takes care of this
		union 
		select mpm.MasterPatientID, ep.MasterMemberMonth as MemberMonth 
		from MasterPatientManagement as mpm
		inner join ExpectedPayments as ep on ep.MMIS_ID = mpm.MMIS_ID -- 618614
		union 
		select mpm.MasterPatientID, ep.MasterMemberMonth as MemberMonth 
		from MasterPatientManagement as mpm
		inner join ExpectedPayments as ep on ep.CCAID = mpm.CCAID -- 195... but expected payment is not missing MMIS_ID on any
	) md on md.MasterPatientID = mpm.MasterPatientID
	full outer join ExpectedPayments as ep 
		on (
			ep.MMIS_ID = mpm.MMIS_ID
			-- May need this in the future, but causes huge performance issue and is not needed for any matches right now
			-- or (ep.MMIS_ID is null
			-- 	and ep.CCAID = mpm.CCAID 
			-- )
		)
		and ep.MasterMemberMonth = md.MemberMonth 
	full outer join PaymentDetail as pd -- do we get the rate card here and call it a day?
		on pd.MemberID = mpm.MMIS_ID 
		and pd.CapitationMonthYear = md.MemberMonth 
		-- and pd.rnCurrentPaidAmount = 1 -- staging takes care of this
	-- select * from vwRateCellMap 
	-- select * from vwRegionMap
	left join vwRateCellMap as mmisRC on mmisRC.MMISRateCell = pd.RateCell
	left join vwRegionMap as mmisReg on mmisReg.MMISRegion = pd.MCRegion


	where md.MemberMonth >= @LookbackDate 
	and (pd.CapitationMonthYear is not null or ep.MasterMemberMonth is not null)                    -- temp solution to exclude nullable membermonth
/*
-- can we eliminate all of this with the changes to the views:	
	left join MMISMemberData as memMMIS on memMMIS.MMIS_ID    = mpm.MMIS_ID
	left join vwRateCellMap	 as rcMap   on rcMap.MMISRateCell = pd.RateCell and rcMap.ActiveFlag = 1
	left join vwRegionMap    as regMap  on regMap.MMISRegion  = pd.MCRegion and regMap.ActiveFlag = 1
	-- note overlaps in test rate card data
	left join vwRateCard     as ratMMIS	
		on  ratMMIS.CCARateCellID = rcMap.CCARateCellID
		and ratMMIS.CCARegionID = regMap.CCARegionID
		and pd.CapitationMonthYear between ratMMIS.StartDate and ratMMIS.EndDate
		and ratMMIS.ActiveFlag = 1
	
	-- fix this join?
	left join vwCCAMemberData as memCCA ON memCCA.MMIS_ID = memMMIS.MMIS_ID
		and pd.CapitationMonthYear between memCCA.RatingCategoryStartDate and memCCA.RatingCategoryEndDate
		and pd.CapitationMonthYear between memCCA.RegionStartDate AND memCCA.RegionEndDate
		and memCCA.ActiveFlag = 1
	left join vwRateCard     as ratCCA on ratCCA.RateCardID = memCCA.RateCardID
*/	
	
	-- where pd.rnCurrentPaidAmount = 1
	
		-- include range mapping


	-- select * from vwRateCellMap	 
	-- select * from vwRegionMap    
	-- select * from vwRateCard
	-- select * from vwCCAMemberData 


	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************

	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()

		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart

		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spProcessMonthlySummaryRecord] TO [Talend] 
GRANT EXECUTE ON [dbo].[spProcessMonthlySummaryRecord] TO [Support] 
GO
-- *****************************************************************************************************