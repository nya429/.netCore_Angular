
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMasterPatientManagement_MMIS] 
PRINT @returnValue 


select insertDate, count(*) as countByInserDate 
from MasterPatientManagement
group by insertDate
order by insertDate

select updateDate, count(*) as countByUpdateDate 
from MasterPatientManagement
group by updateDate
order by updateDate

select * from MasterPatientManagement
where insertDate > '2019-10-05'

select top 10 * from MasterPatientManagement

update mpm
	set SourceSystem = 'CCA'
-- select *
from MasterPatientManagement as mpm
where MasterPatientID	= 10 -- 100000034387


select * from ExecutionLog order by ExecutionLogID desc

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spProcessMasterPatientManagement_MMIS]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spProcessMasterPatientManagement_MMIS]
GO

/****** Object:  StoredProcedure [dbo].[spProcessMasterPatientManagement_MMIS]    Script Date: 10/05/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 10/05/2019
-- Description:	Procedure for processing and managing master patient IDs
				Initial processes will gather data from respective source systems.
				This process will bring these elements together in the hierarchy of source of truth prioritization

				Source system hierarchy 
					MMIS 8200
					MP Member

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spProcessMasterPatientManagement_MMIS]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Process from MMIS data, insert new
	-- ******************************

	insert into MasterPatientManagement (
 		  MMIS_ID 
		, SourceSystem
 		, MemberFirstName 
 		, MemberMiddleName
 		, MemberLastName 
 		, Suffix 
		
		, ActiveFlag 
		, insertDate 
		, updateDate 
	)
	select 
 		  mmis.MMIS_ID 
		, 'MMIS' as SourceSystem
 		, mmis.MemberFirstName 
 		, mmis.MemberMiddleName
 		, mmis.MemberLastName 
 		, mmis.Suffix 
		
		, 1 as ActiveFlag
		, @spStart as insertDate
		, @spStart as updateDate
	from MMISMemberData as mmis
	WHERE not exists (
		select MMIS_ID
		FROM MasterPatientManagement as mpm
		WHERE mpm.MMIS_ID = mmis.MMIS_ID 
	)
	

	-- ******************************
	-- STEP 2. Process from MMIS data, update existing (if necessary) Update names of existing members to latest entry
	-- ******************************

	update mpm
 		set 
			SourceSystem = 'MMIS'
			, MemberFirstName   = mmis.MemberFirstName       
 			, MemberMiddleName	= mmis.MemberMiddleName	
 			, MemberLastName 	= mmis.MemberLastName 	
 			, Suffix 			= mmis.Suffix        
			, updateDate        = @spStart 
		from MasterPatientManagement as mpm
		inner join MMISMemberData as mmis on mmis.MMIS_ID = mpm.MMIS_ID
		-- do not update if the same
		WHERE mpm.SourceSystem <> 'MMIS'
			or not (
					mpm.MemberFirstName  = mmis.MemberFirstName    
 				and mpm.MemberMiddleName = mmis.MemberMiddleName   
 				and mpm.MemberLastName   = mmis.MemberLastName   
 				and mpm.Suffix 		     = mmis.Suffix        
			)







	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spProcessMasterPatientManagement_MMIS] TO [Talend] 
GRANT EXECUTE ON [dbo].[spProcessMasterPatientManagement_MMIS] TO [Support] 
GO
-- *****************************************************************************************************