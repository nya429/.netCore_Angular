
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spUpdateFilterMembers] 
PRINT @returnValue 



declare @SendMemberIDs as dbo.BulkID
insert into @SendMemberIDs (
	updateID
)
	select distinct top 10 ml.masterPatientID 
	from discrepancies as d 
	inner join memberlist as ml on d.MasterPatientID = ml.MasterPatientID
	order by ml.masterPatientID



-- Full Example Test
DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spUpdateFilterMembers] 
	  @eventUserID = 2

	, @Name = 'mar co' -- NULL -- should we be filtering on something so broad and error prone
	, @CCAID = NULL
	, @MMIS_ID = NULL
	, @includeZeroDiscrepancy = 0 -- 0: NO; 1: YES

	-- , @MemberIDs = @SendMemberIDs

	, @DiscrepancyStatusId = 6
	, @Assigned_UserID = 6
	, @DueDate = '2019-12-12'

	, @DiscrepancyComment = 'member filter, super bulk update, watch out!'

	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @RetCd

-- validate results
select * from discrepancies           where masterpatientID in (	27	, 89	, 125	, 144	, 205	, 219	, 383	, 502	, 525	, 570)
select * from discrepanciescomments where discrepancyid in (select discrepancyID from discrepancies where masterpatientID in (	27	, 89	, 125	, 144	, 205	, 219	, 383	, 502	, 525	, 570))

select * from discrepancies           where updatedate >= '2019-09-23'  
select * from discrepanciescomments where updatedate >= '2019-09-23'


-- source data
select * from discrepancystatuses
exec spGetusers
select * from executionlog order by executionlogid desc



-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spUpdateFilterMembers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spUpdateFilterMembers]
GO

/****** Object:  StoredProcedure [dbo].[spUpdateFilterMembers]    Script Date: 09/22/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/22/2019
-- Description:	API
				Used to update discrepancy status via a member filter

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spUpdateFilterMembers]
	-- Add the parameters for the stored procedure here
	@eventUserID int 
	, @Name varchar(51) = NULL -- should we be filtering on something so broad and error prone
	, @CCAID bigint = NULL
	, @MMIS_ID char(12) = NULL
	, @includeZeroDiscrepancy int = 0 -- 0: NO; 1: YES
	
	-- if full list sent, shouldn't we use other bulk member procedure
	, @MemberIDs dbo.BulkID readonly -- , @MasterPatientID int = NULL

	, @DiscrepancyStatusId int = NULL 
	, @Assigned_UserID int = NULL
	, @DueDate date = NULL
	, @DiscrepancyComment varchar(2000) = NULL

	, @ReturnCode int output


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	DECLARE @RetCd int
	DECLARE @SendDiscrepancyIDs as dbo.BulkID

	DECLARE @MemberFirstName varchar(20)
	DECLARE @MemberLastName varchar(30) 
	DECLARE @BothNamesSent bit = 0 
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)


	-- CHECK A NAME WAS SENT AT ALL
	IF ISNULL(@Name, '') <> ''
		-- If only one name sent, set as first name
		IF CHARINDEX(' ',@Name,1) = 0
			begin
				set @BothNamesSent = 0 -- already default to this, but assign here for distinction and readibility
				set @MemberFirstName = @Name
				set @MemberLastName = @Name
				
			end
		ELSE
		-- If a space is included, split into first and last on the space, assuming search order is {[FirstName][ ][LastName]}
			BEGIN 
				set @BothNamesSent = 1 -- already default to this, but assign here for distinction and readibility
				set @MemberFirstName = SUBSTRING(@Name, 1, (CHARINDEX(' ',@Name,1) - 1)) 
				set @MemberLastName  = SUBSTRING(@Name, (CHARINDEX(' ',@Name,1) + 1), (len(@Name) - (CHARINDEX(' ',@Name,1)) ) ) 
			END


	-- ******************************
	-- STEP 1. Get discrepancy IDs based on filter(s) provided.
	-- ******************************
	if exists(select UpdateID from @MemberIDs)
		begin
			insert into @SendDiscrepancyIDs (
				updateID
			)
			select d.DiscrepancyID
			from discrepancies as d 
			-- inner join memberlist as ml on d.MasterPatientID = ml.MasterPatientID
			inner join @MemberIDs as i on i.UpdateID = d.MasterPatientID

			-- print 'found exact'
		end
	else
		begin
			-- print 'using filter'
			
			insert into @SendDiscrepancyIDs (
				updateID
			)

			select d.DiscrepancyID
			from discrepancies as d 
			inner join MemberList as ml on ml.MasterPatientID = d.MasterPatientID
			INNER JOIN vwMemberMap as m on m.MasterPatientID = d.MasterPatientID
			where 
				(
					@CCAID is null
					OR ml.CCAID  = @CCAID 
				)
				AND (
					isnull(@MMIS_ID,'') = ''
					OR ml.MMIS_MMIS_ID = @MMIS_ID 
				)
				AND (
					@includeZeroDiscrepancy = 1 
					OR ISNULL(ml.TotalDiscrepancies, 0) <> 0  
				)
				AND (
					-- check separate first and last names
					(
						@BothNamesSent = 1
						and (
								m.CCA_MemberFirstName LIKE @MemberFirstName + '%'
							OR m.MMIS_MemberFirstName LIKE @MemberFirstName + '%'
						)
						and (
								m.CCA_MemberLastName  LIKE @MemberLastName + '%'
							OR m.MMIS_MemberLastName  LIKE @MemberLastName + '%'
						)
					)
					-- only one name sent, check both first and last name for the entry
					OR  (
						@BothNamesSent = 0
						and (
							isnull(@MemberFirstName,'') = '' 
							or (
									m.CCA_MemberFirstName LIKE @MemberFirstName + '%'
								OR m.MMIS_MemberFirstName LIKE @MemberFirstName + '%'
							)
				
							or (
								isnull(@MemberLastName,'') = '' 
								or (
										m.CCA_MemberLastName  LIKE @MemberLastName + '%'
									OR m.MMIS_MemberLastName  LIKE @MemberLastName + '%'
								)
							)
						)
					)
				)	
		end

	-- SELECT * FROM @SendDiscrepancyIDs

	-- ******************************
	-- STEP 2. Get discrepancy IDs for member list provided.
	-- ******************************
	

	-- Re-use bulk disrepancy stored procedure
	-- DECLARE @returnValue as INT, @NewID int, @RetCd int
	-- EXEC @returnValue = [dbo].[spUpdateBulkDiscrepancies] 

	EXEC [dbo].[spUpdateBulkDiscrepancies] 
			@eventUserID = @eventUserID
		, @DiscrepancyIDs = @SendDiscrepancyIDs

		, @DiscrepancyStatusId = @DiscrepancyStatusId
		, @Assigned_UserID = @Assigned_UserID
		, @DueDate = @DueDate

		, @DiscrepancyComment = @DiscrepancyComment

		, @ReturnCode = @RetCd  output
	
	-- Confirm proper results returned
	-- PRINT @returnValue
	-- PRINT @RetCd

	
	SET @ReturnCode = @RetCd


	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spUpdateFilterMembers] TO [Talend] 
GRANT EXECUTE ON [dbo].[spUpdateFilterMembers] TO [Support] 
GRANT EXECUTE ON [dbo].[spUpdateFilterMembers] TO [webapp] 
GO
-- *****************************************************************************************************