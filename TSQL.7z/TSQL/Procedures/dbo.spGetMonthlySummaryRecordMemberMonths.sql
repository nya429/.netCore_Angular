
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMonthlySummaryRecordMemberMonths] 
PRINT @returnValue 

EXEC [dbo].[spGetMonthlySummaryRecordMemberMonths] 
	  @eventUserID = 2
	  , @MasterPatientID = 1 
	  , @Year = '2019'


EXEC [dbo].[spGetMonthlySummaryRecordMemberMonths] 
	  @eventUserID = 2
	  , @MasterPatientID = 2 -- complete set of months
	  , @Year = '2019'

EXEC [dbo].[spGetMonthlySummaryRecordMemberMonths] 
	  @eventUserID = 2
	  , @MasterPatientID = 4 -- gaps in months (check with Yue... does this need to be years?)
	  , @Year = '2019'

EXEC [dbo].[spGetMonthlySummaryRecordMemberMonths] 
	  @eventUserID = 2
	  , @MasterPatientID = 6189 
	  , @Year = '2019'

EXEC [dbo].[spGetMonthlySummaryRecordMemberMonths] 
	  @eventUserID = 2
	  , @MasterPatientID = 7747 
	  , @Year = '2019'

select cast('2019' as date)
-- select eomonth(dateadd(m,11,cast('2019' as date))) -- don't want, because member months are always listed with the 1st of month
select dateadd(m,11,cast('2019' as date))


-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetMonthlySummaryRecordMemberMonths]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetMonthlySummaryRecordMemberMonths]
GO

/****** Object:  StoredProcedure [dbo].[spGetMonthlySummaryRecordMemberMonths]    Script Date: 09/05/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/05/2019
-- Description:	API
				Procedure for getting member months by year

				Unit-test: 09/19/2019
					Cleaned up the results from this stored procedure
					Ultimately will have to change processing
					Outstanding:
						RateCellID -> RateCell (value)
						RegionID -> Region (value)
						No NULLs
						Use 99 for missing rate cells
						Elminate duplicates
						Ignore MMIS rate card amounts...
						Add actual values from monthly summary record

					Fixed year filter issue

				Unit-test: 10/07/2019
					Added join to MasterPatientManagement for MasterPatientID

				Post unit-test 10/09/2019
					Corrected for showing proper rate cell and region

				Post QA - 10/16/2019
					Need to show raw MMIS rate cell and region when missing from rate card (find unmapped example)

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetMonthlySummaryRecordMemberMonths]
	-- Add the parameters for the stored procedure here
	  @eventUserID int = NULL
	  , @MasterPatientID int -- Must be passed 
	  , @Year char(4) -- Must be passed

	/*

	-- need whole set, probably don't need pagination (Yue confirmed)
	-- maybe move hardcoding into stored procedure, then can check for isnull values
	, @pageIndex int		  = 0
	, @pageSize int			  = NULL -- 12 months per year, 
	, @sortBy varchar(50)	  = 'MemberMonth' 
	, @orderBy int            = 1 -- 0: ASC; 1: DESC
	*/


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Get MonthlySummaryRecord 
	-- ******************************

	select  
		MonthlySummaryRecordID, MasterPatientID, MMIS_ID, MemberMonth, Variance, PaymentError, BaseCapitationAmount, PatientPayAmountN, PatientPayAmountSCO, PaidCapitationAmount, CCARateCellID, CCARegionID, CCARateCell, CCARegion, CCAPatientPay, CCAPatientSpendDown, CCARateCardID, CCAAmount, CCANetAmount, MMISRateCellID, MMISRegionID, MMISRateCell, MMISRegion, MMISPatientPay, MMISPatientSpendDown, MMISRateCardID, MMISAmount, MMISNetAmount, rnMSR

	from (
		-- get all member months pertaining to specific member
		select
			 msr.MonthlySummaryRecordID
			,msr.MasterPatientID
			,mmismem.MMIS_ID -- msr.MMIS_ID
			,msr.MemberMonth
			,isNull(msr.Variance             , 0.00) as Variance
			,isnull(msr.PaymentError		 , 0.00) as PaymentError
			,isnull(msr.BaseCapitationAmount , 0.00) as BaseCapitationAmount  
			,isnull(msr.PatientPayAmountN	 , 0.00) as PatientPayAmountN
			,isnull(msr.PatientPayAmountSCO	 , 0.00) as PatientPayAmountSCO
			,isnull(msr.PaidCapitationAmount , 0.00) as PaidCapitationAmount
			,isnull(msr.CCARateCellID		 , cast(0 as int)) as CCARateCellID
			,isnull(msr.CCARegionID		     , cast(0 as int)) as CCARegionID
			,coalesce(ccarc.CCARateCell, msr.rawCCARateCell , '99') as CCARateCell        
			,coalesce(ccareg.CCARegion, msr.rawCCARegion , 'NA') as CCARegion         
			,isnull(msr.CCAPatientPay		 , 0.00) as CCAPatientPay
			,isnull(msr.CCAPatientSpendDown	 , 0.00) as CCAPatientSpendDown
			,isnull(msr.CCARateCardID		 , cast(0 as int)) as CCARateCardID
			,isnull(msr.CCAAmount			 , 0.00) as CCAAmount
			,isnull(msr.CCANetAmount		 , 0.00) as CCANetAmount
			,isnull(msr.MMISRateCellID		 , cast(0 as int)) as MMISRateCellID
			,isnull(msr.MMISRegionID         , cast(0 as int)) as MMISRegionID
			,coalesce(mmisrc.CCARateCell, msr.rawMMISRateCell, '99') as MMISRateCell
			,coalesce(mmisreg.CCARegion , msr.rawMMISRegion, 'NA') as MMISRegion
			-- ignore from here down... this is the state file matched back to the RevRec rate card
			,isnull(msr.MMISPatientPay		 , 0.00) as MMISPatientPay		 
			,isnull(msr.MMISPatientSpendDown , 0.00) as MMISPatientSpendDown 
			,isnull(msr.MMISRateCardID		 , cast(0 as int)) as MMISRateCardID		 
			,isnull(msr.MMISAmount			 , 0.00) as MMISAmount			 
			,isnull(msr.MMISNetAmount        , 0.00) as MMISNetAmount        
			,ROW_NUMBER() over(partition by msr.MasterPatientID, msr.MemberMonth order by MonthlySummaryRecordID desc) as rnMSR
		from MonthlySummaryRecord as msr
		left join CCARateCells	 AS mmisrc  on mmisrc.CCARateCellID = msr.MMISRateCellID -- even though says mmis, relates to rate card IDs which are CCA
		left join CCARegions	 AS mmisreg on mmisreg.CCARegionID = msr.MMISRegionID	 -- even though says mmis, relates to rate card IDs which are CCA
		left join CCARateCells	 AS ccarc   on ccarc.CCARateCellID = msr.CCARateCellID
		left join CCARegions     AS ccareg  on ccareg.CCARegionID = msr.CCARegionID 
		left join MasterPatientManagement as mpm on mpm.MasterPatientID = msr.MasterPatientID
		left join MMISMemberData as mmismem on mmismem.MMIS_ID = msr.MMIS_ID -- this join may become unnecessary
		where msr.MasterPatientID = @MasterPatientID
		and year(msr.MemberMonth) = cast(@Year as int)
	) as m
	where rnMSR = 1
	order by MemberMonth desc -- set order



-- 	) as msrMem on msrMem.MemberMonth = msr.MemberMonth
		
/*
	ORDER BY 1 -- @sortBy -- need to consider this can be a column numeric representation, but would require dynamic SQL to incorporate the column name
	
	-- apply page retrieval 
	OFFSET (@pageSize * (@pageIndex)) ROWS
	FETCH NEXT @pageSize ROWS ONLY;
*/




	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spGetMonthlySummaryRecordMemberMonths] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetMonthlySummaryRecordMemberMonths] TO [Support]
GRANT EXECUTE ON [dbo].[spGetMonthlySummaryRecordMemberMonths] TO [Webapp] 
GO
-- *****************************************************************************************************