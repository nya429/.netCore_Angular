
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spUpdateBulkDiscrepancies] 
PRINT @returnValue 


declare @SendDiscrepancyIDs as dbo.BulkID
insert into @SendDiscrepancyIDs (
	updateID
)
values 
  (1)
, (2)
, (3)
, (4)


-- Full Example Test
DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spUpdateBulkDiscrepancies] 
	  @eventUserID = 2
	, @DiscrepancyIDs = @SendDiscrepancyIDs

	, @DiscrepancyStatusId = 17
	, @Assigned_UserID = 3
	, @DueDate = '2019-09-23'

	, @DiscrepancyComment = 'BIG test here... both discrepancies and comments'

	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @RetCd

-- validate results
select * from discrepancies
select * from discrepanciescomments
select * from discrepancystatuses

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spUpdateBulkDiscrepancies]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spUpdateBulkDiscrepancies]
GO

/****** Object:  StoredProcedure [dbo].[spUpdateBulkDiscrepancies]    Script Date: 09/12/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/12/2019
-- Description:	API
				Bulk update procedure designed to handle multiple statuses as once

				Post Unit test - 09/25/2019
					@eventUserID passed to bulk comments was hardcoded to 2.
					corrected to pass value sent through parameters/API
					

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spUpdateBulkDiscrepancies]
	-- Add the parameters for the stored procedure here
	  @eventUserID int -- user id of person sending command via front end
	, @DiscrepancyIDs dbo.BulkID readonly
	, @DiscrepancyStatusId int = NULL 
	, @Assigned_UserID int = NULL
	, @DueDate date = NULL
	, @DiscrepancyComment varchar(2000) = NULL

	, @ReturnCode int output

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)


	-- ******************************
	-- STEP 1. Clear any empty strings passed as NULL
	-- ******************************


	if isnull(@DiscrepancyStatusId  , '') = '' set @DiscrepancyStatusId  = NULL
	if isnull(@Assigned_UserID      , '') = '' set @Assigned_UserID      = NULL
	if isnull(@DueDate              , '') = '' set @DueDate              = NULL
	if isnull(@DiscrepancyComment   , '') = '' set @DiscrepancyComment   = NULL



	-- ******************************
	-- STEP 2. Check if anything was passed.  At least one column has to be entered
	-- ******************************

	IF (
		isnull(@DiscrepancyStatusId  , '') = ''
		and isnull(@Assigned_UserID      , '') = ''
		and isnull(@DueDate              , '') = ''
		and isnull(@DiscrepancyComment   , '') = ''

			-- and ActiveFlag = @ActiveFlag
	)
		set @ReturnCode = 1

	-- ******************************
	-- STEP 3. update if changes
	-- ******************************
	
	ELSE
		BEGIN
			Update d 
			set
				  Action_UserID          = @eventUserID            
				, Assigned_UserID        = isnull(@Assigned_UserID		, Assigned_UserID    )
				, DiscrepancyStatusID    = isnull(@DiscrepancyStatusID 	, DiscrepancyStatusID)
				, DueDate                = isnull(@DueDate 				, DueDate            )
				, updateDate        	 = @spStart -- updateDate   
			FROM Discrepancies AS d
			INNER JOIN @DiscrepancyIDs as i on i.UpdateID = d.DiscrepancyID

	
			set @ReturnCode = 2

	-- ******************************
	-- STEP 4. Log history, too
	-- ******************************

			INSERT INTO DiscrepanciesHistory(
				DiscrepancyID
				,MonthlySummaryRecordID
				,MasterPatientID
				,MemberMonth
				,Variance
				,PaymentError
				,BaseCapitationAmount
				,PatientPayAmountN
				,PatientPayAmountSCO
				,PaidCapitationAmount
				,CCARateCellID
				,CCARegionID
				,CCAPatientPay
				,CCAPatientSpendDown
				,CCARateCardID
				,CCAAmount
				,CCANetAmount
				,MMISRateCellID
				,MMISRegionID
				,MMISPatientPay
				,MMISPatientSpendDown
				,MMISRateCardID
				,MMISAmount
				,MMISNetAmount
				,TypeRateCell
				,TypeRegion
				,TypePatientPay
				,TypePatientSpendDown
				,TypePaymentError
				,Assigned_UserID
				,Action_UserID
				,DiscrepancyStatusID
				,DueDate
				,DiscoverDate
				,ResolvedDate
				,Balanced
				,Discrepancy_ActiveFlag
				,Discrepancy_insertDate
				,Discrepancy_updateDate
				,ActiveFlag  
				,insertDate  
				,updateDate  
			) 
			select 
				d.DiscrepancyID
				,d.MonthlySummaryRecordID
				,d.MasterPatientID
				,d.MemberMonth
				,d.Variance
				,d.PaymentError
				,d.BaseCapitationAmount
				,d.PatientPayAmountN
				,d.PatientPayAmountSCO
				,d.PaidCapitationAmount
				,d.CCARateCellID
				,d.CCARegionID
				,d.CCAPatientPay
				,d.CCAPatientSpendDown
				,d.CCARateCardID
				,d.CCAAmount
				,d.CCANetAmount
				,d.MMISRateCellID
				,d.MMISRegionID
				,d.MMISPatientPay
				,d.MMISPatientSpendDown
				,d.MMISRateCardID
				,d.MMISAmount
				,d.MMISNetAmount
				,d.TypeRateCell
				,d.TypeRegion
				,d.TypePatientPay
				,d.TypePatientSpendDown
				,d.TypePaymentError
				,d.Assigned_UserID
				,d.Action_UserID
				,d.DiscrepancyStatusID
				,d.DueDate
				,d.DiscoverDate
				,d.ResolvedDate
				,d.Balanced
				,d.ActiveFlag AS Discrepancy_ActiveFlag
				,d.insertDate AS Discrepancy_insertDate
				,d.updateDate AS Discrepancy_updateDate
				,1 as ActiveFlag
				,@spStart as insertDate
				,@spStart as updateDate
			from Discrepancies as d
			INNER JOIN @DiscrepancyIDs as i on i.UpdateID = d.DiscrepancyID
	

	END 



	-- ******************************
	-- STEP 5. Insert Comments
	-- ******************************

	-- DECLARE @returnValue as INT, @NewID int, 
	DECLARE @RetCd int
	EXEC [dbo].[spCreateBulkDiscrepancyComments] 
	  @eventUserID = @eventUserID
	, @DiscrepancyIDs = @DiscrepancyIDs
	, @DiscrepancyComment = @DiscrepancyComment -- same name...
	-- , @ActiveFlag = 1 

	, @ReturnCode = @RetCd  output




	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spUpdateBulkDiscrepancies] TO [Talend] 
GRANT EXECUTE ON [dbo].[spUpdateBulkDiscrepancies] TO [Support] 
GRANT EXECUTE ON [dbo].[spUpdateBulkDiscrepancies] TO [webapp] 
GO
-- *****************************************************************************************************