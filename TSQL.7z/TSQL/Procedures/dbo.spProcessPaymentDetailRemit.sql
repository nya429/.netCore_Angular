
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessPaymentDetailRemit] 
PRINT @returnValue 


select * from PaymentDetailRemit

-- validation of remit amounts (compared to financial figures from Nick Frenette)
select 
		  f.MMISFileProcessID	 
		, f.Product
		, f.ReportType
		, f.ReportMonth
		, r.CapitationMonthYear
		, sum(r.Remit) as sumRemit

from PaymentDetailRemit as r
inner join MMISFileProcessing as f on f.MMISFileProcessID = r.MMISFileProcessID
group by
		  f.MMISFileProcessID	 
		, f.Product
		, f.ReportType
		, f.ReportMonth
		, r.CapitationMonthYear
order by 
		  Product
		-- , ReportType
		, CapitationMonthYear
		, ReportMonth


-- **************************
-- Validation 
select * from MMISFileProcessing where ProcessIndicator = 'Y' -- will not consider whether or not flagged for processing... truncates whole table anyway
select * from ExecutionLog order by ExecutionLogID desc

-- *****************************************************************************************************
*/



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spProcessPaymentDetailRemit]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spProcessPaymentDetailRemit]
GO

/****** Object:  StoredProcedure [dbo].[spProcessPaymentDetailRemit]    Script Date: 09/23/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/23/2019
-- Description:	Process for calculating the remit amount per member per month using the processed paid amounts.
				Method: use a member month (CapitationMonthYear) as the "root"
				Consider the report month as the trigger, produce the remit using a lag to previous report month for same member month.
				Take the difference of the paid amounts between these two report months, this is the adjusted remit amount for the member for that month.

				Ongoing research: 
					does this need to be done in full each month, due to the SQL windowing requirement?
				

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	Process time for 2018 - Sep 2019:  0:26 seconds
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spProcessPaymentDetailRemit]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Clear table.  At this time, no incremental update/insert option
	-- ******************************

	EXEC dbo.spTrun_PaymentDetailRemit

	-- ******************************
	-- STEP 2. Get details from paid table for calculating remit 
	-- ******************************
	
	if object_id('tempdb..#calcNetRemit') is not null
		drop table #calcNetRemit
	
	select 

		   f.MMISFileProcessID	
		-- , f.ReportName	
		, f.Product	
		, f.ReportType	
		, f.ReportMonth	
		-- , f.PaymentPeriodStart	
		-- , f.PaymentPeriodEnd	
		-- , f.ReportRowCount	
		-- , f.ProcessIndicator	
		-- , f.IdentifiedDate	
		-- , f.ProcessedDate

		, r.MemberID
		, EffectiveDate -- not part of original computation
		, EndDate 		-- not part of original computation
		, r.CapitationMonthYear
		, r.RateCell
		, r.MCRegion
		, r.BaseCapitationAmount
		, r.Paid

		-- , r.CountPayCode - r.CountRetractionCode as PaymentIndicator -- 1: Payment Code prevailed; 2: Retraction Code prevailed

		, r.CountPayCode 
		, r.CountRetractionCode 
		, r.PaymentIndicator -- 1: Payment Code prevailed; 2: Retraction Code prevailed

		, lag(r.Paid)            over(partition by product, MemberID, CapitationMonthYear, RateCell, MCRegion order by reportMonth) as lag_Paid
		, lag(r.PaymentIndicator) over(partition by product, MemberID, CapitationMonthYear, RateCell, MCRegion order by reportMonth) as lag_PaymentIndicator
		-- debug
		-- , r.CountPayCode 
		-- , r.CountRetractionCode 
		-- , row_number() over(partition by product, MemberID, CapitationMonthYear order by reportMonth desc, remit desc) as rn_LatestMemberMonthProcessed
		-- , dense_rank() over(partition by product, MemberID, CapitationMonthYear order by reportMonth desc, remit desc) as drk_LatestMemberMonthProcessed
		, row_number() over(partition by product, MemberID, CapitationMonthYear order by reportMonth desc) as rn_LatestMemberMonthProcessed
		, dense_rank() over(partition by product, MemberID, CapitationMonthYear order by reportMonth desc) as drk_LatestMemberMonthProcessed

		INTO #calcNetRemit

	from PaymentDetailPaid as r
	inner join MMISFileProcessing as f on f.MMISFileProcessID = r.MMISFileProcessID
	-- where r.Remit = 0.00 and (r.CountPayCode - r.CountRetractionCode <> 0) -- confirms retractions all results in 0 payment
	-- where r.CapitationMonthYear = '2018-04-01'
	-- order by product, MemberID, CapitationMonthYear , reportMonth desc	

	-- select * from #calcNetRemit


	-- ******************************
	-- STEP 3. Insert results into PaymentDetailRemit 
	-- ******************************


	insert into PaymentDetailRemit (
		 MMISFileProcessID 
		, MemberID 
		, EffectiveDate 
		, EndDate 
		, CapitationMonthYear 
		, RateCell 
		, MCRegion 
		, BaseCapitationAmount 
		, Remit 
	
		-- used for determining payment vs adjustment
		, CountPayCode		  
		, CountRetractionCode 
		, PaymentIndicator    

		-- windowed columns for referenced and troubleshooting
		, lag_Paid                         
		, lag_PaymentIndicator			   
		, rn_LatestMemberMonthProcessed	   
		, drk_LatestMemberMonthProcessed   

		-- , ActiveFlag bit NULL
		, insertDate 
		, updateDate 

	)

	-- calculate net remit for cap month by report month
	select
		MMISFileProcessID	 
		-- THESE CAN BE PULLED FROM MMISFileProcessing
		-- , Product
		-- , ReportType
		-- , ReportMonth
		-- NEEDED FOR TABLE 
		, MemberID
		, EffectiveDate 
		, EndDate 
		, CapitationMonthYear
		, RateCell
		, MCRegion
		, BaseCapitationAmount
		, case when ReportType = 'M' then paid when ReportType = 'Q' and lag_Paid is null then paid else paid - isnull(lag_Paid, paid) end as Remit -- just 0 out if no difference from last month for quarterly.  Show payment for monthly

		, CountPayCode		  
		, CountRetractionCode 
		, PaymentIndicator    

		, lag_Paid
		, lag_PaymentIndicator
		, rn_LatestMemberMonthProcessed
		, drk_LatestMemberMonthProcessed

		, @spStart as insertDate
		, @spStart as updateDate

	from #calcNetRemit
	
	
	-- where CapitationMonthYear = '2018-04-01'
	-- -- where memberID = '100007777525'
	-- AND MemberID = '100007782591'
	-- order by product, MemberID, CapitationMonthYear , reportMonth 



	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spProcessPaymentDetailRemit] TO [Talend] 
GRANT EXECUTE ON [dbo].[spProcessPaymentDetailRemit] TO [Support] 
GO
-- *****************************************************************************************************