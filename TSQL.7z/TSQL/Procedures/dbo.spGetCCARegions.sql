
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetCCARegions] 
PRINT @returnValue 

EXEC [dbo].[spGetCCARegions] 2, 'ap'   , NULL
EXEC [dbo].[spGetCCARegions] 2, 'West' , NULL
EXEC [dbo].[spGetCCARegions] 2, 'st'	, NULL

EXEC [dbo].[spGetCCARegions] 2, 'ap'   , 'ICO'
EXEC [dbo].[spGetCCARegions] 2, 'West' , 'ICO'
EXEC [dbo].[spGetCCARegions] 2, 'st'	, 'ICO'

EXEC [dbo].[spGetCCARegions] 2, 'ap'   , 'SCO'
EXEC [dbo].[spGetCCARegions] 2, 'West' , 'SCO'
EXEC [dbo].[spGetCCARegions] 2, 'st'	, 'SCO'

EXEC [dbo].[spGetCCARegions] 2, NULL   , 'ICO'
EXEC [dbo].[spGetCCARegions] 2, NULL	, 'SCO'

EXEC [dbo].[spGetCCARegions] NULL, NULL, NULL, 1, 5
EXEC [dbo].[spGetCCARegions] NULL, NULL, NULL, 2, 5
EXEC [dbo].[spGetCCARegions] NULL, NULL, NULL, 3, 5


DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetCCARegions] 
	@eventUserID = NULL
	, @searchRegion = NULL -- 'East'
	, @searchProduct = NULL
/*
	, @pageIndex  = 0
	, @pageSize  = 25
	, @sortBy  = 'CCARegionID' 
	, @orderBy  = 1 -- 0: ASC; 1: DESC
*/
PRINT @returnValue 

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetCCARegions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetCCARegions]
GO

/****** Object:  StoredProcedure [dbo].[spGetCCARegions]    Script Date: 07/19/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/19/2019
-- Description:	Gets CCA Regions based on passed filters

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetCCARegions]
	-- Add the parameters for the stored procedure here
	@eventUserID int = NULL
	, @searchRegion varchar(50) = NULL
	, @searchProduct char(3) = NULL

/*
	, @pageIndex int		  = 0
	, @pageSize int			  = 25
	, @sortBy varchar(50)	  = 'CCARegionID' 
	, @orderBy int            = 1 -- 0: ASC; 1: DESC
*/

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 

	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Get CCA Region
	-- ******************************

	select 
		  r.CCARegionID	
		, r.CCARegion	
		, r.Product
		-- , case when isnull(rm.ActiveFlag, 0) = 1 then 1 else 0 end as CCARegionMapActive
		, count(*) over() as ResultCount
 	from CCARegions as r
	-- left join RegionMap as rm on rm.CCARegionID = r.CCARegionID
	where r.ActiveFlag = 1
		and (
			isnull(@searchRegion, '') = ''
			or r.CCARegion like '%' + @searchRegion + '%'
		)
		and (
			isnull(@searchProduct, '') = ''
			or r.Product = @searchProduct
		)
/*
	ORDER BY 1 -- @sortBy -- need to consider this can be a column numeric representation, but would require dynamic SQL to incorporate the column name
	
	-- apply page retrieval 
	OFFSET (@pageSize * (@pageIndex)) ROWS
	FETCH NEXT @pageSize ROWS ONLY;
*/






	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 
-- *****************************************************************************************************

	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()

		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart

		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spGetCCARegions] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetCCARegions] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetCCARegions] TO webapp
GO
-- *****************************************************************************************************