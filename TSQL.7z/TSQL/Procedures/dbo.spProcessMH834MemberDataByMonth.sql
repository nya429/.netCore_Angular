
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessMH834MemberDataByMonth] 
PRINT @returnValue 


select count(*) from expectedpayments -- for expectations on member month breakout 



SELECT count(*) FROM [dbo].[MH834MemberDataByMonth]

-- verify de-duplication worked
select 
	[MMIS_ID]
	, [MemberMonth]
	, count(*) as dupCheck
from [dbo].[MH834MemberDataByMonth]
group by 	
	[MMIS_ID]
	, [MemberMonth]
having count(*) > 1


select top 100 * from [dbo].[MH834MemberDataByMonth]
-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spProcessMH834MemberDataByMonth]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spProcessMH834MemberDataByMonth]
GO

/****** Object:  StoredProcedure [dbo].[spProcessMH834MemberDataByMonth]    Script Date: 01/21/2020 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis and Shubham Pathak 
-- Create date: 01/21/2020
-- Description:	ADS-2980
				Processes Mass Health 834 data to get latest value for member month
				Used in explorer page

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	0:17 seconds 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spProcessMH834MemberDataByMonth]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Truncate latest data
	-- ******************************

	exec spTrun_MH834MemberDataByMonth

	-- ******************************
	-- STEP 1. Get table with all values, including Mass Health 834 file date
	-- ******************************

	insert into MH834MemberDataByMonth (
		[MH834MemberDataID] 
		, [MH834SeqNum]   
		, [MH834FileName] 
		, [MH834FileDate] 
		, [MMIS_ID] 
		, [CCAID]   
		, [Product] 
		, [MH834RateCell]     
		, [RateCellStartDate] 
		, [RateCellEndDate]   
		, [MemberMonth]       

		, [ActiveFlag] 
		, [insertDate] 
		, [updateDate] 
	)
	select  
		  MH834MemberDataID	
		, MH834SeqNum	
		, MH834FileName	
		, MH834FileDate	
		, MMIS_ID	
		, CCAID	
		, Product	
		, MH834RateCell	
		, RateCellStartDate	
		, RateCellEndDate	
		, membermonth 

		, 1 as ActiveFlag	
		, @spStart as insertDate	
		, @spStart as updateDate
		
	from 
	(
		SELECT 
			  mh.MH834MemberDataID	
			, mh.MH834SeqNum	
			, mh.MH834FileName	
			, mh.MH834FileDate	
			, mh.MMIS_ID	
			, mh.CCAID	
			, mh.Product	
			, mh.MH834RateCell	
			, mh.RateCellStartDate	
			, mh.RateCellEndDate	
			-- , mh.ActiveFlag	
			-- , mh.insertDate	
			-- , mh.updateDate
			, mm.membermonth 

			-- row_number -- partition on mmis_id, membermonth order by  mh834filedate desc... where mh834RateCell is not null and <> ''
			, ROW_NUMBER() over(partition by mh.MMIS_ID,mm.membermonth  Order by mh.MH834FileDate desc ) as rnLatestByFileDate
		
		FROM MH834MemberData as mh
		inner join vwMemberMonths as mm on mm.membermonth between mh.RateCellStartDate and mh.RateCellEndDate

		where mh.MH834RateCell is not null and mh.MH834RateCell <> ''
	) as mhfilter
	where mhfilter.rnLatestByFileDate = 1
	





	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spProcessMH834MemberDataByMonth] TO [Talend] 
GRANT EXECUTE ON [dbo].[spProcessMH834MemberDataByMonth] TO [Support] 
GO
-- *****************************************************************************************************