
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMemberName] null, 'jaco'
PRINT @returnValue 

DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetMemberName] null, 'sand woo'
PRINT @returnValue 



-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetMemberName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetMemberName]
GO

/****** Object:  StoredProcedure [dbo].[spGetMemberName]    Script Date: 08/29/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/29/2019
-- Description:	API
				Quick result for Member name only
				API will use for type ahead, minimum 3 letters
				Search is on both first and last names
				Will return either CCA or state if no CCA

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetMemberName]
	-- Add the parameters for the stored procedure here
	@eventUserID int = NULL
	, @Name varchar(50) -- must be sent, intended to return a filtered set

	-- no pagination

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
	DECLARE @MemberFirstName varchar(20)
	DECLARE @MemberLastName varchar(30) 
	DECLARE @BothNamesSent bit = 0 
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 0. Split name into first/last  
	-- ******************************
	
	/*

	MemberFirstName	MemberMiddleName	MemberLastName
	SANDRA	A	WOODRING
	JEMELLE	NULL	ONEILL
	RAFAEL	R	ROMAN
	FELIX	I	SANTANA
	*/

	/*
	DECLARE @n  varchar(51) 
	DECLARE @fn varchar(20) 
	DECLARE @ln varchar(30) 

	set @n = 'first last'
	set @n = 'firstOnly'
	
	-- maybe make this a user defined function
	select @n
		, CHARINDEX(' ',@n,1) as spaceLocation
		, SUBSTRING(@n, 1, (CHARINDEX(' ',@n,1) - 1)) as subFirstName
		, SUBSTRING(@n, (CHARINDEX(' ',@n,1) + 1), (len(@n) - (CHARINDEX(' ',@n,1)) ) ) as subLastName
	*/

	-- CHECK A NAME WAS SENT AT ALL
	IF ISNULL(@Name, '') <> ''
		-- If only one name sent, set as first name
		IF CHARINDEX(' ',@Name,1) = 0
			begin
				set @BothNamesSent = 0 -- already default to this, but assign here for distinction and readibility
				set @MemberFirstName = @Name
				set @MemberLastName = @Name
				
			end
		ELSE
		-- If a space is included, split into first and last on the space, assuming search order is {[FirstName][ ][LastName]}
			BEGIN 
				set @BothNamesSent = 1 -- already default to this, but assign here for distinction and readibility
				set @MemberFirstName = SUBSTRING(@Name, 1, (CHARINDEX(' ',@Name,1) - 1)) 
				set @MemberLastName  = SUBSTRING(@Name, (CHARINDEX(' ',@Name,1) + 1), (len(@Name) - (CHARINDEX(' ',@Name,1)) ) ) 
			END

	-- print @MemberFirstName 
	-- print @MemberLastName  




	-- ******************************
	-- STEP 1. Search for member's partial name
	-- ******************************

	select top 10
		  m.MasterPatientID       -- ID
		-- was CCA before
		, isnull(m.CCA_MemberFirstName , m.MMIS_MemberFirstName  ) as MemberFirstName -- NAME
		, isnull(m.CCA_MemberMiddleName, m.MMIS_MemberMiddleName ) as MemberMiddleName-- NAME
		, isnull(m.CCA_MemberLastName  , m.MMIS_MemberLastName   ) as MemberLastName  -- NAME 
		, m.MMIS_MMIS_ID		  -- MMIS_ID
		, m.CCAID				  -- CCAID
		-- , count(*) over() as ResultCount
	from vwMemberMap as m
	where 
		-- check separate first and last names
		(
			@BothNamesSent = 1
			and (
				   m.CCA_MemberFirstName LIKE @MemberFirstName + '%'
				OR m.MMIS_MemberFirstName LIKE @MemberFirstName + '%'
			)
			and (
				   m.CCA_MemberLastName  LIKE @MemberLastName + '%'
				OR m.MMIS_MemberLastName  LIKE @MemberLastName + '%'
			)
		)
		-- only one name sent, check both first and last name for the entry
		OR  (
			@BothNamesSent = 0
			and (
				isnull(@MemberFirstName,'') = '' 
				or (
					   m.CCA_MemberFirstName LIKE @MemberFirstName + '%'
					OR m.MMIS_MemberFirstName LIKE @MemberFirstName + '%'
				)
				
				or (
					isnull(@MemberLastName,'') = '' 
					or (
						   m.CCA_MemberLastName  LIKE @MemberLastName + '%'
						OR m.MMIS_MemberLastName  LIKE @MemberLastName + '%'
					)
				)
			)
		)	


	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spGetMemberName] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetMemberName] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetMemberName] TO [webapp] 
GO
-- *****************************************************************************************************