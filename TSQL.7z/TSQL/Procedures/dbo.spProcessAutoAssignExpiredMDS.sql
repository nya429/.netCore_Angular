
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessAutoAssignExpiredMDS] 
PRINT @returnValue 

select * from DiscrepancyStatuses where DiscrepancyStatus = 'Clinical Ops- Expired MDS'
SELECT * FROM listParameters
SELECT * FROM DISCREPANCIES WHERE DISCREPANCYSTATUSID = 6 AND UPDATEDATE > '2020-01-21'
SELECT * FROM DISCREPANCIES WHERE DISCREPANCYSTATUSID = 6 AND UPDATEDATE > '2020-01-21 14:36:58.480'
SELECT * FROM DISCREPANCIES WHERE DISCREPANCYSTATUSID = 6 AND UPDATEDATE > '2020-01-21 14:39:32.463'
-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spProcessAutoAssignExpiredMDS]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spProcessAutoAssignExpiredMDS]
GO

/****** Object:  StoredProcedure [dbo].[spProcessAutoAssignExpiredMDS]    Script Date: 01/02/2020 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 01/02/2020
-- Description:	ADS-2980/ADS-2999
				This will automatically assign a discrepancy status of "Clinical Ops - Expired MDS"

				Downgrades: 
					ICO	DC1
					SCO	CW

				Post QA - 01/21/2019
					Caught SCO downgrade (CW) was not being identified properly
				

-- Modified by: Yue Song
-- Modified dt: 06/24/2020
-- Description: The auto assign failed for discrepancies which DiscrepancyId is null. - IDS-2377

-- EXEC TIME:	after revised SCO matching - 0:16 seconds; 0:05 seconds; before join rearrangement - 17:29 minutes 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spProcessAutoAssignExpiredMDS]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ProcessLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)

	
	DECLARE @AutoExpiredMDSStatus varchar(50) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'AutoExpiredMDSStatus')
	DECLARE @AutoExpiredMDSStatusID int = (select DiscrepancyStatusID from DiscrepancyStatuses where DiscrepancyStatus = @AutoExpiredMDSStatus)
	DECLARE @SCORateCellDowngrade varchar(50) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'SCORateCellDowngrade')
	DECLARE @ICORateCellDowngrade varchar(50) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ICORateCellDowngrade')
	DECLARE @OpenEndDate date = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'OpenEndDate')

-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Determine downgrades
	-- ******************************

	if object_id('tempdb..#MHDowngrades') is not null
		drop table #MHDowngrades

	select 
		MH834MemberDataID
		,MH834SeqNum
		,MH834FileName
		,MH834FileDate
		,MMIS_ID
		,CCAID
		,Product
		,MH834RateCell
		,RateCellStartDate
		,RateCellEndDate
		,ActiveFlag
		,insertDate
		,updateDate
		,rankLatestRateCell
		,previousRateCell
		,matchPrevious
		,RateCellDowngrade

	into #MHDowngrades
	from (

		select 
			MH834MemberDataID
			,MH834SeqNum
			,MH834FileName
			,MH834FileDate
			,MMIS_ID
			,CCAID
			,Product
			,MH834RateCell
			,RateCellStartDate
			,RateCellEndDate
			,ActiveFlag
			,insertDate
			,updateDate

			, rank() over(partition by mmis_id order by MH834FileDate DESC, RateCellStartDate, RateCellEndDate) as rankLatestRateCell
			, lead(MH834RateCell) over(partition by mmis_id order by MH834FileDate DESC, RateCellStartDate, RateCellEndDate) as previousRateCell
			, CASE WHEN MH834RateCell = lead(MH834RateCell) over(partition by mmis_id order by MH834FileDate DESC, RateCellStartDate, RateCellEndDate) THEN 1 ELSE 0 END as matchPrevious
			, case when 
				(Product = 'SCO' and LEFT(MH834RateCell,2) = @SCORateCellDowngrade) 
				or (Product = 'ICO' and MH834RateCell = @ICORateCellDowngrade)
				then 1
				else 0
			end as RateCellDowngrade
		from MH834MemberData
	) as down
	where rankLatestRateCell = 1 and RateCellDowngrade = 1
	order by mmis_id, MH834FileDate DESC, RateCellStartDate, RateCellEndDate

	-- ******************************
	-- STEP 2. Match to Discrepancies by date range and non-match on rate cell
	-- unit test by finding exceptions in data
	-- ******************************

/*
-- DEBUG
	select 
		down.MH834FileName
		, down.MH834FileDate
		, down.MMIS_ID
		, down.MH834RateCell
		, down.rankLatestRateCell
		, down.previousRateCell
		, down.matchPrevious
		, down.RateCellStartDate
		, down.RateCellEndDate
		, d.MemberMonth
		, d.rawCCARateCell
		, d.rawCCARegion
		, d.rawMMISRateCell
		, d.rawMMISRegion
*/
-- select * from discrepancies
	update d
		set d.DiscrepancyStatusID = @AutoExpiredMDSStatusID
		, d.updateDate = @spStart
		, d.Action_UserID = 0
	from Discrepancies as d
	inner join vwMemberMap as memMap on memMap.MasterPatientID = d.MasterPatientID
	inner join #MHDowngrades as down
		on down.MMIS_ID = coalesce(memMap.MMIS_MMIS_ID, memMap.CCA_MMIS_ID) -- is this necessary, could perhaps focus on one
		and d.MemberMonth between down.RateCellStartDate and down.RateCellEndDate
-- 	inner join MasterPatientManagement as mpm on mpm.MasterPatientID = d.MasterPatientID
-- 	inner join MonthlySummaryRecord as msr 
-- 		on msr.MasterPatientID = d.MasterPatientID 
-- 		and msr.MemberMonth = d.MemberMonth
	inner join CCAMemberSpanEnrollment as mpEnr 
		on mpEnr.CCAID = memMap.CCAID 
		and d.MemberMonth between mpEnr.EnrollStartDate and isnull(mpEnr.EnrollEndDate, @OpenEndDate)
	where 
		(
			d.DISCREPANCYSTATUSID <> 6          -- do not change status where already updated
			or  d.DISCREPANCYSTATUSID is null
		) -- IDS-2377
		-- make sure it is not a "downgrade" in MP currently
		and (
			(
				mpEnr.Product = 'ICO'  
				and down.MH834RateCell <> d.rawCCARateCell 
			)
			or 		
			(
				mpEnr.Product = 'SCO'  
				and left(down.MH834RateCell,2) <> left(d.rawCCARateCell,2) -- shortend for 'CW'
			)
		)
		AND 
		-- make sure 834 matches MMIS value for consistency
		(
			(
				mpEnr.Product = 'ICO'  
				and down.MH834RateCell = d.rawMMISRateCell 
			)
			or 		
			(
				mpEnr.Product = 'SCO'  
				and left(down.MH834RateCell,2) = left(d.rawMMISRateCell,2) -- shortend for 'CW'
			)
		)
		
	-- ******************************
	-- STEP 3. Insert into status history, too
	-- ******************************

		INSERT INTO DiscrepanciesHistory(
			DiscrepancyID
			,MonthlySummaryRecordID
			,MasterPatientID
			,MemberMonth
			,Variance
			,PaymentError
			,BaseCapitationAmount
			,PatientPayAmountN
			,PatientPayAmountSCO
			,PaidCapitationAmount
			,CCARateCellID
			,CCARegionID
			,CCAPatientPay
			,CCAPatientSpendDown
			,CCARateCardID
			,CCAAmount
			,CCANetAmount
			,MMISRateCellID
			,MMISRegionID
			,MMISPatientPay
			,MMISPatientSpendDown
			,MMISRateCardID
			,MMISAmount
			,MMISNetAmount
			,TypeRateCell
			,TypeRegion
			,TypePatientPay
			,TypePatientSpendDown
			,TypePaymentError
			,Assigned_UserID
			,Action_UserID
			,DiscrepancyStatusID
			,DueDate
			,DiscoverDate
			,ResolvedDate
			,Balanced
			,Discrepancy_ActiveFlag
			,Discrepancy_insertDate
			,Discrepancy_updateDate
			,rawMMISRateCell 
			,rawMMISRegion   
			,rawCCARateCell  
			,rawCCARegion    
			,ActiveFlag  
			,insertDate  
			,updateDate  
		) 
		select 
			d.DiscrepancyID
			,d.MonthlySummaryRecordID
			,d.MasterPatientID
			,d.MemberMonth
			,d.Variance
			,d.PaymentError
			,d.BaseCapitationAmount
			,d.PatientPayAmountN
			,d.PatientPayAmountSCO
			,d.PaidCapitationAmount
			,d.CCARateCellID
			,d.CCARegionID
			,d.CCAPatientPay
			,d.CCAPatientSpendDown
			,d.CCARateCardID
			,d.CCAAmount
			,d.CCANetAmount
			,d.MMISRateCellID
			,d.MMISRegionID
			,d.MMISPatientPay
			,d.MMISPatientSpendDown
			,d.MMISRateCardID
			,d.MMISAmount
			,d.MMISNetAmount
			,d.TypeRateCell
			,d.TypeRegion
			,d.TypePatientPay
			,d.TypePatientSpendDown
			,d.TypePaymentError
			,d.Assigned_UserID
			,d.Action_UserID
			,d.DiscrepancyStatusID
			,d.DueDate
			,d.DiscoverDate
			,d.ResolvedDate
			,d.Balanced
			,d.ActiveFlag AS Discrepancy_ActiveFlag
			,d.insertDate AS Discrepancy_insertDate
			,d.updateDate AS Discrepancy_updateDate
			,d.rawMMISRateCell 
			,d.rawMMISRegion   
			,d.rawCCARateCell  
			,d.rawCCARegion    
			,1 as ActiveFlag
			,@spStart as insertDate
			,@spStart as updateDate
		from Discrepancies as d
		where d.updateDate = @spStart



/*
	where exists (

		select MH834MemberDataID
		from #MHDowngrades as down
		where down.MH834RateCell <> d.rawCCARateCell
			and d.MemberMonth between down.RateCellStartDate and down.RateCellEndDate
	)
*/
	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spProcessAutoAssignExpiredMDS] TO [Talend] 
GRANT EXECUTE ON [dbo].[spProcessAutoAssignExpiredMDS] TO [Support] 
GO
-- *****************************************************************************************************