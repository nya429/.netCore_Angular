
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spGetDiscrepancyCommentList] @DiscrepancyID = 1
PRINT @returnValue 

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetDiscrepancyCommentList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetDiscrepancyCommentList]
GO

/****** Object:  StoredProcedure [dbo].[spGetDiscrepancyCommentList]    Script Date: 09/05/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/05/2019
-- Description:	API
				Get Discrepancy comments

				if we track masterComment, is there a performance hit over time as table grows in size?

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spGetDiscrepancyCommentList]
	-- Add the parameters for the stored procedure here
	  @eventUserID int = NULL
	, @DiscrepancyID int -- must be passed	
	-- maybe move hardcoding into stored procedure, then can check for isnull values
/*
 	, @pageIndex int		  = 0
 	, @pageSize int			  = 5 -- for parent comment only
	-- sort and order by are defaulted by insertDate desc... this should not change
	, @sortBy varchar(50)	  = 'DiscrepancyCommentID' 
	, @orderBy int            = 1 -- 0: ASC; 1: DESC
*/	

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Get Discrepancy comment by DiscrepancyID
	-- ******************************

	select  distinct -- is there a better way? (using distinct becuase of left join
		  dc.DiscrepancyCommentID	
		, dc.DiscrepancyID	
		, dc.ReplyCommentID	
		, dc.Comment_UserID	
		, u.UserNameAD
		, u.UserFirstName
		, u.UserLastName
		, dc.DiscrepancyComment	
		, dc.ActiveFlag	
		, dc.insertDate	
		, dc.updateDate
		, case when dc.ReplyCommentID is null then 1 else 0 end as MasterComment
		, case when dcrep.DiscrepancyCommentID is not null then 1 else 0 end as HasReply
	from DiscrepanciesComments as dc
	inner join Users as u on userid = dc.Comment_UserID
	left join DiscrepanciesComments as dcrep on dcrep.ReplyCommentID = dc.DiscrepancyCommentID -- concerned about performance?

	where dc.ActiveFlag = 1
		AND dc.DiscrepancyID = @DiscrepancyID
	-- order by DiscrepancyCommentID desc
	order by insertDate	desc

	-- consider finding "master" comments that have child reply comments up front


/*
		, count(*) over() as ResultCount -- generic for all multi-line get procedures

		
	ORDER BY 1 -- @sortBy -- need to consider this can be a column numeric representation, but would require dynamic SQL to incorporate the column name
	
	-- apply page retrieval 
	OFFSET (@pageSize * (@pageIndex)) ROWS
	FETCH NEXT @pageSize ROWS ONLY;
*/




	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd)
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spGetDiscrepancyCommentList] TO [Talend] 
GRANT EXECUTE ON [dbo].[spGetDiscrepancyCommentList] TO [Support] 
GRANT EXECUTE ON [dbo].[spGetDiscrepancyCommentList] TO [webapp] 
GO
-- *****************************************************************************************************