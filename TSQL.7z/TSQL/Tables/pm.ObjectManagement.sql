
USE [RevRec]
GO


/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [pm].[ObjectManagement]

-- *****************************************************************************************************
*/


/****** Object:  Table [pm].[ObjectManagement]    Script Date: 09/09/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/09/2019
-- Description:	(PM) Project Management 
				Tool for tracking status of objects


-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pm].[ObjectManagement]') AND type in (N'U'))
	DROP TABLE [pm].[ObjectManagement]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pm].[ObjectManagement]') AND type in (N'U'))
BEGIN
CREATE TABLE [pm].[ObjectManagement](

	-- sample table definition
	  ObjectManagementID int IDENTITY(1,1) NOT NULL
	, JiraTag			varchar(100) NULL
	, AppSection		varchar(100) NULL
	, ObjectType		varchar(100) NOT NULL
	, ObjectName		varchar(100) NOT NULL
	, ObjectFunction	varchar(100) NULL
	, ObjectActive		varchar(100) NULL
	, CodeReview		varchar(1000) NULL
	, ObjectStatus		varchar(100) NULL
	, APIStatus 		varchar(100) NULL
	, IntegrationStatus varchar(100) NULL
	, Pagination        varchar(100) NULL
	-- , [defCol]    [bit]               NOT NULL CONSTRAINT DF_ObjectManagement_defCol DEFAULT 0

	
	, CONSTRAINT [PK_ObjectManagement] PRIMARY KEY 
	(
		ObjectManagementID 
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	, CONSTRAINT [UQ_ObjectManagement] UNIQUE
	(
		ObjectType
		, ObjectName
	)

) -- ON [PRIMARY]
END
GO


SET ANSI_PADDING OFF
GO

/*
-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [pm].[ObjectManagement] TO [Talend] 
GRANT SELECT ON [pm].[ObjectManagement] TO [Support] 
GO
-- *****************************************************************************************************
*/