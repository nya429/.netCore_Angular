
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[RegionMap]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[RegionMap]    Script Date: 07/08/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/08/2019
-- Description:	Table for storing the MMIS to CCA region code map
				This is part of the rate card

				Post-QA: 09/12/2019
					altered column CCARegionID to be null
						This will allow the the map to contain all MMIS regions, awaiting a map to CCA region
						Will be compatible with the 1-to-many concept on the interface in the admin screen.

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RegionMap]') AND type in (N'U'))
	DROP TABLE [dbo].[RegionMap]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RegionMap]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RegionMap](
	-- sample table definition
	  RegionMapID    [int] IDENTITY(1,1) NOT NULL
	, CCARegionID    [int] NULL -- will create placeholder map for missing CCARegionID mapping, compatible with API
	, MMISRegionID   [int] NOT NULL
	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 
	-- , [defCol]    [bit]               NOT NULL CONSTRAINT DF_RegionMap_defCol DEFAULT 0

	
	, CONSTRAINT [PK_RegionMap] PRIMARY KEY 
	(
		RegionMapID ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	, CONSTRAINT [UQ_RegionMap] UNIQUE
	(
		-- CCARegionID    -- Do not include this in unique constraint... only one map per active MMISRegion
		MMISRegionID 
		, ActiveFlag
	)

) -- ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[RegionMap]') AND name = 'CCARegionID') ALTER TABLE [dbo].[RegionMap] ADD CCARegionID    [int] NULL ELSE ALTER TABLE [dbo].[RegionMap] ALTER COLUMN CCARegionID    [int] NULL


/*
-- ************************************************************************************
	-- other samples to include
	-- sample key
-- ************************************************************************************
*/

SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[RegionMap] TO [Talend] 
GRANT SELECT ON [dbo].[RegionMap] TO [Support] 
GO
-- *****************************************************************************************************
