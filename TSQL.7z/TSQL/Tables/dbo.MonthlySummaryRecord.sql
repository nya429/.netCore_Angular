
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[MonthlySummaryRecord]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[MonthlySummaryRecord]    Script Date: 08/06/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/06/2019
-- Description:	Table for storing the monthly summary record, based on the daily process
				Truncate and reload of table part of daily process

				Note: Columns from original RevRec: 

					id -- just a key
					member_id -- equivalent to MasterPatientID ?
					month -- equivalent to member Month ?

					org_rating_category_id     payor_rating_category_id
					org_rating_category_rate   payor_rating_category_rate
					org_patient_pay			   payor_patient_pay
					org_spenddown			   payor_spenddown
					org_premium                payor_premium
					org_writeoff			   

					unexplained -- equivalent to payment error 
					paid -- paid capitation amount
					full_receivable -- base captiation amount
					deferred 
					disenrolled 
					enrolled_payable 
					enrolled_receivable 
					
					-- status tracking
					archived_at
					created_at
					updated_at
					program_id

				Post QA/Unit-Test 10/11/2019

					10/11/2019 - Monthly summary record has nullable payment details from state, in case CCA has member missing from state

				Post QA 10/16/2019
					Added raw columns for rate cell and region for both CCA and MMIS


-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MonthlySummaryRecord]') AND type in (N'U'))
	DROP TABLE [dbo].[MonthlySummaryRecord]
-- *****************************************************************************************************

-- remove second if not exists statement if dropping the table in the statement above.
-- IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MonthlySummaryRecord]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MonthlySummaryRecord](


	MonthlySummaryRecordID int identity(1,1)


	, MasterPatientID int NOT NULL -- makes up unique key
	, MMIS_ID char(12) NULL -- included for ease of reference... may be redundant with MasterPatientID
	, MemberMonth date NOT NULL	   -- makes up unique key; aligns to CapitationMonthYear

	, Variance numeric(18, 2) NULL -- compared to expected CCA payment: PaidCapitationAmount - CCANetAmount
	
	-- Payment error SHOULD NOT be part of the variance calculation
	, PaymentError numeric(18, 2) NULL -- compared to expected amount based on state details, like "unexplained" in original: PaidCapitationAmount - MMISNetAmount

	-- from PatientPayDetail... what the state actually says they paid, based on file
	, BaseCapitationAmount	numeric(18,2) NULL
	, PatientPayAmountN		numeric(18,2) NULL -- aligns to Patient Pay
	, PatientPayAmountSCO	numeric(18,2) NULL -- aligns to Patient Spend Down
	, PaidCapitationAmount	numeric(18,2) NULL -- total_paid
	, Remit                 numeric(18,2) NULL -- total remit

	, CCARateCellID int NULL
	, CCARegionID int NULL
	, CCAPatientPay numeric(18,2) NULL
	, CCAPatientSpendDown numeric (18,2) NULL

	-- CCA's expected based on current member's rate cell and region in MP
	, CCARateCardID int NULL
	, CCAAmount numeric(18,2) NULL -- from the rate card
	, CCANetAmount numeric(18,2) NULL -- minus patient pay and spend down
		
	, MMISRateCellID int  NULL
	, MMISRegionID int NULL
	, MMISPatientPay numeric(18,2) NULL
	, MMISPatientSpendDown numeric (18,2) NULL
	
	-- expected payment based on state's rate rate cell and region
	, MMISRateCardID int NULL
	, MMISAmount numeric(18,2) NULL -- expect it to align with base captiation amount
	, MMISNetAmount numeric(18,2) NULL -- minus patient pay and spend down

	, rawMMISRateCell char(4) NULL
	, rawMMISRegion char(5) NULL

	, rawCCARateCell varchar(50) NULL
	, rawCCARegion varchar(50) NULL

/*
	, PaymentPeriodStart datetime NULL
	, PaymentPeriodEnd datetime NULL
	, EffectiveDate datetime NULL
	, EndDate datetime NULL

	-- what are these, do we need them
	, OverrideRC varchar(4) NULL
	, Legacy char(1) NULL
	
*/




	, CONSTRAINT [PK_MonthlySummaryRecord] PRIMARY KEY 
	(
		MonthlySummaryRecordID ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
/*
	, CONSTRAINT [UQ_MonthlySummaryRecord] UNIQUE
	(
		[colName] ASC
	)
*/
) -- ON [PRIMARY]
END
GO



SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[MonthlySummaryRecord] TO [Talend] 
GRANT SELECT ON [dbo].[MonthlySummaryRecord] TO [Support] 
GO
-- *****************************************************************************************************
