
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[CCARegions]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[CCARegions]    Script Date: 07/08/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/08/2019
-- Description:	Source table for storing CCA regions
				

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CCARegions]') AND type in (N'U'))
	DROP TABLE [dbo].[CCARegions]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CCARegions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CCARegions](
	-- sample table definition
	  CCARegionID    [int] IDENTITY(1,1) NOT NULL
	, CCARegion  varchar(50)  NULL
	, Product    char(3) NULL
	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 
	-- , [defCol]    [bit]               NOT NULL CONSTRAINT DF_CCARegions_defCol DEFAULT 0

	
	, CONSTRAINT [PK_CCARegions] PRIMARY KEY 
	(
		CCARegionID 
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	, CONSTRAINT [UQ_CCARegions] UNIQUE
	(
		CCARegion
	)

) -- ON [PRIMARY]
END
GO




SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[CCARegions] TO [Talend] 
GRANT SELECT ON [dbo].[CCARegions] TO [Support] 
GO
-- *****************************************************************************************************
