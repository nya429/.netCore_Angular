
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[UserRoles]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[UserRoles]    Script Date: 08/07/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/07/2019
-- Description:	Table stores user role definitions and IDs
				These roles have built in functionality for the application. 
				Any new addition or alteration here would result in core changes of the application as a whole.

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserRoles]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserRoles](

	  UserRoleID int identity(1,1) NOT NULL
	, UserRole varchar(50) NOT NULL
	, UserRoleDescription varchar(1000) NULL
	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 

	
	, CONSTRAINT [PK_UserRoles] PRIMARY KEY 
	(
		UserRoleID
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	, CONSTRAINT [UQ_UserRoles] UNIQUE
	(
		UserRole
	)

) -- ON [PRIMARY]
END
GO




SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[UserRoles] TO [Talend] 
GRANT SELECT ON [dbo].[UserRoles] TO [Support] 
GO
-- *****************************************************************************************************
