
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[MH834MemberData]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[MH834MemberData]    Script Date: 11/22/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 11/22/2019
-- Description:	ADS-3000
				Table for storing Mass health 834 sourced data
				Will be used for comparison to other sources to reduce research effort on end user team


-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MH834MemberData]') AND type in (N'U'))
	DROP TABLE [dbo].[MH834MemberData]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MH834MemberData]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MH834MemberData](

	-- sample table definition
	MH834MemberDataID    [int] IDENTITY(1,1) NOT NULL
	, MH834SeqNum int NULL -- or should this be file ID if available
	, MH834FileName varchar(100) NULL -- or should this be file ID if available
	, MH834FileDate datetime2(3) NULL
 	, MMIS_ID char(12) NOT NULL
	, CCAID BIGINT NULL -- in case they send CCA ID
	, Product char(3) NULL
	, MH834RateCell varchar(50) NOT NULL
 	, RateCellStartDate date NULL
 	, RateCellEndDate date NULL
	

	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 

	
	, CONSTRAINT [PK_MH834MemberData] PRIMARY KEY 
	(
		MH834MemberDataID
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
/*
	, CONSTRAINT [UQ_MH834MemberData] UNIQUE
	(
		[colName] ASC
	)
*/
) -- ON [PRIMARY]
END
GO


SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[MH834MemberData] TO [Talend] 
GRANT SELECT ON [dbo].[MH834MemberData] TO [Support] 
GO
-- *****************************************************************************************************
