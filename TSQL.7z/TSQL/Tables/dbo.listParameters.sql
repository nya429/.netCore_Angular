
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[listParameters]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[listParameters]    Script Date: 08/07/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/07/2019
-- Description:	Application contained table storing parameters and hard-coded values for application control

				Post QA: 09/12/2019
					Altered column length to accomdate larger parameter names
					
					

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[listParameters]') AND type in (N'U'))
	DROP TABLE [dbo].[listParameters]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[listParameters]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[listParameters](
	  [parameterID]       [int] IDENTITY(1,1) NOT NULL
	-- , [appName]           [varchar](20)       NOT NULL -- this is on the other servers, but to stay consistent with StaticParameters table, made this the same with column definition below
	, [ApplicationName]   [varchar](50)       NOT NULL -- should this be excluded for RevRec... maybe still useful in sub-sets of the application
	, [parameterName]     [varchar](100)      NULL 
	, [parameterDataType] [varchar](20)       NULL -- could consider separating this into separate elements, but overkill at this time
	, [parameterValue]    [varchar](1000)     NULL -- this needs to accomodate a wide range of values.  Will start at 1000 and hopefully doesn't have to be larger than this.
	-- , [defCol]    [bit]               NOT NULL CONSTRAINT DF_listParameters_defCol DEFAULT 0

	
	, CONSTRAINT [PK_listParameters] PRIMARY KEY 
	(
		[parameterID] ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


	, CONSTRAINT [UQ_listParameters] UNIQUE
	(
		[ApplicationName] ASC
		, [parameterName] ASC
	)
) -- ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[listParameters]') AND name = 'parameterName') ALTER TABLE [dbo].[listParameters] ADD [parameterName]     [varchar](100)      NULL ELSE ALTER TABLE [dbo].[listParameters] ALTER COLUMN [parameterName]     [varchar](100)      NULL 


SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[listParameters] TO [Talend] 
GRANT SELECT, UPDATE ON [dbo].[listParameters] TO [Support] 
GO
-- *****************************************************************************************************
