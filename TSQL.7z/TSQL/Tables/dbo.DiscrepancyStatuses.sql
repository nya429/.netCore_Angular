
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[DiscrepancyStatuses]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[DiscrepancyStatuses]    Script Date: 08/07/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/07/2019
-- Description:	Statuses for use with managing discrepancies

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/
/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DiscrepancyStatuses]') AND type in (N'U'))
	DROP TABLE [dbo].[DiscrepancyStatuses]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DiscrepancyStatuses]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DiscrepancyStatuses](
	  DiscrepancyStatusID int identity(1,1) NOT NULL
	, DiscrepancyStatus varchar(50) NOT NULL
	, DiscrepancyStatusDescription varchar(1000) NULL
	, DiscrepancyCategoryID int -- varchar(20) NULL -- reporting category: i.e. new, resolved, completed... possibly will create another table for this and let the put procedure perform the insert/update to map appropriately
	, DiscrepancyStatusType int -- varchar(20) NULL -- 0 = system maintenance; 1 = user entered; future values, would need lookup?
		/*
			NOTE: 
				Stored procedure may have to distinguish between displaying this as a binary selection, as there is potential for this column to be used for more "types".
				At that point, may need to introduce a separate DisplayFlag bit to identify whether or not the get routine will return the status or not
		*/
	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 
	
	, CONSTRAINT [PK_DiscrepancyStatuses] PRIMARY KEY 
	(
		DiscrepancyStatusID 
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	, CONSTRAINT [UQ_DiscrepancyStatuses] UNIQUE
	(
		DiscrepancyStatus
	)

) -- ON [PRIMARY]
END
GO


SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[DiscrepancyStatuses] TO [Talend] 
GRANT SELECT ON [dbo].[DiscrepancyStatuses] TO [Support] 
GO
-- *****************************************************************************************************
