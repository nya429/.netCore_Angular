
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[PaymentDetailSpendDown]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[PaymentDetailSpendDown]    Script Date: 09/21/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/21/2019
-- Description:	Table for storing Spend Down details by month

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PaymentDetailSpendDown]') AND type in (N'U'))
	DROP TABLE [dbo].[PaymentDetailSpendDown]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PaymentDetailSpendDown]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PaymentDetailSpendDown](

	PaymentDetailSendDownID int identity(1,1) NOT NULL
	, MMISFileProcessID int NOT NULL

	, MemberID char(12) NOT NULL
	, EffectiveDate datetime NULL
	, EndDate datetime NULL
	, CapitationMonthYear datetime NOT NULL
	, RateCell char(4) NULL
	, MCRegion char(5) NULL
	, BaseCapitationAmount numeric(18,2) NULL
	-- , sumPatientPayAmountN   numeric(18,2) NULL
	, SpendDown numeric(18,2) NULL -- sumPatientPayAmountSCO	numeric(18,2) NULL
	-- , Remit numeric(18,2) NULL -- sumPaidCapitationAmount 
	, CountPayCode		  int NOT NULL -- used for determing payment vs adjustment
	, CountRetractionCode int NOT NULL -- used for determing payment vs adjustment
	, PaymentIndicator int NOT NULL -- used for determining payment vs adjustment

	-- consider sum retractions vs sum payments


	-- , ActiveFlag bit NULL
	, insertDate datetime2(3) NOT NULL 
	, updateDate datetime2(3) NOT NULL -- this may get used in a reprocessing effort

	
	, CONSTRAINT [PK_PaymentDetailSpendDown] PRIMARY KEY 
	(
		PaymentDetailSendDownID
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
/*
	, CONSTRAINT [UQ_PaymentDetailSpendDown] UNIQUE
	(
		[colName] ASC
	)
*/
) -- ON [PRIMARY]
END
GO



SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[PaymentDetailSpendDown] TO [Talend] 
GRANT SELECT ON [dbo].[PaymentDetailSpendDown] TO [Support] 
GO
-- *****************************************************************************************************
