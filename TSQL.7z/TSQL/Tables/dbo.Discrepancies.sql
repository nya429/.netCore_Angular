
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT top 10 * FROM [dbo].[Discrepancies]



-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[Discrepancies]    Script Date: 08/19/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/19/2019
-- Description:	Primary application table
				Used for managing discrepancies identified during daily process
				Taken from monthly summary record

				Post QA - 10/16/2019
					Added "raw" ratecell and region for both CCA and MMIS to be passed from monthly summary record


-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/
/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Discrepancies]') AND type in (N'U'))
	DROP TABLE [dbo].[Discrepancies]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Discrepancies]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Discrepancies](
	DiscrepancyID int IDENTITY(1, 1) NOT NULL

	-- ************************************************************************
	-- detail pulled from monthly summary record, should mirror table columns
	-- ************************************************************************
	, MonthlySummaryRecordID int NOT NULL -- probably can be part of unique key... will leave out unless necessary; may eliminte, gets truncated and reloaded every day?
	, MasterPatientID int NOT NULL -- makes up unique key
	, MemberMonth date NOT NULL	   -- makes up unique key

	, Variance numeric(18, 2) NULL -- compared to expected CCA payment: PaidCapitationAmount - CCANetAmount
	
	-- Payment error SHOULD NOT be part of the variance calculation
	, PaymentError numeric(18, 2) NULL -- compared to expected amount based on state details, like "unexplained" in original: PaidCapitationAmount - MMISNetAmount

	-- from PatientPayDetail... what the state actually says they paid, based on file
	, BaseCapitationAmount	numeric(18,2) NOT NULL
	, PatientPayAmountN		numeric(18,2) NOT NULL -- aligns to Patient Pay
	, PatientPayAmountSCO	numeric(18,2) NOT NULL -- aligns to Patient Spend Down
	, PaidCapitationAmount	numeric(18,2) NOT NULL
	

	, CCARateCellID int NULL
	, CCARegionID int NULL
	, CCAPatientPay numeric(18,2) NULL
	, CCAPatientSpendDown numeric (18,2) NULL

	-- CCA's expected based on current member's rate cell and region in MP
	, CCARateCardID int NULL
	, CCAAmount numeric(18,2) NULL -- from the rate card
	, CCANetAmount numeric(18,2) NULL -- minus patient pay and spend down
		
	, MMISRateCellID int NULL
	, MMISRegionID int NULL
	, MMISPatientPay numeric(18,2) NULL
	, MMISPatientSpendDown numeric (18,2) NULL
	
	-- expected payment based on state's rate rate cell and region
	, MMISRateCardID int NULL
	, MMISAmount numeric(18,2) NULL -- expect it to align with base captiation amount
	, MMISNetAmount numeric(18,2) NULL -- minus patient pay and spend down

	
	-- ************************************************************************
	-- Specific to discrepancy tracking
	-- ************************************************************************
	

	-- this relates to be the actual values, both CCA and MMIS keys and amounts
	, TypeRateCell bit NOT NULL
	, TypeRegion bit NOT NULL
	, TypePatientPay bit NOT NULL
	, TypePatientSpendDown bit NOT NULL
	, TypePaymentError bit NOT NULL -- amount of payment error

	-- status columns
	, Assigned_UserID int NULL
	, Action_UserID int NULL
	, DiscrepancyStatusID int NULL
	, DueDate date NULL
	, DiscoverDate date NULL -- will match insert date, unless re-opened, then will reflect the initial re-open date; will use for aging
	, ResolvedDate date NULL -- only when a designated resolved system status/balanced bit is used; re-open, this date is cleared
	, Balanced bit NULL -- will consider this for system marking complete/resolved 

	, rawMMISRateCell char(4) NULL
	, rawMMISRegion char(5) NULL

	, rawCCARateCell varchar(50) NULL
	, rawCCARegion varchar(50) NULL

	, ActiveFlag bit NULL
	, insertDate datetime2(3) NULL -- this can translate to discover date
	, updateDate datetime2(3) NULL -- could possibly used as resolution date via history in combination with the status

	, CONSTRAINT [PK_Discrepancies] PRIMARY KEY CLUSTERED 
	(
		DiscrepancyID ASC
	)
	/*
	-- may need to be more managed this just these two
	, CONSTRAINT [UQ_Discrepancies] UNIQUE NONCLUSTERED 
	(
		MasterPatientID ASC,
		MemberMonth ASC
	)
	*/
	/*
	-- should this be introduced in addition to or instead of MasterPatientID/MemberMonth?
	, CONSTRAINT [UQ_Discrepancies_MonthlySummaryRecord] UNIQUE NONCLUSTERED 
	(
		MonthlySummaryRecordID
		
	)
	*/

) -- ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[Discrepancies]') AND name = 'rawMMISRateCell') ALTER TABLE [dbo].[Discrepancies] ADD rawMMISRateCell char(4) NULL    
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[Discrepancies]') AND name = 'rawMMISRegion')   ALTER TABLE [dbo].[Discrepancies] ADD rawMMISRegion   char(5) NULL    
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[Discrepancies]') AND name = 'rawCCARateCell')  ALTER TABLE [dbo].[Discrepancies] ADD rawCCARateCell  varchar(50) NULL
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[Discrepancies]') AND name = 'rawCCARegion')    ALTER TABLE [dbo].[Discrepancies] ADD rawCCARegion    varchar(50) NULL




SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[Discrepancies] TO [Talend] 
GRANT SELECT ON [dbo].[Discrepancies] TO [Support] 
GO
-- *****************************************************************************************************
