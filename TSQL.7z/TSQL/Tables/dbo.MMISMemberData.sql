
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[MMISMemberData]

-- confirm viable primary key option
SELECT * FROM [dbo].[MMISMemberData]
WHERE MMIS_ID IS NULL

-- unique key review:
select 
	  MemberID	
	, LastName	
	, FirstName	
	, MiddleInitial	
	, Suffix
	, count(*) as countPaymentEntries
from PDRIn.DBO.MMIS8200MDetail
where CapitationMonthYear >= '2019-01-01'
group by 
	  MemberID	
	, LastName	
	, FirstName	
	, MiddleInitial	
	, Suffix

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[MMISMemberData]    Script Date: 07/22/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/22/2019
-- Description:	Table to store MMIS member data and also hold the master patient ID 

				Unit-test: 10/07/2019
					Moved MasterPatientID to new MasterPatientManagement table 
					Altered table to track only MMIS_ID as primary key
					Removed unique constraint as that would be redundant

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/



-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MMISMemberData]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MMISMemberData](


	/*
	-- definition of MMIS8200MDetail table from PDRIN
	  MemberID char(12) NULL
	, LastName char(23) NULL
	, FirstName char(15) NULL
	, MiddleInitial char(1) NULL
	, Suffix char(19) NULL
	, countPaymentEntries int NULL
	*/

	--  MasterPatientID    int IDENTITY(1,1) NOT NULL
 	MMIS_ID char(12) NOT NULL
 	, MemberFirstName varchar(20) NULL
 	, MemberMiddleName varchar(20) NULL
 	, MemberLastName varchar(30) NULL
 	, Suffix varchar(19) NULL

	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 

	
	, CONSTRAINT [PK_MMISMemberData] PRIMARY KEY 
	(
		-- MasterPatientID ASC
		MMIS_ID 
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
/*
	, CONSTRAINT [UQ_MMISMemberData] UNIQUE
	(
		MMIS_ID 
		-- these make actual demographic constraint, but we'll only use the latest
 		-- , MemberFirstName 
 		-- , MemberMiddleName
 		-- , MemberLastName
 		-- , Suffix
	)
*/
) -- ON [PRIMARY]
END
GO



SET ANSI_PADDING OFF
GO



-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[MMISMemberData] TO [Talend] 
GRANT SELECT ON [dbo].[MMISMemberData] TO [Support] 
GO
-- *****************************************************************************************************
