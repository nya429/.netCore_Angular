
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[logFileLoad]

-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[logFileLoad]') AND type in (N'U'))
	DROP TABLE [dbo].[logFileLoad]
-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[logFileLoad]    Script Date: 09/13/2018 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/30/2019
-- Description:	Table for logging files
				
				(layout same as PartnerExchange)


-- Modified by: 
-- Modified dt: 
-- Description: 
-- *****************************************************************************************************
*/

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[logFileLoad]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[logFileLoad](
	FileID int IDENTITY(1,1) NOT NULL,  -- surrogate key
	FileName varchar(100) NOT NULL, 
	FileType varchar(50) NOT NULL, -- indicates how the file is used in the application
	FileLocation varchar(1000) NULL, -- for full path

	OutboundFlag bit NOT NULL, -- set 1 for outbound (sending), 0 for inbound (receiving)
	ProcessedDate datetime2(0) NOT NULL, -- future use (check with Matt on his thoughts), could be when loaded data goes through some additional transformation or process
	FileRowCount int NULL, -- for successful row counts from inbound/outbound file
	RowCountError int NULL -- for tracking error records in a file that do not get loaded
	
	-- [TotalRowCount] [int] NULL -- for tracking all records in a file... can we just get rid of this?


	-- [Duration] -- future column... may be recorded further by the logExecute table

, CONSTRAINT [PK_logFileLoad] PRIMARY KEY CLUSTERED 
(
	FileID
) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

, CONSTRAINT [UQ_logFileLoad] UNIQUE
(
	  FileName 
	, FileType
	, ProcessedDate
)

) ON [PRIMARY]
END
GO


SET ANSI_PADDING OFF
GO

GRANT SELECT, INSERT, UPDATE on [dbo].[logFileLoad] to Talend
GO
