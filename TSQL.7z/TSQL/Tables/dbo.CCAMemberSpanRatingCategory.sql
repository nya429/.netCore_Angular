
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[CCAMemberSpanRatingCategory]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[CCAMemberSpanRatingCategory]    Script Date: 08/20/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/20/2019
-- Description:	For storing member rating category spans 
				Should join back to CCAMemberData

-- Modified by: Jonathan Lewis
-- Modified dt: 01/08/2020
-- Description: ADS-2980/ADS-2915
				Will add ActiveFlag, Insert and Update dates to the member data imported.
				These will then be managed by the validation routine.
				Will also have to update the expected payment process to consider the active flags from these tables.

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/


-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CCAMemberSpanRatingCategory]') AND type in (N'U'))
	DROP TABLE [dbo].[CCAMemberSpanRatingCategory]
-- *****************************************************************************************************

-- remove second if not exists statement if dropping the table in the statement above.
-- IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CCAMemberSpanRatingCategory]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CCAMemberSpanRatingCategory](

	  CCAMemberSpanRatingCategoryID int IDENTITY(1,1) NOT NULL
	, CCAID bigint NULL
 	, RatingCategory varchar(50) NULL
 	, RatingCategoryStartDate date NULL
 	, RatingCategoryEndDate date NULL

	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 

	
	, CONSTRAINT [PK_CCAMemberSpanRatingCategory] PRIMARY KEY 
	(
		CCAMemberSpanRatingCategoryID ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
/*
	, CONSTRAINT [UQ_CCAMemberSpanRatingCategory] UNIQUE
	(
		[colName] ASC
	)
*/
) -- ON [PRIMARY]
END
GO




SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[CCAMemberSpanRatingCategory] TO [Talend] 
GRANT SELECT ON [dbo].[CCAMemberSpanRatingCategory] TO [Support] 
GO
-- *****************************************************************************************************
