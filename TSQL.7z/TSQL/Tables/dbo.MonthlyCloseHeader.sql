
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[MonthlyCloseHeader]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[MonthlyCloseHeader]    Script Date: 08/21/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/21/2019
-- Description:	Header table to record monthly close event.
				This will be a summary of the payment and variance details in the MonthlyCloseRecord.
				It will record the userID and process date (as insertDate).

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseHeader]') AND type in (N'U'))
	DROP TABLE [dbo].[MonthlyCloseHeader]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseHeader]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MonthlyCloseHeader](

	MonthlyCloseHeaderID int identity(1,1) NOT NULL
	, UserID int NOT NULL
	, ReportMonth date NOT NULL

	/*
	, CCA_Premium numeric(18,2) NULL
	, CCA_PatientPay numeric(18,2) NULL -- varchar(50) NULL -- Org_Patient_Pay
 	, CCA_PatientSpendDown numeric(18,2) NULL -- varchar(50) NULL -- Org_Spend_Down

	, BaseCapitationAmount numeric (18,2) NULL --  Contract_Rate ?
	, PaidCapitationAmount numeric(18,2) NULL -- from state
	, MMIS_PatientPay numeric(18,2) NULL -- varchar(50) NULL -- Payor_Patient_Pay; , PatientPayAmountN numeric(18,2) NULL 
	, MMIS_PatientSpendDown numeric(18,2) NULL -- varchar(50) NULL -- Payor_Spend_Down; , PatientPayAmountSCO numeric(18,2) NULL
	
	, Unexplained numeric(18,2) NULL
	, Variance numeric(18,2) NULL
	, WriteOff numeric(18,2) NULL
	*/


	, ProcessIndicator    char(1)      not null -- Y - already processed - ignore; N - first time process; R - marked for reprocessing

	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 

		
	, CONSTRAINT [PK_MonthlyCloseHeader] PRIMARY KEY 
	(
		MonthlyCloseHeaderID ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	, CONSTRAINT [UQ_MonthlyCloseHeader] UNIQUE
	(
		ReportMonth 
	)

) -- ON [PRIMARY]
END
GO




SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[MonthlyCloseHeader] TO [Talend] 
GRANT SELECT ON [dbo].[MonthlyCloseHeader] TO [Support] 
GO
-- *****************************************************************************************************
