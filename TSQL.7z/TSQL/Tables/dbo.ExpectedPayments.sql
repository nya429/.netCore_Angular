
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[ExpectedPayments]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[ExpectedPayments]    Script Date: 10/09/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 10/09/2019
-- Description:	Table for storing expected payments by member month based on CCA data

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ExpectedPayments]') AND type in (N'U'))
	DROP TABLE [dbo].[ExpectedPayments]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ExpectedPayments]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ExpectedPayments](

	ExpectedPaymentsID int identity(1,1) NOT NULL
	, MasterMemberMonth datetime NOT NULL
	, CCAID bigint NOT NULL
	, MMIS_ID char(12) NULL
	, MemberFirstName varchar(20) NULL
	, MemberMiddleName varchar(20) NULL
	, MemberLastName varchar(30) NULL
	, Gender char(1) NULL
	, DOB date NULL
	, DOD date NULL
	, Product char(3) NULL
	, EnrollStartDate date NULL
	, EnrollEndDate date NULL
	, RatingCategory varchar(50) NULL
	, RatingCategoryStartDate date NULL
	, RatingCategoryEndDate date NULL
	, Region varchar(50) NULL
	, RegionStartDate date NULL
	, RegionEndDate date NULL
	, PatientPay varchar(50) NULL
	, PatientPayStartDate date NULL
	, PatientPayEndDate date NULL
	, PatientSpendDown varchar(50) NULL
	, PatientSpendDownStartDate date NULL
	, PatientSpendDownEndDate date NULL
	, RateCardID int NULL
	, CCARateCellID int NULL
	, CCARateCell varchar(50) NULL
	, CCARegionID int NULL
	, CCARegion varchar(50) NULL
	, StartDate date NULL
	, EndDate date NULL
	, Amount numeric(18,2) NULL
	, RateCardLabel varchar(20) NULL
	, Eligibility char(1) NULL
	, EligibilityStatus varchar(16) NULL
	, ActiveFlag bit NULL
	, insertDate datetime2(3) NULL
	, updateDate datetime2(3) NULL
	
	, CONSTRAINT [PK_ExpectedPayments] PRIMARY KEY 
	(
		ExpectedPaymentsID
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	, CONSTRAINT [UQ_ExpectedPayments] UNIQUE
	(
		 MasterMemberMonth 
		, CCAID 	
	)

) -- ON [PRIMARY]
END
GO

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[ExpectedPayments]') AND name = N'IDX_ExpectedPayments_CCAID')
		CREATE NONCLUSTERED INDEX [IDX_ExpectedPayments_CCAID] ON [dbo].[ExpectedPayments]
		(
			CCAID
		) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[ExpectedPayments]') AND name = N'IDX_ExpectedPayments_MMIS_ID')
		CREATE NONCLUSTERED INDEX [IDX_ExpectedPayments_MMIS_ID] ON [dbo].[ExpectedPayments]
		(
			MMIS_ID
		) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[ExpectedPayments] TO [Talend] 
GRANT SELECT ON [dbo].[ExpectedPayments] TO [Support] 
GO
-- *****************************************************************************************************
