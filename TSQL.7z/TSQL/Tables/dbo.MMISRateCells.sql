
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[MMISRateCells]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[MMISRateCells]    Script Date: 07/17/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/17/2019
-- Description:	Table for storing MMIS Rate Cells

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MMISRateCells]') AND type in (N'U'))
	DROP TABLE [dbo].[MMISRateCells]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MMISRateCells]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MMISRateCells](

	  MMISRateCellID [int] IDENTITY(1,1) NOT NULL
	, MMISRateCell   varchar(50)  NULL
	, Product    char(3) NULL
	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 

	
	, CONSTRAINT [PK_MMISRateCells] PRIMARY KEY 
	(
		MMISRateCellID ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	, CONSTRAINT [UQ_MMISRateCells] UNIQUE
	(
		MMISRateCell   
		, Product 
	)

) -- ON [PRIMARY]
END
GO



SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[MMISRateCells] TO [Talend] 
GRANT SELECT ON [dbo].[MMISRateCells] TO [Support] 
GO
-- *****************************************************************************************************
