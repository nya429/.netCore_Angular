
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[ExecutionLog]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[ExecutionLog]    Script Date: 08/07/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/07/2019
-- Description:	Execution Log for tracking application processing execution and application errors
				Modeled after PE_DI_Logs from PartnerExchange

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/
/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ExecutionLog]') AND type in (N'U'))
	DROP TABLE [dbo].[ExecutionLog]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ExecutionLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ExecutionLog](
	ExecutionLogID int identity(1,1) NOT NULL,
	[job_repository_id] [varchar](255) NULL, -- these might be removable
	[project] [varchar](50) NULL,			 -- these might be removable
	[job] [varchar](255) NOT NULL,
	[message_type] [varchar](255) NULL,
	[message] [varchar](255) NULL,
	[EndTime] [datetime] NOT NULL,
	[duration] [bigint] NULL,
	[Count] [int] NULL,
	[StartTime] [datetime] NOT NULL,

	-- jlewis 20180309: Added these columns for specific stored procedure error logging
	[successFlag] [bit] NULL, -- bit to indicate success or failure of a job or stored procedure
	[errorNumber] [int] NULL, -- SQL error number, if available... helpful reference for web lookup
	[errorProcedure] [varchar](255) NULL, -- SQL error procedure... if called from a master procedure
	[errorLine] [int] NULL, -- SQL stored procedure line error was encountered, helpful for quick debugging
	[errorSeverity] [int] NULL, -- SQL error severity... reference, but not critical 
	[errorState] [int] NULL, -- SQL error state... reference, but not critical 


	CONSTRAINT [PK_ExecutionLog] PRIMARY KEY 
	(
		ExecutionLogID 
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
/*
	-- not sure about the unique constraint at this time
	, CONSTRAINT [UQ_ExecutionLog] UNIQUE
	(
		[job] ASC,
		[StartTime] ASC
	)
*/
) -- ON [PRIMARY]
END
GO



SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT, INSERT ON [dbo].[ExecutionLog] TO [Talend] 
GRANT SELECT ON [dbo].[ExecutionLog] TO [Support] 
GO
-- *****************************************************************************************************
