
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[MMISFileProcessing]


-- file names and member months
SELECT DISTINCT
	ReportName
	, case datediff(month,PaymentPeriodStart, PaymentPeriodEnd) when 0 then 'M' when 2 then 'Q' when 11 then 'A' else cast(datediff(month,PaymentPeriodStart, PaymentPeriodEnd) as varchar) end as FileType
	, case RIGHT(ReportName,1) when 'A' then 'SCO' when 'B' then 'ICO' else RIGHT(ReportName,1) end AS Product
	, case datediff(month,PaymentPeriodStart, PaymentPeriodEnd) when 0 then PaymentPeriodStart else DATEADD(DAY,1,PaymentPeriodEnd) end AS ReportMonth
	, PaymentPeriodStart
	, PaymentPeriodEnd
	, CapitationMonthYear
from PDRIN.dbo.MMIS8200MDetail
where CapitationMonthYear between '2018-01-01' and '2018-12-01'
order by FileType, Product, ReportMonth, CapitationMonthYear

-- , CapitationMonthYear 

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[MMISFileProcessing]    Script Date: 09/04/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/04/2019
-- Description:	Table for tracking MMIS files processed

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MMISFileProcessing]') AND type in (N'U'))
	DROP TABLE [dbo].[MMISFileProcessing]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MMISFileProcessing]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MMISFileProcessing](

	-- sample table definition
	MMISFileProcessID     int IDENTITY(1,1) NOT NULL

	, ReportName          char(21)     not null
	, Product             char(3)      not null
	, ReportType          char(1)      not null -- Monthly, Quarterly, Annually
	, ReportMonth         date         not null -- month downloaded, will help identify gaps
	, PaymentPeriodStart  date         not null
	, PaymentPeriodEnd	  date         not null
	, ReportRowCount      int          not null
	, ProcessIndicator    char(1)      not null -- Y - already processed - ignore; N - first time process; R - marked for reprocessing
	, IdentifiedDate      datetime2(3) not null
	, ProcessedDate       datetime2(3) null

	
	, CONSTRAINT [PK_MMISFileProcessing] PRIMARY KEY 
	(
		MMISFileProcessID ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	-- unsure if there is a viable unique constraint at this time
	, CONSTRAINT [UQ_MMISFileProcessing] UNIQUE
	(
		  ReportType          
		, Product
		, ReportMonth         
		, PaymentPeriodStart  
		, PaymentPeriodEnd	  
	)

) -- ON [PRIMARY]
END
GO



SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[MMISFileProcessing] TO [Talend] 
GRANT SELECT ON [dbo].[MMISFileProcessing] TO [Support] 
GO
-- *****************************************************************************************************
