
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[MonthlyCloseRecord]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[MonthlyCloseRecord]    Script Date: 08/16/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/16/2019
-- Description:	Table for storing processed monthly summary record.
				Confirms revenue reconciliation complete for the month.
				Ultimately required for month end processing.
				Should be tied to monthly close process record summary (1 line per close event).
				A View will be used to export this data from RevRec and import into the month end process.

-- Modified by: Jonathan Lewis
-- Modified dt: 10/31/2019
-- Description: ADS-2937
				Adjusted Columns to have NULL values
				Added raw column values

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseRecord]') AND type in (N'U'))
	DROP TABLE [dbo].[MonthlyCloseRecord]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseRecord]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MonthlyCloseRecord](
	-- Columns for View

	  MonthlyCloseRecordID int identity(1,1) NOT NULL 
	, MonthlyCloseHeaderID int NOT NULL

	-- MonthlySummaryRecord Columns
	, MasterPatientID int NOT NULL -- makes up unique key
	, MMIS_ID char(12) NULL -- included for ease of reference... may be redundant with MasterPatientID
	, MemberMonth date NOT NULL	   -- makes up unique key; aligns to CapitationMonthYear

	, Variance numeric(18, 2) NULL -- compared to expected CCA payment: PaidCapitationAmount - CCANetAmount
	
	-- Payment error SHOULD NOT be part of the variance calculation
	, PaymentError numeric(18, 2) NULL -- compared to expected amount based on state details, like "unexplained" in original: PaidCapitationAmount - MMISNetAmount

	-- from PatientPayDetail... what the state actually says they paid, based on file
	, BaseCapitationAmount	numeric(18,2) NULL
	, PatientPayAmountN		numeric(18,2) NULL -- aligns to Patient Pay
	, PatientPayAmountSCO	numeric(18,2) NULL -- aligns to Patient Spend Down
	, PaidCapitationAmount	numeric(18,2) NULL -- total_paid
	, Remit                 numeric(18,2) NULL -- total remit

	, CCARateCellID int NULL
	, CCARegionID int NULL
	, CCAPatientPay numeric(18,2) NULL
	, CCAPatientSpendDown numeric (18,2) NULL

	-- CCA's expected based on current member's rate cell and region in MP
	, CCARateCardID int NULL
	, CCAAmount numeric(18,2) NULL -- from the rate card
	, CCANetAmount numeric(18,2) NULL -- minus patient pay and spend down
		
	, MMISRateCellID int  NULL
	, MMISRegionID int NULL
	, MMISPatientPay numeric(18,2) NULL
	, MMISPatientSpendDown numeric (18,2) NULL
	
	-- expected payment based on state's rate rate cell and region
	, MMISRateCardID int NULL
	, MMISAmount numeric(18,2) NULL -- expect it to align with base captiation amount
	, MMISNetAmount numeric(18,2) NULL -- minus patient pay and spend down

	-- ADS-2937
	, rawMMISRateCell char(4) NULL
	, rawMMISRegion char(5) NULL
	, rawCCARateCell varchar(50) NULL
	, rawCCARegion varchar(50) NULL

	

	, CONSTRAINT [PK_MonthlyCloseRecord] PRIMARY KEY 
	(
		MonthlyCloseRecordID ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
/*
	, CONSTRAINT [UQ_MonthlyCloseRecord] UNIQUE
	(
		[colName] ASC
	)
*/
) -- ON [PRIMARY]
END
GO


IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseRecord]') AND name = 'BaseCapitationAmount'	) ALTER TABLE [dbo].[MonthlyCloseRecord] ADD BaseCapitationAmount	numeric(18,2) NULL ELSE ALTER TABLE [dbo].[MonthlyCloseRecord]  ALTER COLUMN BaseCapitationAmount	numeric(18,2) NULL
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseRecord]') AND name = 'PatientPayAmountN'		) ALTER TABLE [dbo].[MonthlyCloseRecord] ADD PatientPayAmountN	numeric(18,2) NULL ELSE ALTER TABLE [dbo].[MonthlyCloseRecord]  ALTER COLUMN PatientPayAmountN		numeric(18,2) NULL
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseRecord]') AND name = 'PatientPayAmountSCO'	) ALTER TABLE [dbo].[MonthlyCloseRecord] ADD PatientPayAmountSCO	numeric(18,2) NULL ELSE ALTER TABLE [dbo].[MonthlyCloseRecord]  ALTER COLUMN PatientPayAmountSCO	numeric(18,2) NULL
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseRecord]') AND name = 'PaidCapitationAmount'	) ALTER TABLE [dbo].[MonthlyCloseRecord] ADD PaidCapitationAmount	numeric(18,2) NULL ELSE ALTER TABLE [dbo].[MonthlyCloseRecord]  ALTER COLUMN PaidCapitationAmount	numeric(18,2) NULL
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseRecord]') AND name = 'Remit'                  ) ALTER TABLE [dbo].[MonthlyCloseRecord] ADD Remit                numeric(18,2) NULL ELSE ALTER TABLE [dbo].[MonthlyCloseRecord]  ALTER COLUMN Remit					numeric(18,2) NULL


IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseRecord]') AND name = 'rawMMISRateCell ') ALTER TABLE [dbo].[MonthlyCloseRecord] ADD rawMMISRateCell char(4) NULL     ELSE ALTER TABLE [dbo].[MonthlyCloseRecord] ALTER COLUMN rawMMISRateCell char(4) NULL
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseRecord]') AND name = 'rawMMISRegion   ') ALTER TABLE [dbo].[MonthlyCloseRecord] ADD rawMMISRegion	  char(5) NULL     ELSE ALTER TABLE [dbo].[MonthlyCloseRecord] ALTER COLUMN rawMMISRegion	  char(5) NULL
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseRecord]') AND name = 'rawCCARateCell  ') ALTER TABLE [dbo].[MonthlyCloseRecord] ADD rawCCARateCell  varchar(50) NULL ELSE ALTER TABLE [dbo].[MonthlyCloseRecord] ALTER COLUMN rawCCARateCell  varchar(50) NULL
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseRecord]') AND name = 'rawCCARegion    ') ALTER TABLE [dbo].[MonthlyCloseRecord] ADD rawCCARegion    varchar(50) NULL ELSE ALTER TABLE [dbo].[MonthlyCloseRecord] ALTER COLUMN rawCCARegion    varchar(50) NULL

-- IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[MonthlyCloseRecord]') AND name = 'colName') ALTER TABLE [tblSchema].[tblName] DROP COLUMN [colName] 





SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[MonthlyCloseRecord] TO [Talend] 
GRANT SELECT ON [dbo].[MonthlyCloseRecord] TO [Support] 
GO
-- *****************************************************************************************************
