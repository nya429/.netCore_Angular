
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[CCAMemberSpanEnrollment]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[CCAMemberSpanEnrollment]    Script Date: 08/20/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/20/2019
-- Description:	For storing member enrollment spans 
				Should join back to CCAMemberData

-- Modified by: Jonathan Lewis
-- Modified dt: 01/08/2020
-- Description: ADS-2980/ADS-2915
				Will add ActiveFlag, Insert and Update dates to the member data imported.
				These will then be managed by the validation routine.
				Will also have to update the expected payment process to consider the active flags from these tables.

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/


-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CCAMemberSpanEnrollment]') AND type in (N'U'))
	DROP TABLE [dbo].[CCAMemberSpanEnrollment]
-- *****************************************************************************************************

-- remove second if not exists statement if dropping the table in the statement above.
-- IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CCAMemberSpanEnrollment]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CCAMemberSpanEnrollment](

	-- sample table definition
	  CCAMemberSpanEnrollID int IDENTITY(1,1) NOT NULL
	, CCAID bigint NULL
 	, Product char(3) NULL
 	, EnrollStartDate date NULL
 	, EnrollEndDate date NULL

	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 

	
	, CONSTRAINT [PK_CCAMemberSpanEnrollment] PRIMARY KEY 
	(
		CCAMemberSpanEnrollID ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
/*
	, CONSTRAINT [UQ_CCAMemberSpanEnrollment] UNIQUE
	(
		[colName] ASC
	)
*/
) -- ON [PRIMARY]
END
GO



SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[CCAMemberSpanEnrollment] TO [Talend] 
GRANT SELECT ON [dbo].[CCAMemberSpanEnrollment] TO [Support] 
GO
-- *****************************************************************************************************
