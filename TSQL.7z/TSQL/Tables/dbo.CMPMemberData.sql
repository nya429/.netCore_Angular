
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[CMPMemberData]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[CMPMemberData]    Script Date: 11/22/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 11/22/2019
-- Description:	ADS-3000
				Table for storing Guiding Care (CMP) sourced data
				Will be used for comparison to other sources to reduce research effort on end user team

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CMPMemberData]') AND type in (N'U'))
	DROP TABLE [dbo].[CMPMemberData]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CMPMemberData]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CMPMemberData](
	-- sample table definition
	  CMPMemberDataID    [int] IDENTITY(1,1) NOT NULL
	, CCAID BIGINT NOT NULL

	-- , CMPRateCell varchar(50) NULL -- this may not be relevant. may remove this column altogether.

	, CMPMDSAssessmentType varchar(500) NULL -- source: Altruista.dbo.ELIGIBILITY_TYPE.ELIGIBILITY_TYPE nvarchar(500)
	, CMPMDSAssessment varchar(50) NOT NULL -- this will be version from Altruista
	, AssessmentStartDate date NOT NULL
	, AssessmentEndDate date NULL -- 12 months from start date...

	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 

	 

	
	, CONSTRAINT [PK_CMPMemberData] PRIMARY KEY 
	(
		CMPMemberDataID
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
/*
	, CONSTRAINT [UQ_CMPMemberData] UNIQUE
	(
		[colName] ASC
	)
*/
) -- ON [PRIMARY]
END
GO

SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[CMPMemberData] TO [Talend] 
GRANT SELECT ON [dbo].[CMPMemberData] TO [Support] 
GO
-- *****************************************************************************************************
