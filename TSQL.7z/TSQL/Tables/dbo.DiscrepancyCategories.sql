
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[DiscrepancyCategories]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[DiscrepancyCategories]    Script Date: 08/09/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/09/2019
-- Description:	Categories for organizing statuses used with discrepancies

				Post Unit Test - 09/27/2019
					Added column to confirm a category could have statuses added to it.
					Also should be used when a status is system used and not selectable.


-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DiscrepancyCategories]') AND type in (N'U'))
	DROP TABLE [dbo].[DiscrepancyCategories]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DiscrepancyCategories]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DiscrepancyCategories](
	  DiscrepancyCategoryID int identity(1,1) NOT NULL
	, DiscrepancyCategory varchar(50) NOT NULL
	, DiscrepancyCategoryDescription varchar(1000) NULL
	, DiscrepancyCategoryDisplay bit NOT NULL -- 0 = not displayed by default in front end; 1 = always display in front end
	, DiscrepancyCategoryAddStatus bit NOT NULL -- varchar(20) NULL -- 0 = cannot add Status; 1 = can add a status under this category
	
	, ActiveFlag bit NOT NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 

	
	, CONSTRAINT [PK_DiscrepancyCategories] PRIMARY KEY 
	(
		DiscrepancyCategoryID ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	, CONSTRAINT [UQ_DiscrepancyCategories] UNIQUE
	(
		DiscrepancyCategory ASC
	)

) -- ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[DiscrepancyCategories]') AND name = 'DiscrepancyCategoryAddStatus') ALTER TABLE [dbo].[DiscrepancyCategories] ADD DiscrepancyCategoryAddStatus bit NOT NULL default (1) ELSE ALTER TABLE [dbo].[DiscrepancyCategories] ALTER COLUMN DiscrepancyCategoryAddStatus bit NOT NULL 
	


SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[DiscrepancyCategories] TO [Talend] 
GRANT SELECT ON [dbo].[DiscrepancyCategories] TO [Support] 
GO
-- *****************************************************************************************************
