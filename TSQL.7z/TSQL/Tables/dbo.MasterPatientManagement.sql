
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[MasterPatientManagement]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[MasterPatientManagement]    Script Date: 10/03/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 10/03/2019
-- Description:	Table for "source agnostic" management of master patient IDs
				A hierarchy will be employeed when a "higher" source has data avaialable to overwrite a previous "lower" source.
					i.e. - When a member finally shows in the Mass Health data, it can overwrite the data previously stored as an MP source
							However, an MP source that has data cannot overwrite when data already exists from Mass Health

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MasterPatientManagement]') AND type in (N'U'))
	DROP TABLE [dbo].[MasterPatientManagement]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MasterPatientManagement]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MasterPatientManagement](

	-- sample table definition
	  MasterPatientID    int IDENTITY(1,1) NOT NULL
 	, MMIS_ID char(12) NULL
	, CCAID bigint NULL 
	, SourceSystem varchar(50) NOT NULL

 	, MemberFirstName varchar(20) NULL
 	, MemberMiddleName varchar(20) NULL
 	, MemberLastName varchar(30) NULL
 	, Suffix varchar(19) NULL

	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 

	
	, CONSTRAINT [PK_MasterPatientManagement] PRIMARY KEY 
	(
		MasterPatientID ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
/*
	, CONSTRAINT [UQ_MasterPatientManagement] UNIQUE
	(
		[colName] ASC -- possible third column that holds "hierarchical" value from the other two
	)
*/
) -- ON [PRIMARY]
END
GO



	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MasterPatientManagement]') AND name = N'IDX_MasterPatientManagement_CCAID')
		CREATE NONCLUSTERED INDEX [IDX_MasterPatientManagement_CCAID] ON [dbo].[MasterPatientManagement]
		(
			CCAID
		) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MasterPatientManagement]') AND name = N'IDX_MasterPatientManagement_MMIS_ID')
		CREATE NONCLUSTERED INDEX [IDX_MasterPatientManagement_MMIS_ID] ON [dbo].[MasterPatientManagement]
		(
			MMIS_ID
		) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]



SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[MasterPatientManagement] TO [Talend] 
GRANT SELECT ON [dbo].[MasterPatientManagement] TO [Support] 
GO
-- *****************************************************************************************************
