
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[UserEventLog]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[UserEventLog]    Script Date: 08/13/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/13/2019
-- Description:	Stores a RevRec activity event (such as change to a rating category or adding a new discrepancy status).  
				JSON will be used to store the change details, both before (if any) and after.

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserEventLog]') AND type in (N'U'))
	DROP TABLE [dbo].[UserEventLog]
-- *****************************************************************************************************
*/

-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserEventLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserEventLog](
	-- sample table definition
	  EventID   int IDENTITY(1,1) NOT NULL
	, UserID    int  NOT NULL
	, EventName varchar(255) NOT NULL
	, EventDateTime datetime2(3) NOT NULL
	, EventReturnCode int NULL
	, EventOldData nvarchar(1000) NULL -- XML vs JSON... nvarchar?
	, EventNewData nvarchar(1000) NULL -- XML vs JSON... nvarchar?
	
	, CONSTRAINT [PK_UserEventLog] PRIMARY KEY 
	(
		EventID
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
/*
	-- research/review needed for unique key
	, CONSTRAINT [UQ_UserEventLog] UNIQUE
	(
		[colName] ASC
	)
*/
) -- ON [PRIMARY]
END
GO




SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[UserEventLog] TO [Talend] 
GRANT SELECT ON [dbo].[UserEventLog] TO [Support] 
GO
-- *****************************************************************************************************
