
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[PaymentDetailRemit]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[PaymentDetailRemit]    Script Date: 09/23/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/23/2019
-- Description:	Table for storing calculated remit (actual amounts contributing to CCA check payment).

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PaymentDetailRemit]') AND type in (N'U'))
	DROP TABLE [dbo].[PaymentDetailRemit]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PaymentDetailRemit]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PaymentDetailRemit](

	-- sample table definition
	PaymentDetailRemitID int IDENTITY(1,1) NOT NULL
	, MMISFileProcessID int NOT NULL


	-- columns below matched in MMISFileProcessing
	-- , ReportName char(21) NOT NULL
	-- , Product char(3) NOT NULL
	-- , ReportType varchar(1) NOT NULL
	-- , ReportMonth datetime NOT NULL
	-- , PaymentPeriodStart datetime NOT NULL
	-- , PaymentPeriodEnd datetime NOT NULL

	, MemberID char(12) NOT NULL
	, EffectiveDate datetime NULL
	, EndDate datetime NULL
	, CapitationMonthYear datetime NOT NULL
	, RateCell char(4) NULL
	, MCRegion char(5) NULL
	, BaseCapitationAmount numeric(18,2) NULL
	-- , sumPatientPayAmountN   numeric(18,2) NULL
	-- , sumPatientPayAmountSCO	numeric(18,2) NULL
	-- , Paid numeric(18,2) NULL -- sumPaidCapitationAmount 
	, Remit numeric(18,2) NULL -- final amount to be computed
	
	-- used for determining payment vs adjustment
	, CountPayCode		  int NOT NULL 
	, CountRetractionCode int NOT NULL 
	, PaymentIndicator int NOT NULL 

	-- windowed columns for referenced and troubleshooting
	, lag_Paid                         numeric(18,2) NULL
	, lag_PaymentIndicator			   INT NULL
	, rn_LatestMemberMonthProcessed	   INT NULL
	, drk_LatestMemberMonthProcessed   INT NULL

	-- , ActiveFlag bit NULL
	, insertDate datetime2(3) NOT NULL 
	, updateDate datetime2(3) NOT NULL -- this may get used in a reprocessing effort	

	, CONSTRAINT [PK_PaymentDetailRemit] PRIMARY KEY 
	(
		PaymentDetailRemitID
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
/*
	, CONSTRAINT [UQ_PaymentDetailRemit] UNIQUE
	(
		[colName] ASC
	)
*/
) -- ON [PRIMARY]
END
GO



/*
-- ************************************************************************************
	-- other samples to include
	-- sample key
-- ************************************************************************************
*/

SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[PaymentDetailRemit] TO [Talend] 
GRANT SELECT ON [dbo].[PaymentDetailRemit] TO [Support] 
GO
-- *****************************************************************************************************
