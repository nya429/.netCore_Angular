
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[MMISRegions]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[MMISRegions]    Script Date: 07/08/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/08/2019
-- Description:	Source table for storing MMIS regions

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MMISRegions]') AND type in (N'U'))
	DROP TABLE [dbo].[MMISRegions]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MMISRegions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MMISRegions](
	-- sample table definition
	MMISRegionID    [int] IDENTITY(1,1) NOT NULL
	, MMISRegion  varchar(50)  NULL
	, Product    char(3) NULL
	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 
	-- , [defCol]    [bit]               NOT NULL CONSTRAINT DF_MMISRegions_defCol DEFAULT 0


	, CONSTRAINT [PK_MMISRegions] PRIMARY KEY 
	(
		MMISRegionID ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	, CONSTRAINT [UQ_MMISRegions] UNIQUE
	(
		MMISRegion 
		, Product  
	)

) -- ON [PRIMARY]
END
GO


SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[MMISRegions] TO [Talend] 
GRANT SELECT ON [dbo].[MMISRegions] TO [Support] 
GO
-- *****************************************************************************************************
