
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[PaymentDetail]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[PaymentDetail]    Script Date: 10/09/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 10/09/2019
-- Description:	Table for staging latest PaymentDetail.  Will need to be added to daily refresh for RateCard consistency

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

/*
-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PaymentDetail]') AND type in (N'U'))
	DROP TABLE [dbo].[PaymentDetail]
-- *****************************************************************************************************
*/
-- remove second if not exists statement if dropping the table in the statement above.
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PaymentDetail]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PaymentDetail](

	PaymentDetailID int identity(1,1)
	, Product char(3) NOT NULL
	, ReportType char(1) NOT NULL
	, ReportMonth date NOT NULL
	, MemberID char(12) NOT NULL
	, CapitationMonthYear datetime NOT NULL
	, RateCell char(4) NULL
	, MCRegion char(5) NULL
	, BaseCapitationAmount numeric(18,2) NULL
	, Paid numeric(18,2) NULL
	, PatientPay numeric(18,2) NOT NULL
	, SpendDown numeric(18,2) NULL
	, Remit numeric(18,2) NULL
	, RateCardID int NULL
	, CCARateCell varchar(50) NULL
	, CCARateCellID int NULL
	, CCARegion varchar(50) NULL
	, CCARegionID int NULL
	, StartDate date NULL
	, EndDate date NULL
	, Amount numeric(18,2) NULL
	, ActiveFlag bit NULL
	, rnCurrentPaidAmount bigint NULL
	
	, CONSTRAINT [PK_PaymentDetail] PRIMARY KEY 
	(
		PaymentDetailID
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	, CONSTRAINT [UQ_PaymentDetail] UNIQUE
	(
		MemberID 
		, CapitationMonthYear 
	)

) -- ON [PRIMARY]
END
GO



/*
-- ************************************************************************************
-- sample table alter/add/drop statements

	IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[PaymentDetail]') AND name = 'colName') ALTER TABLE [dbo].[PaymentDetail] ADD [colName] [colType](colLen,colPrecision) NULL ELSE ALTER TABLE [dbo].[PaymentDetail] ALTER COLUMN [colName] [colType](colLen,colPrecision) NULL
	IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[PaymentDetail]') AND name = 'colName') ALTER TABLE [dbo].[PaymentDetail] DROP COLUMN [colName] 
-- ************************************************************************************
*/


/*
-- ************************************************************************************
-- Indexing Sample:

	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PaymentDetail]') AND name = N'IDX_PaymentDetail')
		DROP INDEX [IDX_PaymentDetail] ON [dbo].[PaymentDetail] WITH ( ONLINE = OFF )
	GO

	-- CLUSTERED: 
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PaymentDetail]') AND name = N'CIX_PaymentDetail')
		CREATE CLUSTERED INDEX [CIX_PaymentDetail] ON [dbo].[PaymentDetail]
		(
			[colName] ASC
		) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	GO

	-- OR: NONCLUSTERED
	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PaymentDetail]') AND name = N'IDX_PaymentDetail')
		CREATE NONCLUSTERED INDEX [IDX_PaymentDetail] ON [dbo].[PaymentDetail]
		(
			[colName] ASC
		) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	GO

-- ************************************************************************************
*/


/*
-- ************************************************************************************
-- sample constraints

	IF EXISTS (SELECT * FROM SYS.SYSCONSTRAINTS WHERE OBJECT_NAME(CONSTID) = 'CK_uniqueConstraintName')
		ALTER TABLE  [dbo].[PaymentDetail] DROP CONSTRAINT [CK_uniqueConstraintName] 
	GO

	ALTER TABLE  [dbo].[PaymentDetail] 
	ADD CONSTRAINT [CK_uniqueConstraintName] UNIQUE
	(
		[colName] ASC
	)
	GO
-- ************************************************************************************
*/

/*
-- ************************************************************************************
	-- other samples to include
	-- sample key
-- ************************************************************************************
*/

SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[PaymentDetail] TO [Talend] 
GRANT SELECT ON [dbo].[PaymentDetail] TO [Support] 
GO
-- *****************************************************************************************************
