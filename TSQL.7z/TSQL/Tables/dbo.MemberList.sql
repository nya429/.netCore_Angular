
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[MemberList]

-- *****************************************************************************************************
*/


/****** Object:  Table [dbo].[MemberList]    Script Date: 09/16/2019 00:00:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/16/2019
-- Description:	Table for storing processed member list for API retrieval
				Will included in daily process

-- Modified by: 
-- Modified dt: 
-- Description: 

-- See CCA Development Standards at: http://commonground.commonwealthcare.org/departments/IT/itpmo/SitePages/Home.aspx

						Inherent indexing
							Primary Key (clustered) - for joining
							Unique Constraint - for natural keys
-- *****************************************************************************************************
*/

-- *****************************************************************************************************
-- Only drop if a routinely truncated table or other "droppable" table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MemberList]') AND type in (N'U'))
	DROP TABLE [dbo].[MemberList]
-- *****************************************************************************************************

-- remove second if not exists statement if dropping the table in the statement above.
-- IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MemberList]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MemberList](
	-- sample table definition
	  MemberListID int IDENTITY(1,1) NOT NULL
	, MasterPatientID int NOT NULL
	, MemberFirstName varchar(20) NULL
	, MemberMiddleName varchar(20) NULL
	, MemberLastName varchar(30) NULL
	, MMIS_MMIS_ID char(12) NULL
	, CCAID bigint NULL
	, Product char(3) NULL
	, EnrollStartDate date NULL
	, EnrollEndDate date NULL
	, DOB date NULL
	, DOD int NULL
	, RatingCategory varchar(50) NULL
	, Region varchar(50) NULL
	, MemberEnrollmentStatus varchar(50) NOT NULL
	, TotalDiscrepancies int NULL
	, maxAging int NULL
	, absoluteVarianceSum numeric(18,2) NULL

	, CONSTRAINT [PK_MemberList] PRIMARY KEY 
	(
		MemberListID  ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
/*
	, CONSTRAINT [UQ_MemberList] UNIQUE
	(
		[colName] ASC
	)
*/
) -- ON [PRIMARY]
END
GO




SET ANSI_PADDING OFF
GO

-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[MemberList] TO [Talend] 
GRANT SELECT ON [dbo].[MemberList] TO [Support] 
GO
-- *****************************************************************************************************
