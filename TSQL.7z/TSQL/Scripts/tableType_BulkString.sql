USE RevRec
	
	if not exists (SELECT SCHEMA_NAME(SCHEMA_ID), OBJECT_NAME(system_type_id), * FROM SYS.types WHERE name = 'BulkString' and SCHEMA_NAME(SCHEMA_ID) = 'dbo')
		-- DROP TYPE dbo.BulkString
		CREATE TYPE dbo.BulkString AS TABLE (
			UpdateString varchar(50) NOT NULL 
		)
	GO  
	
	-- declare as (replace @Bulk with your variable name), @Bulk dbo.BulkString readonly

	grant view definition on type::dbo.BulkString to webapp
	grant execute on type::dbo.BulkString to webapp
