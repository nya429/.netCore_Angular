use RevRec

-- SELECT * FROM pm.ObjectManagement where objectname like '%spProcessMemberMap%'

if object_id('tempdb..#newObjectmanagement') is not null
	drop table #newObjectmanagement

create table #newObjectmanagement (
	ObjectType		varchar(100) NULL
	, ObjectName		varchar(100) NULL
)

insert into #newObjectmanagement (
	ObjectType
	, ObjectName
)
values 
 ('SCRIPTS','CompareObjectManagement.sql')
,('SCRIPTS','GrantPermissions.sql')
,('SCRIPTS','InsertObjectManagement.sql')
,('SCRIPTS','preLoad_DiscrepancyCategories.sql')
,('SCRIPTS','preLoad_DiscrepancyStatuses.sql')
,('SCRIPTS','preLoad_listParameters.sql')
,('SCRIPTS','preLoad_MemberMap.sql')
,('SCRIPTS','preLoad_RateCard.sql')
,('SCRIPTS','preLoad_RateCellMap.sql')
,('SCRIPTS','preLoad_RegionMap.sql')
,('SCRIPTS','preLoad_spProcessCCARateCells.sql')
,('SCRIPTS','preLoad_spProcessCCARegions.sql')
,('SCRIPTS','preLoad_UserRoleMap.sql')
,('SCRIPTS','preLoad_UserRoles.sql')
,('SCRIPTS','preLoad_Users.sql')
,('SCRIPTS','tableType_BulkDate.sql')
,('SCRIPTS','tableType_BulkID.sql')
,('SCRIPTS','tableType_BulkString.sql')
,('SCRIPTS','UpdateObjectManagement.sql')
,('SCRIPTS','preLoad_RatingCategoryLegacy.sql')
,('SCRIPTS','preLoad_ProcessMonthlyFiles.sql')
,('ETL','J_RevRec_Import_CCAMember')
,('ETL','SJ_RevRec_Import_CCAMemberData')
,('ETL','SJ_RevRec_Import_CCAMemberSpanEnrollment')
,('ETL','SJ_RevRec_Import_CCAMemberSpanPatientPay')
,('ETL','SJ_RevRec_Import_CCAMemberSpanPatientSpendDown')
,('ETL','SJ_RevRec_Import_CCAMemberSpanRatingCategory')
,('ETL','SJ_RevRec_Import_CCAMemberSpanRegion')
,('ETL','J_RevRec_Import_RateCard')
,('ETL','J_RevRec_Process_Daily')





insert into pm.Objectmanagement (
	ObjectType
	, ObjectName
)
select 
	ObjectType
	, ObjectName
from #newObjectmanagement as n
where not exists (
	select 
		ObjectType
		, ObjectName
	from pm.ObjectManagement as o
	where o.ObjectName = n.ObjectName
)
