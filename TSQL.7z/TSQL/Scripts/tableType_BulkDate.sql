USE RevRec

	if not exists (SELECT SCHEMA_NAME(SCHEMA_ID), OBJECT_NAME(system_type_id), * FROM SYS.types WHERE name = 'BulkDate' and SCHEMA_NAME(SCHEMA_ID) = 'dbo')
		-- DROP TYPE dbo.BulkDate
		CREATE TYPE dbo.BulkDate AS TABLE (
			UpdateDate datetime2(3) NOT NULL 
		)
	GO  
	
	-- declare as (replace @Bulk with your variable name), @Bulk dbo.BulkDate readonly
	grant view definition on type::dbo.BulkDate   to webapp 
	grant execute on type::dbo.BulkDate   to webapp 
