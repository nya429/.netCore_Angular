USE [RevRec]
GO

/*
	-- clear for re-import
	-- EXEC spTrun_UserRoles
	truncate table userroles

	-- validate pre/post import
	SELECT * FROM userroles
*/	

DECLARE @spStart datetime2(3) = getdate()

if (select UserRole from UserRoles where UserRole = 'Administrator') is null

	insert into UserRoles (
		  UserRole 
		, UserRoleDescription 
		, ActiveFlag
		, insertDate
		, updateDate
	)
	values ('Administrator'
		, 'Full access: Create/edit users; Create/run reports; Edit Discrepancy List; Correct errors; Control processing'
		, 1 , @spStart , @spStart 
	)
	
if (select UserRole from UserRoles where UserRole = 'Helpdesk') is null

	insert into UserRoles (
		  UserRole 
		, UserRoleDescription 
		, ActiveFlag
		, insertDate
		, updateDate
	)
	values ('Helpdesk'
		,'Create/edit users; Read Only; Run Reports'
		, 1 , @spStart , @spStart 
	)

if (select UserRole from UserRoles where UserRole = 'Supervisor') is null

	insert into UserRoles (
		  UserRole 
		, UserRoleDescription 
		, ActiveFlag
		, insertDate
		, updateDate
	)
	values ('Supervisor'
		, 'Create/edit users; Create/run reports; Edit Discrepancy List; Correct errors; Control processing'
		, 1 , @spStart , @spStart 
	)

if (select UserRole from UserRoles where UserRole = 'Specialist') is null

	insert into UserRoles (
		  UserRole 
		, UserRoleDescription 
		, ActiveFlag
		, insertDate
		, updateDate
	)
	values ('Specialist'
		, 'Edit Discrepancy List; Run reports; Correct errors'
		, 1 , @spStart , @spStart 
	)
		
			
