use revrec

IF NOT EXISTS (SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE (TABLE_NAME) = 'DiscrepancyCategories'
        AND (COLUMN_NAME) = 'DiscrepancyCategoryIsResolved')
BEGIN
   ALTER TABLE [RevRec].[dbo].[DiscrepancyCategories]
   ADD  DiscrepancyCategoryIsResolved bit;
END
GO


UPDATE [RevRec].[dbo].[DiscrepancyCategories] 
SET DiscrepancyCategoryIsResolved = 
CASE LOWER(DiscrepancyCategory)
	WHEN  'resolved' THEN 1 
	ELSE  0 
END
GO


