
USE [RevRec]
GO

DECLARE @spStart datetime2(3) = getdate()
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Get Rate Cells from View, store only if they do not exist
	-- ******************************

	
	insert into CCARateCells (
		CCARateCell
		, Product
		, ActiveFlag
		, insertDate
		, updateDate
	)

	SELECT 
		CCARateCell
		, Product
		, 1 as ActiveFlag
		, @spStart as insertDate
		, @spStart as updateDate
	FROM (
		select -- dsrc.value as CCARatingCategory_FullValue, 
			case ds.VALUE when 'SCO' then LEFT(dsrc.value,3) when 'ICO' then dsrc.value else NULL end as CCARateCell
			, ds.VALUE as Product
			, count(*) as CountByRateCell
		from mpsnapshotprod.dbo.DATE_SPAN as dsrc
		inner join mpsnapshotprod.dbo.DATE_SPAN as ds 
			on ds.NAME_ID = dsrc.NAME_ID
			and dsrc.START_DATE between ds.START_DATE and isnull(ds.END_DATE, '2999-12-31')
		where   dsrc.CARD_TYPE = 'MCAID App'
			and dsrc.COLUMN_NAME = 'name_text14'
			and dsrc.VALUE <> '99'
			and ds.CARD_TYPE = 'MCAID App'
			and ds.COLUMN_NAME = 'name_text19'
			and ds.VALUE in ('SCO', 'ICO')
		group by 
			case ds.VALUE when 'SCO' then LEFT(dsrc.value,3) when 'ICO' then dsrc.value else NULL end -- CCARateCell
			, ds.VALUE 	
	) as v
	WHERE CCARateCell is not null
	and not exists (
		select CCARateCell
		FROM CCARateCells as t
		WHERE t.CCARateCell = v.CCARateCell
	)

	-- ******************************
	-- validation
		-- 09/15/2019 confirmed no trimming needed
	-- ******************************
	-- select * from CCARateCells

