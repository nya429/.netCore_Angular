USE [RevRec]
GO

/*
	-- clear for re-import
	-- EXEC spTrun_UserRoleMap
	truncate table UserRoleMap

	-- validate pre/post import
	SELECT * FROM UserRoleMap
	SELECT * FROM Users
	SELECT * FROM UserRoles


*/	

DECLARE @spStart datetime2(3) = getdate()

if OBJECT_ID('tempdb..#revrecUserRole') is not null
	drop table #revrecUserRole

-- IDs could change, converted to values?


create table #revrecUserRole (
-- 	  UserID int
-- 	, UserRoleID int
	  UserNameAD varchar(50)
	, UserRole varchar(50)
)

insert into #revrecUserRole (
	  UserNameAD 
	, UserRole 
)

values
 ('ysong'	   , 'Administrator')
,('jlewis'	   , 'Administrator')
,('nfrenette'  , 'Administrator')
,('randrade'   , 'Administrator')
,('lalvarez'   , 'Specialist')
,('aortiz'	   , 'Specialist')
,('jbresnahan' , 'Administrator') 
,('rrathore'   , 'Administrator') 
,('tpardeshi'  , 'Administrator') 
,('dboni'  , 'Administrator') 
,('adevarapall'  , 'Administrator') 



if OBJECT_ID('tempdb..#revrecUserRoleMap') is not null
	drop table #revrecUserRoleMap

-- IDs could change, converted to values?


create table #revrecUserRoleMap (
	  UserID int
	, UserRoleID int
)

insert into #revrecUserRoleMap (
	  UserID 
	, UserRoleID
)
select u.UserID, ur.UserRoleID 
from #revrecUserRole as r
inner join UserRoles as ur on ur.UserRole = r.userRole
inner join Users as u on u.UserNameAD = R.UserNameAD


insert into UserRoleMap (
	  UserID 
	, UserRoleID 
	, ActiveFlag
	, insertDate
	, updateDate
)
select 
	  rr.UserID 
	, rr.UserRoleID 
	, 1        as ActiveFlag
	, @spStart as insertDate
	, @spStart as updateDate
from #revrecUserRoleMap as rr
where not exists (
	select UserId
	from UserRoleMap as urm
	where urm.UserID = rr.UserID 
		and urm.UserRoleID = rr.UserRoleID 
		
	)

