USE [RevRec]
GO

/*
	-- clear for re-import
	-- EXEC spTrun_DiscrepancyStatus
	truncate table DiscrepancyStatus

	-- validate pre/post import
	SELECT * FROM DiscrepancyCategories
	select * FROM DiscrepancyStatuses

Categories for RevRec 2.0

DiscrepancyCategoryID	DiscrepancyCategory	DiscrepancyCategoryDescription
	New - must be reviewed
	Pending - in progress, and does not fall off list (was "working")
	Worked - waiting for system resolution, falls off discrepancy working list (was "Pending")
		Nick - go back to New
			Reopen - status name; New - status category
	Complete - discrepancy will remain, but no further action can be taking
	Resolved - discrepancy is corrected
	


Statuses from RevRec 1.0
	
		SELECT * FROM OPENQUERY(revrec, 'SELECT 
		  ds.id
		, ds.description
		, ds.category
		, ds.symbol
		, ds.category_symbol
		, ds.source_id
		, cast(ds.archived_at as char(20)) as archived_at
		, cast(ds.created_at as char(20)) as created_at
		, cast(ds.updated_at as char(20)) as updated_at
		, ds.retired
		, count(*) as CountByDiscrepancyStatus
		FROM discrepancy_statuses as ds
		inner join discrepancies as d on d.discrepancy_status_id = ds.id
		-- where ds.retired = 0 -- does not seem right?
		where d.updated_at > ''2019-07-01''
		group by
		  ds.id
		, ds.description
		, ds.category
		, ds.symbol
		, ds.category_symbol
		, ds.source_id
		, ds.archived_at
		, ds.created_at 
		, ds.updated_at 
		, ds.retired
		;')
		order by CountByDiscrepancyStatus desc

		description	| category
		-------------------------------------------------
		New	New
		Resolved	Completed
		Decision to Not Pursue	Completed
		Resolution expected from change to MP	Resolution Expected
		At Medicaid For Appeal	NULL
		Clinical Ops- Expired MDS	NULL
		Preparing appeal to Medicaid	Preparing Submission
		Contacting Member (Demographics Verification)	Contacting Member
		... all entries below are have less than 20 entries in revrec 1.0 since 7/1/2019
		No Active MDS	Preparing Submission
		At Medicaid for eligibility reinstatement	Submitted
		Resolution expected via Medicaid 820, Quarterly	Resolution Expected
		Appeal denied by Medicaid	Denied
		Ready for write-off by CCA	Queued for Action
		Contacting SNF (MMQ/Score Data Needed)	Contacting SNF
		Resolution expected via Medicaid 820, Annual	Resolution Expected
		At Medicaid for Appeal-Short Term SNF Stay	Submitted
		Written off	Completed
		Deceased-Prorated	NULL
		At Medicaid for appeal-Paid Tier; No LTC or Score	Submitted

	

*/	

DECLARE @spStart datetime2(3) = getdate()

if OBJECT_ID('tempdb..#revrecDiscrepancyStatus') is not null
	drop table #revrecDiscrepancyStatus

create table #revrecDiscrepancyStatus (
	  DiscrepancyStatus varchar(50) NOT NULL
	, DiscrepancyStatusDescription varchar(1000) NULL
	, DiscrepancyCategory varchar(50) NULL 
	-- , DiscrepancyCategoryID int -- varchar(20) NULL -- reporting category: i.e. new, resolved, completed... possibly will create another table for this and let the put procedure perform the insert/update to map appropriately
	, DiscrepancyStatusType bit -- varchar(20) NULL -- 0 = system maintenance; 1 = user entered
)

insert into #revrecDiscrepancyStatus (
	  DiscrepancyStatus 
	, DiscrepancyStatusDescription 
	, DiscrepancyCategory
	, DiscrepancyStatusType 
)
values
 ('New'                                              , '', 'New'      , 0)
,('Reopen'                                           , '', 'New'      , 0)
,('Pending'                                          , '', 'Pending'  , 0)
,('Worked'                                           , '', 'Worked'  , 0)
,('Complete'                                         , '', 'Complete' , 0)
,('Resolved'                                         , '', 'Resolved' , 0)
,('Decision to Not Pursue'                           , '', 'Complete' , 1)
,('Resolution expected from change to MP'            , '', 'Working'  , 1)
,('At Medicaid For Appeal'                           , '', 'Working'  , 1)
,('Clinical Ops- Expired MDS'                        , '', 'Complete' , 1)
,('Preparing appeal to Medicaid'                     , '', 'Pending'  , 1)
,('Contacting Member (Demographics Verification)'    , '', 'Pending'  , 1)
,('No Active MDS'                                    , '', 'Pending'  , 1)
,('At Medicaid for eligibility reinstatement'        , '', 'Working'  , 1)
,('Resolution expected via Medicaid 820, Quarterly'  , '', 'Working'  , 1)
,('Appeal denied by Medicaid'                        , '', 'Complete' , 1)
,('Ready for write-off by CCA'                       , '', 'Complete' , 1)
,('Contacting SNF (MMQ/Score Data Needed)'           , '', 'Pending'  , 1)
,('Resolution expected via Medicaid 820, Annual'     , '', 'Working'  , 1)
,('At Medicaid for Appeal-Short Term SNF Stay'       , '', 'Pending'  , 1)
,('Written off'                                      , '', 'Complete' , 1)
,('Deceased-Prorated'                                , '', 'Complete' , 1) -- or should this be resolved, because it would ultimately balance
,('At Medicaid for appeal-Paid Tier; No LTC or Score', '', 'Pending'  , 1)


insert into DiscrepancyStatuses (
	  DiscrepancyStatus 
	, DiscrepancyStatusDescription 
	, DiscrepancyCategoryID 
	, DiscrepancyStatusType 
	, ActiveFlag
	, insertDate
	, updateDate
)
select 
	  rr.DiscrepancyStatus 
	, rr.DiscrepancyStatusDescription 
	, dc.DiscrepancyCategoryID 
	, rr.DiscrepancyStatusType 
	, 1        as ActiveFlag
	, @spStart as insertDate
	, @spStart as updateDate
from #revrecDiscrepancyStatus as rr
inner join DiscrepancyCategories as dc on dc.DiscrepancyCategory = rr.DiscrepancyCategory
where not exists (
	select DiscrepancyStatusId
	from DiscrepancyStatuses as ds
	where ds.DiscrepancyStatus = rr.DiscrepancyStatus
	)
