USE [RevRec]
GO


/*
	09/15/2019 - added this to be part of the initial processing without need for special instructions/execution

	-- clear for re-import

	exec spTrun_MMISRegions
	select * from MMISRegions
*/


	exec spProcessMMISRegions



/*
	-- clear for re-import
	EXEC spTrun_RegionMap

	-- validate pre/post import
	SELECT * FROM RegionMap
	select * from vwRegionMap
*/	



-- what to do with state?

DECLARE @spStart datetime2(3) = getdate()

-- select * from vwCCARegions
-- select * from vwMMISRegions

	insert into RegionMap (
		  CCARegionID 
		, MMISRegionID
		, ActiveFlag
		, insertDate
		, updateDate
	)
	select 
		  CCARegionID 
		, MMISRegionID
		, ActiveFlag
		, insertDate
		, updateDate
	from (	
		select
			  CCARegionID 
			, MMISRegionID
			, 1 as ActiveFlag
			, @spStart as insertDate
			, @spStart as updateDate
		from CCARegions as c
		cross join MMISRegions as s
		where c.CCARegion = 'West'
		and s.MMISRegion IN (
			 'C011'
			,'C013'
			,'C015'
			,'C027'
		)
		UNION ALL 
		select
			  CCARegionID 
			, MMISRegionID
			, 1 as ActiveFlag
			, @spStart as insertDate
			, @spStart as updateDate
		from CCARegions as c
		cross join MMISRegions as s
		where c.CCARegion = 'Cape'
		and s.MMISRegion IN (
			 'C023A'
		)
		union all
		select
			  CCARegionID 
			, MMISRegionID
			, 1 as ActiveFlag
			, @spStart as insertDate
			, @spStart as updateDate
		from CCARegions as c
		cross join MMISRegions as s
		where c.CCARegion = 'East'
		and s.MMISRegion IN (
			 'C005'
			,'C009'
			,'C017'
			,'C021'
			,'C025'
		)
		union all
		select
			  CCARegionID 
			, MMISRegionID
			, 1 as ActiveFlag
			, @spStart as insertDate
			, @spStart as updateDate
		from CCARegions as c
		cross join MMISRegions as s
		where c.CCARegion = 'Bos'
		and s.MMISRegion IN (
			 'CINBN'
		)
		union all
		select
			  CCARegionID 
			, MMISRegionID
			, 1 as ActiveFlag
			, @spStart as insertDate
			, @spStart as updateDate
		from CCARegions as c
		cross join MMISRegions as s
		where c.CCARegion = 'Non'
		and s.MMISRegion IN (
			 'COTBN'
		)
	) as allRegions
	where not exists (
		select RegionMapID
		from RegionMap as m
		where m.MMISRegionID = allRegions.MMISRegionID
			and m.CCARegionID = allRegions.CCARegionID
	)

/*
	Post-QA: 09/12/2019
		altered column CCARegionID to be null
			This will allow the the map to contain all MMIS regions, awaiting a map to CCA region
			Will be compatible with the 1-to-many concept on the interface in the admin screen.
*/


INSERT INTO RegionMap(
	MMISRegionID	
	, ActiveFlag	
	, insertDate	
	, updateDate
)
SELECT
	  reg.MMISRegionID	
	, 0 AS ActiveFlag	
	, reg.insertDate	
	, reg.insertDate AS updateDate
FROM MMISRegions as reg
where not exists(
	select MMISRegionID	
	from RegionMap as m
	where reg.MMISRegionID = m.MMISRegionID
)
