

use revrec

IF NOT EXISTS (SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE (TABLE_NAME) = 'MemberList'
        AND (COLUMN_NAME) = 'MemberEnrollmentStatusId')
BEGIN
   Alter table dbo.MemberList
   add  MemberEnrollmentStatusId int ;
END
GO


update dbo.MemberList 
  set MemberEnrollmentStatusId = 
CASE MemberEnrollmentStatus
						WHEN  'Never enrolled' then 0 
						WHEN  'Currently enrolled' then 1
						WHEN  'Not currently enrolled' then 2
						ELSE  '' 
					END
;

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MemberList]') AND name = N'IDX1_MemberList')
		CREATE NONCLUSTERED INDEX [IDX1_MemberList] ON [dbo].[MemberList]
		(
			[MemberEnrollmentStatus] ASC
		) 
	GO


	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MemberList]') AND name = N'IDX2_MemberList')
		CREATE NONCLUSTERED INDEX [IDX2_MemberList] ON [dbo].[MemberList]
		(
			[MemberEnrollmentStatusId] ASC
		) 
	GO

	IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[discrepancies]') AND name = N'IDX2_discrepancies')
		CREATE NONCLUSTERED INDEX [IDX2_discrepancies] ON [dbo].[discrepancies]
		(
			[variance] ASC
		) 
	GO






