USE [RevRec]
GO


/*
	-- clear for re-import
	EXEC dbo.spTrun_RateCard

	-- validate pre/post import
	SELECT * FROM RateCard
	select * from vwRateCard
	
	-- REVIEW
	SELECT * FROM vwRegionMap
	SELECT * FROM vwRateCellMap 

	-- validation

		select CCARateCellID, CCARegionID, StartDate, EndDate, Amount, Eligibility, Product, ActiveFlag
		from RateCard where ActiveFlag = 1
		except
		select CCARateCellID, CCARegionID, StartDate, EndDate, Amount, Eligibility, Product, ActiveFlag
		from RateCardTEST



		select CCARateCellID, CCARegionID, StartDate, EndDate, Amount, Eligibility, Product, ActiveFlag
		from RateCardTEST
		except
		select CCARateCellID, CCARegionID, StartDate, EndDate, Amount, Eligibility, Product, ActiveFlag
		from RateCard




-- test
DROP TABLE [dbo].[RateCardTEST]
CREATE TABLE [dbo].[RateCardTEST](
	-- sample table definition
	RateCardID    int IDENTITY(1,1) NOT NULL
	, CCARateCellID       int       NULL
	, CCARegionID         int       NULL
	, StartDate           date      NULL 
	, EndDate             date      NULL 
	, Amount              numeric(18,2) NULL
	, RateCardLabel       varchar(20) NULL
	, Eligibility         char(1)   NULL -- Dual Status
	, Product             char(3) NULL

	, ActiveFlag bit NULL
	, insertDate datetime2(3)      NULL 
	, updateDate datetime2(3)      NULL 


	, CONSTRAINT [PK_RateCardTEST] PRIMARY KEY 
	(
		RateCardID ASC
	) -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	, CONSTRAINT [UQ_RateCardTEST] UNIQUE
	(
		  CCARateCellID       
		, CCARegionID         
		, StartDate           
		, EndDate  
	)
) -- ON [PRIMARY]

GO


*/	



DECLARE @spStart datetime2(3) = getdate()


if object_id('tempdb..#rateRegionAmounts') is not null
	drop table #rateRegionAmounts

create table #rateRegionAmounts (
	  Product     char(3)       NOT NULL
	, CCARateCell varchar(50)   NOT NULL
	, CCARegion   varchar(50)   NOT NULL
	, StartDate   date          NOT NULL 
	, EndDate     date          NOT NULL 
	, Amount      numeric(18,2) NOT NULL
)

INSERT INTO #rateRegionAmounts(
	  Product     
	, CCARateCell 
	, CCARegion   
	, StartDate   
	, EndDate     
	, Amount      
)
values 
 ('SCO','CAD','Bos','1/1/2019','6/30/2019',549.04 )
,('SCO','CAD','Bos','7/1/2019','12/31/2019',549.04 )
,('SCO','CAD','Non','1/1/2019','6/30/2019',548.62 )
,('SCO','CAD','Non','7/1/2019','12/31/2019',548.62 )
,('SCO','CAM','Bos','1/1/2019','6/30/2019',1615.02 )
,('SCO','CAM','Bos','7/1/2019','12/31/2019',1615.02 )
,('SCO','CAM','Non','1/1/2019','6/30/2019',1417.50 )
,('SCO','CAM','Non','7/1/2019','12/31/2019',1417.50 )
,('SCO','CND','Bos','1/1/2019','6/30/2019',2371.40 )
,('SCO','CND','Bos','7/1/2019','12/31/2019',2378.58 )
,('SCO','CND','Non','1/1/2019','6/30/2019',2671.68 )
,('SCO','CND','Non','7/1/2019','12/31/2019',2620.43 )
,('SCO','CNM','Bos','1/1/2019','6/30/2019',3648.28 )
,('SCO','CNM','Bos','7/1/2019','12/31/2019',3648.28 )
,('SCO','CNM','Non','1/1/2019','6/30/2019',3842.52 )
,('SCO','CNM','Non','7/1/2019','12/31/2019',3966.47 )
,('SCO','CWD','Bos','1/1/2019','6/30/2019',328.36 )
,('SCO','CWD','Bos','7/1/2019','12/31/2019',328.36 )
,('SCO','CWD','Non','1/1/2019','6/30/2019',368.61 )
,('SCO','CWD','Non','7/1/2019','12/31/2019',368.61 )
,('SCO','CWM','Bos','1/1/2019','6/30/2019',882.89 )
,('SCO','CWM','Bos','7/1/2019','12/31/2019',882.89 )
,('SCO','CWM','Non','1/1/2019','6/30/2019',869.65 )
,('SCO','CWM','Non','7/1/2019','12/31/2019',869.65 )
,('ICO','DC1','Cape','1/1/2019','12/31/2019',178.84 )
,('ICO','DC1','East','1/1/2019','12/31/2019',186.42 )
,('ICO','DC1','State','1/1/2019','12/31/2019',178.15 )
,('ICO','DC1','West','1/1/2019','12/31/2019',165.69 )
,('ICO','DC2A','Cape','1/1/2019','12/31/2019',653.42 )
,('ICO','DC2A','East','1/1/2019','12/31/2019',592.84 )
,('ICO','DC2A','State','1/1/2019','12/31/2019',562.18 )
,('ICO','DC2A','West','1/1/2019','12/31/2019',515.17 )
,('ICO','DC2B','Cape','1/1/2019','12/31/2019',984.34 )
,('ICO','DC2B','East','1/1/2019','12/31/2019',891.97 )
,('ICO','DC2B','State','1/1/2019','12/31/2019',842.29 )
,('ICO','DC2B','West','1/1/2019','12/31/2019',773.56 )
,('ICO','DC3A','Cape','1/1/2019','12/31/2019',3101.01 )
,('ICO','DC3A','East','1/1/2019','12/31/2019',2785.69 )
,('ICO','DC3A','State','1/1/2019','12/31/2019',2808.58 )
,('ICO','DC3A','West','1/1/2019','12/31/2019',2812.10 )
,('ICO','DC3B','Cape','1/1/2019','12/31/2019',7339.96 )
,('ICO','DC3B','East','1/1/2019','12/31/2019',6591.10 )
,('ICO','DC3B','State','1/1/2019','12/31/2019',6643.38 )
,('ICO','DC3B','West','1/1/2019','12/31/2019',6654.56 )
,('ICO','DC3C','Cape','1/1/2019','12/31/2019',6953.57 )
,('ICO','DC3C','East','1/1/2019','12/31/2019',8378.84 )
,('ICO','DC3C','State','1/1/2019','12/31/2019',8303.93 )
,('ICO','DC3C','West','1/1/2019','12/31/2019',8303.18 )
,('ICO','DF1','Cape','1/1/2019','12/31/2019',8248.75 )
,('ICO','DF1','East','1/1/2019','12/31/2019',9926.45 )
,('ICO','DF1','State','1/1/2019','12/31/2019',9625.64 )
,('ICO','DF1','West','1/1/2019','12/31/2019',9368.75 )
,('SCO','I1D','Statewide','1/1/2019','12/31/2019',4460.29 )
,('SCO','I1M','Statewide','1/1/2019','12/31/2019',4460.29 )
,('SCO','I2D','Statewide','1/1/2019','12/31/2019',6381.46 )
,('SCO','I2M','Statewide','1/1/2019','12/31/2019',6381.46 )
,('SCO','I3D','Statewide','1/1/2019','12/31/2019',8196.99 )
,('SCO','I3M','Statewide','1/1/2019','12/31/2019',8196.99 )
,('SCO','TCD','Statewide','1/1/2019','12/31/2019',4460.29 )
,('SCO','TCM','Statewide','1/1/2019','12/31/2019',4460.29 )
,('SCO','TND','Bos','1/1/2019','6/30/2019',2371.40 )
,('SCO','TND','Bos','7/1/2019','12/31/2019',2315.98 )
,('SCO','TND','Non','1/1/2019','6/30/2019',2671.68 )
,('SCO','TND','Non','7/1/2019','12/31/2019',2609.58 )
,('SCO','TNM','Bos','1/1/2019','6/30/2019',3648.28 )
,('SCO','TNM','Bos','7/1/2019','12/31/2019',3648.28 )
,('SCO','TNM','Non','1/1/2019','6/30/2019',3842.52 )
,('SCO','TNM','Non','7/1/2019','12/31/2019',3842.52 )
,('SCO','CAD','Bos','1/1/2018','12/31/2018',427.11 )
,('SCO','CAD','Non','1/1/2018','12/31/2018',443.29 )
,('SCO','CAM','Bos','1/1/2018','12/31/2018',1594.94 )
,('SCO','CAM','Non','1/1/2018','12/31/2018',1394.25 )
,('SCO','CND','Bos','1/1/2018','12/31/2018',2528.60 )
,('SCO','CND','Non','1/1/2018','12/31/2018',2753.30 )
,('SCO','CNM','Bos','1/1/2018','12/31/2018',3594.79 )
,('SCO','CNM','Non','1/1/2018','12/31/2018',3721.35 )
,('SCO','CWD','Bos','1/1/2018','12/31/2018',247.73 )
,('SCO','CWD','Non','1/1/2018','12/31/2018',272.20 )
,('SCO','CWM','Bos','1/1/2018','12/31/2018',753.03 )
,('SCO','CWM','Non','1/1/2018','12/31/2018',746.91 )
,('ICO','DC1','Cape','1/1/2018','12/31/2018',171.21 )
,('ICO','DC1','East','1/1/2018','12/31/2018',158.07 )
,('ICO','DC1','Statewide','11/1/2018','12/31/2018',155.71 )
,('ICO','DC1','West','1/1/2018','12/31/2018',150.44 )
,('ICO','DC2A','Cape','1/1/2018','12/31/2018',604.13 )
,('ICO','DC2A','East','1/1/2018','12/31/2018',558.13 )
,('ICO','DC2A','Statewide','11/1/2018','12/31/2018',537.77 )
,('ICO','DC2A','West','1/1/2018','12/31/2018',509.84 )
,('ICO','DC2B','Cape','1/1/2018','12/31/2018',846.62 )
,('ICO','DC2B','East','1/1/2018','12/31/2018',781.44 )
,('ICO','DC2B','West','1/1/2018','12/31/2018',712.94 )
,('ICO','DC3A','Cape','1/1/2018','12/31/2018',3106.12 )
,('ICO','DC3A','East','1/1/2018','12/31/2018',2829.24 )
,('ICO','DC3A','Statewide','11/1/2018','12/31/2018',2807.55 )
,('ICO','DC3A','West','1/1/2018','12/31/2018',2764.80 )
,('ICO','DC3B','Cape','1/1/2018','12/31/2018',6584.93 )
,('ICO','DC3B','East','1/1/2018','12/31/2018',5997.02 )
,('ICO','DC3B','West','1/1/2018','12/31/2018',5867.48 )
,('ICO','DF1','Statewide','1/1/2018','12/31/2018',9102.96 )
,('ICO','DF1','Cape','1/1/2018','12/31/2018',8059.66 )
,('ICO','DF1','East','1/1/2018','12/31/2018',9558.25 )
,('ICO','DF1','West','1/1/2018','12/31/2018',8440.84 )
,('SCO','I1D','Statewide','1/1/2018','12/31/2018',4273.39 )
,('SCO','I1M','Statewide','1/1/2018','12/31/2018',4273.39 )
,('SCO','I2D','Statewide','1/1/2018','12/31/2018',6150.27 )
,('SCO','I2M','Statewide','1/1/2018','12/31/2018',6150.27 )
,('SCO','I3D','Statewide','1/1/2018','12/31/2018',7959.68 )
,('SCO','I3M','Statewide','1/1/2018','12/31/2018',7959.68 )
,('SCO','TCD','Statewide','1/1/2018','12/31/2018',4273.39 )
,('SCO','TCM','Statewide','1/1/2018','12/31/2018',4273.39 )
,('SCO','TND','Bos','1/1/2018','12/31/2018',2528.60 )
,('SCO','TND','Non','1/1/2018','12/31/2018',2753.30 )
,('SCO','TNM','Bos','1/1/2018','12/31/2018',3594.79 )
,('SCO','TNM','Non','1/1/2018','12/31/2018',3721.35 )



if object_id('tempdb..#preloadRateCards') is not null
	drop table #preloadRateCards

select distinct
	  rc.CCARateCellID                          
	, reg.CCARegionID			                
	, rate.StartDate     
	, rate.EndDate       
	, rate.Amount        
	, '' as RateCardLabel 
	, case ccaRc.Product 
		when 'SCO' then SUBSTRING(rc.ccaRateCell, 3, 1) 
		when 'ICO' then 'D' 
		else NULL 
	end as Eligibility   
	, ccaRc.Product                             
	, 1 as ActiveFlag
	, @spStart as insertDate
	, @spStart as updateDate
into #preloadRateCards
from #rateRegionAmounts as rate
inner join vwRegionMap as reg on reg.CCARegion = rate.CCARegion
inner join vwRateCellMap as rc on rc.CCARateCell = rate.CCARateCell
inner join CCARateCells as ccaRc on ccaRc.CCARateCellID = rc.CCARateCellID


insert into RateCard (

	  CCARateCellID       
	, CCARegionID         
	, StartDate           
	, EndDate             
	, Amount              
	, RateCardLabel       
	, Eligibility         
	, Product
	, ActiveFlag
	, insertDate
	, updateDate
)
SELECT
	  CCARateCellID       
	, CCARegionID         
	, StartDate           
	, EndDate             
	, Amount              
	, RateCardLabel       
	, Eligibility         
	, Product
	, ActiveFlag
	, insertDate
	, updateDate
FROM #preloadRateCards as p
WHERE NOT EXISTS (
	SELECT RateCardID
	FROM RateCard as rc
	WHERE 
		-- TEST UNIQUE KEY
		    rc.CCARateCellID = p.CCARateCellID
		and rc.CCARegionID   = p.CCARegionID  
		and rc.StartDate     = p.StartDate    
		and rc.EndDate       = p.EndDate
)


