
USE [RevRec]
GO

DECLARE @spStart datetime2(3) = getdate()
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 1. Get Regions from View, store only if they do not exist
	-- ******************************
	
	insert into CCARegions (
		CCARegion
		, Product
		, ActiveFlag
		, insertDate
		, updateDate
	)

	SELECT 
		CCARegion 
		, Product
		, 1 as ActiveFlag
		, @spStart as insertDate
		, @spStart as updateDate
	FROM (
		-- ICO
		select dsReg.value as CCARegion, ds.VALUE as Product, count(*) as CountByRegion 
		from mpsnapshotprod.dbo.DATE_SPAN as dsReg
		inner join mpsnapshotprod.dbo.DATE_SPAN as ds 
			on ds.NAME_ID = dsReg.NAME_ID
			and dsReg.START_DATE between ds.START_DATE and isnull(ds.END_DATE, '2999-12-31')
		where   dsReg.CARD_TYPE = 'MCAID App'
			and dsReg.COLUMN_NAME = 'name_text18'
			-- and dsReg.VALUE <> '99'
			and ds.CARD_TYPE = 'MCAID App'
			and ds.COLUMN_NAME = 'name_text19'
			and ds.VALUE in ('ICO') -- removed 'SCO' due to conflict in primary key and "bad" assignment in front end.
		group by dsReg.value, ds.VALUE 

		union all

		-- should only be SCO, but will bring in product
		select 
		right(dsreg.value, 3) as CCARegion, ds.VALUE as Product, count(*) as CountByRegion 
		from mpsnapshotprod.dbo.DATE_SPAN as dsReg
		inner join mpsnapshotprod.dbo.DATE_SPAN as ds 
			on ds.NAME_ID = dsReg.NAME_ID
			and dsReg.START_DATE between ds.START_DATE and isnull(ds.END_DATE, '2999-12-31')
		where   dsReg.CARD_TYPE = 'MCAID App'
			and dsReg.COLUMN_NAME = 'name_text14'
			and dsReg.VALUE <> '99'
			and ds.CARD_TYPE = 'MCAID App'
			and ds.COLUMN_NAME = 'name_text19'
			and ds.VALUE in ('SCO', 'ICO')
			and len(dsReg.VALUE) = 6
		group by right(dsreg.value, 3), ds.VALUE

		-- Statewide additions -- will pause on adding this until confirming unique key ramifications
		-- union all select 'Statewide' as CCARegion, 'ICO' as Product, 1 as CountByRegion 
		-- union all select 'Statewide' as CCARegion, 'SCO' as Product, 1 as CountByRegion 
	
	) as v
	WHERE CCARegion is not null
	and not exists (
		select CCARegion
		FROM CCARegions as t
		WHERE t.CCARegion  = v.CCARegion
	)

	-- ******************************
	-- validation
		-- 09/15/2019 confirmed no trimming needed
	-- ******************************
	-- select * from CCARegions 
	-- select * from vwRateCard
