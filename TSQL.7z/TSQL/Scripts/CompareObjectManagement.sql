use RevRec

if object_id('tempdb..#orgObjects') is not null
	drop table #orgObjects 

create table #orgObjects (
	objName varchar(1000)
)

insert into #orgObjects (
	objName
) 
values
 ('C:\\temp\\ADS-2069\\Tables\\dbo.CCARateCells.sql')
,('C:\\temp\\ADS-2069\\Tables\\dbo.CCARegions.sql')
,('C:\\temp\\ADS-2069\\Tables\\dbo.MMISRateCells.sql')
,('C:\\temp\\ADS-2069\\Tables\\dbo.MMISRegions.sql')
,('C:\\temp\\ADS-2069\\Tables\\dbo.RateCard.sql')
,('C:\\temp\\ADS-2069\\Tables\\dbo.RateCellMap.sql')
,('C:\\temp\\ADS-2069\\Tables\\dbo.RegionMap.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwGetUnmappedMMISRateCellCount.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwGetUnmappedMMISRegionCount.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwMMISRateCells.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwMMISRegions.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwProcessMMISRateCells.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwProcessMMISRegions.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwRateCard.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwRateCellMap.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwRegionMap.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spTrun_CCARateCells.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spTrun_CCARegions.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spTrun_MMISRateCells.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spTrun_MMISRegions.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spTrun_RateCard.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spTrun_RegionMap.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spCreateRateCard.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetCCARateCells.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetCCARegions.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetMMISRateCells.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetMMISRegions.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetRateCard.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetRateCellMap.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetRegionMap.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetUnmappedMMISRateCellCount.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetUnmappedMMISRegionCount.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spProcessMMISRateCells.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spProcessMMISRegions.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spUpdateRateCard.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spUpdateRateCellMap.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spUpdateRegionMap.sql')
,('C:\\temp\\ADS-2069\\Scripts\\preLoad_spProcessCCARateCells.sql')
,('C:\\temp\\ADS-2069\\Scripts\\preLoad_spProcessCCARegions.sql')
,('C:\\temp\\ADS-2069\\Scripts\\preLoad_RateCellMap.sql')
,('C:\\temp\\ADS-2069\\Scripts\\preLoad_RegionMap.sql')
,('C:\\temp\\ADS-2069\\Scripts\\preLoad_RateCard.sql')


if object_id('tempdb..#newObjects') is not null
	drop table #newObjects 

create table #newObjects (
	objName varchar(1000)
)

insert into #newObjects (
	objName
) 
values
('C:\\temp\\ADS-2069\\Tables\\dbo.CCARateCells.sql')
,('C:\\temp\\ADS-2069\\Tables\\dbo.CCARegions.sql')
,('C:\\temp\\ADS-2069\\Tables\\dbo.MMISRateCells.sql')
,('C:\\temp\\ADS-2069\\Tables\\dbo.MMISRegions.sql')
,('C:\\temp\\ADS-2069\\Tables\\dbo.RateCard.sql')
,('C:\\temp\\ADS-2069\\Tables\\dbo.RateCellMap.sql')
,('C:\\temp\\ADS-2069\\Tables\\dbo.RegionMap.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwCCARateCells.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwCCARegions.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwGetUnmappedMMISRateCellCount.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwGetUnmappedMMISRegionCount.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwProcessMMISRateCells.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwProcessMMISRegions.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwRateCard.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwRateCellMap.sql')
,('C:\\temp\\ADS-2069\\Views\\dbo.vwRegionMap.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spCreateRateCard.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetCCARateCells.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetCCARegions.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetMMISRateCells.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetMMISRegions.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetRateCard.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetRateCellMap.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetRegionMap.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetUnmappedMMISRateCellCount.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spGetUnmappedMMISRegionCount.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spProcessMMISRateCells.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spProcessMMISRegions.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spUpdateRateCard.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spUpdateRateCellMap.sql')
,('C:\\temp\\ADS-2069\\Procedures\\dbo.spUpdateRegionMap.sql')
,('C:\\temp\\ADS-2069\\Scripts\\preLoad_spProcessCCARateCells.sql')
,('C:\\temp\\ADS-2069\\Scripts\\preLoad_spProcessCCARegions.sql')
,('C:\\temp\\ADS-2069\\Scripts\\preLoad_RateCellMap.sql')
,('C:\\temp\\ADS-2069\\Scripts\\preLoad_RegionMap.sql')
,('C:\\temp\\ADS-2069\\Scripts\\preLoad_RateCard.sql')



select * from #orgObjects
except
select * from #newObjects

select * from #newObjects
except
select * from #orgObjects
