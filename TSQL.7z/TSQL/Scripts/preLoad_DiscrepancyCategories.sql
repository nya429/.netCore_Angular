USE [RevRec]
GO

/*
	-- clear for re-import
	-- EXEC spTrun_DiscrepancyCategories
	truncate table DiscrepancyCategories

	-- validate pre/post import
	SELECT * FROM DiscrepancyCategories


*/	

DECLARE @spStart datetime2(3) = getdate()

if OBJECT_ID('tempdb..#revrecDiscrepancyCategories') is not null
	drop table #revrecDiscrepancyCategories

create table #revrecDiscrepancyCategories (
	  DiscrepancyCategory varchar(50) NOT NULL
	, DiscrepancyCategoryDescription varchar(1000) NULL
	, DiscrepancyCategoryDisplay bit -- 0 = not displayed by default in front end; 1 = always display in front end
	, DiscrepancyCategoryAddStatus bit -- 0 = not displayed by default in front end; 1 = always display in front end
)

insert into #revrecDiscrepancyCategories (
	  DiscrepancyCategory 
	, DiscrepancyCategoryDescription	
	, DiscrepancyCategoryDisplay 
	, DiscrepancyCategoryAddStatus
)
values
 ('New', 'Must be reviewed', 1, 0)
,('Pending', 'In progress, and does not fall off working list', 1, 1)
,('Worked', 'Waiting for system resolution, falls off discrepancy working list', 0, 1)
,('Complete', 'Discrepancy will remain, but no further action can be taking', 0, 1)
,('Resolved', 'Discrepancy is corrected', 0, 0)



insert into DiscrepancyCategories (
	  DiscrepancyCategory 
	, DiscrepancyCategoryDescription	
	, DiscrepancyCategoryDisplay 
	, DiscrepancyCategoryAddStatus
	, ActiveFlag
	, insertDate
	, updateDate
)
select 
	  rr.DiscrepancyCategory 
	, rr.DiscrepancyCategoryDescription	
	, rr.DiscrepancyCategoryDisplay 
	, rr.DiscrepancyCategoryAddStatus
	, 1        as ActiveFlag
	, @spStart as insertDate
	, @spStart as updateDate
from #revrecDiscrepancyCategories as rr
where not exists (
	select DiscrepancyCategoryId
	from DiscrepancyCategories as dc
	where dc.DiscrepancyCategory = rr.DiscrepancyCategory
		
	)

