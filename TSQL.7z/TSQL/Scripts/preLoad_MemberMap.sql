USE [RevRec]
GO

/*
	-- clear for re-import
	EXEC spTrun_MemberMap

	-- validate pre/post import
	SELECT * FROM   MemberMap
	select * from vwMemberMap

	-- duplicates are natural, due to extra spans
	select * 
	from CCAMemberData as c
	inner join MMISMemberData as m on m.MMIS_ID = c.MMIS_ID
	where c.ccaid = '5364521037'
*/	

EXEC [dbo].[spProcessMemberMap] 



		
