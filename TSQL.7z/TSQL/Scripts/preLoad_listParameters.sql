USE [RevRec]
GO

-- Reset values
-- delete from listParameters where ApplicationName = 'RevRec'

-- Verify entry
-- select * from listParameters where ApplicationName = 'RevRec'


-- Insert Application entry into static parameters for more streamlined 

declare @ApplicationName varchar(50) = 'RevRec'
  

-- Insert application parameters and default values into the parameters table.


if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'ExecutionLogging')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'ExecutionLogging'        , 'char(1)' , 'E'                  )


	 
if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'EmailDomain')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'EmailDomain'        , 'varchar(50)' , '@commonwealthcare.org'                  )


	 
if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'ProcessLogging')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'ProcessLogging'        , 'char(1)' , 'A'                  )


if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'BrowneConstant')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'BrowneConstant'        , 'bigint' , '5364521034'          )


if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'OpenEndDate')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'OpenEndDate'        , 'date' , '2999-12-31'                  )


if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'LookbackDate')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'LookbackDate'        , 'date' , '2018-01-01'                  )
	 
-- use this... or just get outstanding.  Will ignore for now
if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'LastMonthProcessed')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'LastMonthProcessed'        , 'date' , '2018-12-01'                  )
	 

if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'ProcessingPeriod')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'ProcessingPeriod'        , 'char(1)' , 'M'                  ) -- (M)onth; (O)utstanding; (A)ll?
	 

if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'MissingRateCell')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'MissingRateCell'        , 'varchar(50)' , '99'                  ) -- (M)onth; (O)utstanding; (A)ll?
	 

if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'MissingRegion')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'MissingRegion'        , 'varchar(50)' , 'NA'                  ) -- (M)onth; (O)utstanding; (A)ll?
	 

if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'defaultSort_spGetRateCellMap')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'defaultSort_spGetRateCellMap'        , 'varchar(50)' , 'RateCellMapID'                  ) -- (M)onth; (O)utstanding; (A)ll?
	 
if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'defaultSort_spGetRegionMap')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'defaultSort_spGetRegionMap'        , 'varchar(50)' , 'RegionMapID'                  ) -- (M)onth; (O)utstanding; (A)ll?
	 

if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'defaultSort_spGetMemberList')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'defaultSort_spGetMemberList'        , 'varchar(50)' , 'absoluteVarianceSum'                  ) -- (M)onth; (O)utstanding; (A)ll?


if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'defaultSort_spGetCCAMemberData')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'defaultSort_spGetCCAMemberData'        , 'varchar(50)' , 'CCAID'                  ) -- (M)onth; (O)utstanding; (A)ll?


if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'defaultSort_spGetUsers')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'defaultSort_spGetUsers'        , 'varchar(50)' , 'UserNameAD'                  ) -- (M)onth; (O)utstanding; (A)ll?


if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'defaultSort_spGetDiscrepancyCategories')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'defaultSort_spGetDiscrepancyCategories'        , 'varchar(50)' , 'DiscrepancyCategory'                  ) -- (M)onth; (O)utstanding; (A)ll?



if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'defaultSort_spGetDiscrepancyStatus')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'defaultSort_spGetDiscrepancyStatus'        , 'varchar(50)' , 'DiscrepancyStatus'                  ) -- (M)onth; (O)utstanding; (A)ll?


if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'defaultSort_spGetRateCard')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'defaultSort_spGetRateCard'        , 'varchar(50)' , 'CCARateCell'                  ) -- (M)onth; (O)utstanding; (A)ll?



if not exists (select ApplicationName from listParameters where ApplicationName = @ApplicationName and parameterName = 'defaultSort_spGetDiscrepancyList')
	INSERT INTO listParameters (
		  [ApplicationName]           
		, [parameterName]     
		, [parameterDataType] 
		, [parameterValue]    
	)
	VALUES 
	 (@ApplicationName, 'defaultSort_spGetDiscrepancyList'        , 'varchar(50)' , 'Variance'                  ) -- (M)onth; (O)utstanding; (A)ll?

	 
	 
		