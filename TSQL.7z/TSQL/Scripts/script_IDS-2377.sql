use [RevRec]
GO


DECLARE @appProject varchar(50) = 'RevRec' 
DECLARE @spStart datetime2(3) = getdate()
DECLARE @DiscrepancyCategoryID int = 8
DECLARE @eventUserID int = 0  -- System
DECLARE @spProcName varchar(50) = '[Script_IDS-2377]'
DECLARE @ReturnCode int 
DECLARE @EventOldData nvarchar(1000)
DECLARE @EventNewData nvarchar(1000)
DECLARE @AutoExpiredMDSStatus varchar(50) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'AutoExpiredMDSStatus')

BEGIN

	if object_id('tempdb..#EventResult') is not null
	drop table #EventResult

	create table #EventResult (
	
			DiscrepancyStatusID     int not null
	
			, old_DiscrepancyStatus             varchar(50) NULL
			, old_DiscrepancyStatusDescription  varchar(1000) NULL
			, old_DiscrepancyCategoryID         int NULL
			, old_DiscrepancyStatusType         bit NULL
			, old_ActiveFlag                    bit NULL		
	
			, new_DiscrepancyStatus             varchar(50) NULL
			, new_DiscrepancyStatusDescription  varchar(1000) NULL
			, new_DiscrepancyCategoryID         int NULL
			, new_DiscrepancyStatusType         bit NULL
			, new_ActiveFlag                    bit NULL		
	
	)

	UPDATE  [RevRec].[dbo].[DiscrepancyStatuses] 
	SET   DiscrepancyStatusType = 0
		, updateDate = @spStart
		, DiscrepancyStatus = @AutoExpiredMDSStatus
	OUTPUT
		inserted.DiscrepancyStatusID
		, deleted.DiscrepancyStatus 
		, deleted.DiscrepancyStatusDescription 
		, deleted.DiscrepancyCategoryID 
		, deleted.DiscrepancyStatusType
		, deleted.ActiveFlag 
		, inserted.DiscrepancyStatus 
		, inserted.DiscrepancyStatusDescription 
		, inserted.DiscrepancyCategoryID 
		, inserted.DiscrepancyStatusType
		, inserted.ActiveFlag 
	into #EventResult
	WHERE DiscrepancyStatusID = 8
	
	
	select @EventOldData = '{
				"DiscrepancyStatusID"          :'  + CAST(DiscrepancyStatusID               as varchar) 
			+ ', "DiscrepancyStatus" 		    :"' +      old_DiscrepancyStatus 		     + '"'
			+ ', "DiscrepancyStatusDescription" :"' +      old_DiscrepancyStatusDescription  + '"'
			+ ', "DiscrepancyCategoryID" 	    :'  + CAST(old_DiscrepancyCategoryID 		 as varchar) 
			+ ', "DiscrepancyStatusType"        :'  + CAST(old_DiscrepancyStatusType         as varchar) 
			
			+ ', "ActiveFlag"     :'  + case old_ActiveFlag when 0 then 'false' else 'true' end
			+ '}' 
		from #EventResult
	
		select @EventNewData = '{
				"DiscrepancyStatusID"          :'  + CAST(DiscrepancyStatusID               as varchar) 
			+ ', "DiscrepancyStatus" 		    :"' +      new_DiscrepancyStatus 		     + '"'
			+ ', "DiscrepancyStatusDescription" :"' +      new_DiscrepancyStatusDescription  + '"'
			+ ', "DiscrepancyCategoryID" 	    :'  + CAST(new_DiscrepancyCategoryID 		 as varchar) 
			+ ', "DiscrepancyStatusType"        :'  + CAST(new_DiscrepancyStatusType         as varchar) 
			
			+ ', "ActiveFlag"     :'  + case new_ActiveFlag when 0 then 'false' else 'true' end
			+ '}' 
		from #EventResult
		
		Set @ReturnCode = 2
		EXEC spPutUserEventLog @eventUserID, @spProcName, @spStart, @ReturnCode, @EventOldData, @EventNewData
	
		if object_id('tempdb..#EventResult') is not null
		drop table #EventResult
END	
GO



		