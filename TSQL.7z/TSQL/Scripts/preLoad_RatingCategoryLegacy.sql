USE [RevRec]
GO


/*
	-- clear for re-import
	truncate table CCARatingCategoryLegacy

	-- source tabels
	select * from CCARateCells
	select * from CCARegions
	
	select * from CCARatingCategoryLegacy
*/


DECLARE @spStart datetime2(3) = getdate()


if object_id('tempdb..#legacyCodeMap') is not null
	drop table #legacyCodeMap 

create table #legacyCodeMap (
	  Product    char(3) NULL
	, CCARateCell varchar(50) NOT NULL
	, CCARegion  varchar(50)  NOT NULL
	, LegacyCode varchar(50) NOT NULL
)


insert into #legacyCodeMap (
	  Product    
	, CCARateCell
	, CCARegion  
	, LegacyCode 
)
values 
 ('SCO','99','Bos','99')
,('SCO','99','Non','99')
,('ICO','99','East','99')
,('ICO','99','West','99')
,('ICO','99','Cape','99')
,('SCO','CAD','Bos','SE')
,('SCO','CAD','Non','SF')
,('SCO','CAM','Bos','SG')
,('SCO','CAM','Non','SH')
,('SCO','CND','Bos','SI')
,('SCO','CND','Non','SJ')
,('SCO','CNM','Bos','SK')
,('SCO','CNM','Non','SL')
,('SCO','CWD','Bos','SA')
,('SCO','CWD','Non','SB')
,('SCO','CWM','Bos','SC')
,('SCO','CWM','Non','SD')
,('ICO','DC1','East','DC1')
,('ICO','DC1','West','DC1')
,('ICO','DC1','Cape','DC1')
,('ICO','DC2A','East','DC2A')
,('ICO','DC2A','West','DC2A')
,('ICO','DC2A','Cape','DC2A')
,('ICO','DC2B','East','DC2B')
,('ICO','DC2B','West','DC2B')
,('ICO','DC2B','Cape','DC2B')
,('ICO','DC3A','East','DC3A')
,('ICO','DC3A','West','DC3A')
,('ICO','DC3A','Cape','DC3A')
,('ICO','DC3B','East','DC3B')
,('ICO','DC3B','West','DC3B')
,('ICO','DC3B','Cape','DC3B')
,('ICO','DC3C','East','DC3C')
,('ICO','DC3C','West','DC3C')
,('ICO','DC3C','Cape','DC3C')
,('ICO','DF1','East','DF1')
,('ICO','DF1','West','DF1')
,('ICO','DF1','Cape','DF1')
,('SCO','I1D','NA','LA')
,('SCO','I1M','NA','LB')
,('SCO','I2D','NA','LC')
,('SCO','I2M','NA','LD')
,('SCO','I3D','NA','LE')
,('SCO','I3M','NA','LF')
,('SCO','NA','NA','NA')
,('SCO','TCD','NA','LY')
,('SCO','TCM','NA','LZ')
,('SCO','TND','Bos','SW')
,('SCO','TND','Non','SX')
,('SCO','TNM','Bos','SY')
,('SCO','TNM','Non','SZ')




insert into CCARatingCategoryLegacy
(
	Product    
	, CCARateCell
	, CCARegion  
	, LegacyCode 
	, ActiveFlag	
	, insertDate	
	, updateDate

)

select 
		Product    
	, CCARateCell
	, CCARegion  
	, LegacyCode 
	, 1 as ActiveFlag
	, @spStart as insertDate	
	, @spStart as updateDate
from #legacyCodeMap as l
where not exists (
	select CCARatingCategoryLegacyID
	from CCARatingCategoryLegacy as r
	where 
			r.Product     = l.Product    
		and r.CCARateCell = l.CCARateCell
		and r.CCARegion   = l.CCARegion  
		and r.LegacyCode  = l.LegacyCode 
)


