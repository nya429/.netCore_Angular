use RevRec

	if not exists (SELECT SCHEMA_NAME(SCHEMA_ID), OBJECT_NAME(system_type_id), * FROM SYS.types WHERE name = 'BulkID' and SCHEMA_NAME(SCHEMA_ID) = 'dbo')
		-- DROP TYPE dbo.BulkID
		CREATE TYPE dbo.BulkID AS TABLE (
			UpdateID int NOT NULL 
		)
	GO  
	
	-- declare as (replace @Bulk with your variable name), @Bulk dbo.BulkID readonly

	
	
grant view definition on type::dbo.BulkID 	 to webapp
grant execute on type::dbo.BulkID 	 to webapp
