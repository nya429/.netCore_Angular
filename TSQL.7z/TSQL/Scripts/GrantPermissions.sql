USE RevRec

/*
SELECT * FROM SYS.tables WHERE TYPE = 'u' order by name
SELECT * FROM SYS.VIEWS order by name
*/

/*
-- grant select for webapp where dynamic SQL is used
-- following procedures use dynamic SQL
	spGetCCAMemberData (view only)
	spGetDiscrepancyCategories
	spGetDiscrepancyStatus
	spGetMemberList
	spGetRateCard (view only)
	spGetRateCellMap
	spGetRegionMap
	spGetUsers
*/

GRANT SELECT ON DiscrepancyStatuses    to webapp -- spGetDiscrepancyStatus, spGetMemberList
GRANT SELECT ON DiscrepancyCategories  to webapp -- spGetDiscrepancyCategories, spGetDiscrepancyStatus, spGetMemberList
GRANT SELECT ON MemberList             to webapp -- spGetMemberList
GRANT SELECT ON Discrepancies          to webapp -- spGetMemberList
GRANT SELECT ON RateCellMap            to webapp -- spGetRateCellMap
GRANT SELECT ON MMISRateCells          to webapp -- spGetRateCellMap
GRANT SELECT ON CCARateCells           to webapp -- spGetRateCellMap
GRANT SELECT ON RegionMap              to webapp -- spGetRegionMap
GRANT SELECT ON MMISRegions            to webapp -- spGetRegionMap
GRANT SELECT ON CCARegions             to webapp -- spGetRegionMap
GRANT SELECT ON users                  to webapp -- spGetUsers
GRANT SELECT ON UserRoleMap            to webapp -- spGetUsers
GRANT SELECT ON UserRoles              to webapp -- spGetUsers


-- permissions for webapp for views related to model in UI.
grant select on vwGetUnmappedMMISRegionCount		   to webapp
grant select on vwGetUnmappedMMISRateCellCount		   to webapp
grant select on vwRateCard							   to webapp -- spGetRateCard
grant select on vwCCAMemberData						   to webapp -- spGetCCAMemberData
grant select on vwMMISRateCells						   to webapp
grant select on vwMMISRegions						   to webapp
grant select on vwProcessMMISRegions				   to webapp
grant select on vwDiscrepancyCategories				   to webapp
grant select on vwProcessMMISRateCells				   to webapp
grant select on vwMMISMemberData					   to webapp
grant select on vwMemberMap							   to webapp
grant select on vwMemberData						   to webapp
grant select on vwMonthEndOutput					   to webapp
grant select on vwRegionMap							   to webapp
grant select on vwCCARateCells						   to webapp
grant select on vwCCARegions						   to webapp
grant select on vwDiscrepancyStatuses  	               to webapp
grant select on vwGetDiscrepancyList				   to webapp
grant select on vwGetDiscrepancyRecord				   to webapp
grant select on vwRateCellMap						   to webapp
grant select on vwDiscrepancyStatuses				   to webapp
grant select on vwGetMonthlySummaryRecordMemberMonths  to webapp
grant select on vwGetDiscrepancyCommentList			   to webapp
grant select on vwGetMonthlySummaryRecordMemberYears   to webapp

-- permissions for table type definitions for webapp
grant view definition on type::dbo.BulkID 	 to webapp
grant view definition on type::dbo.BulkString to webapp
grant view definition on type::dbo.BulkDate   to webapp 

grant execute on type::dbo.BulkID 	 to webapp
grant execute on type::dbo.BulkString to webapp
grant execute on type::dbo.BulkDate   to webapp 
