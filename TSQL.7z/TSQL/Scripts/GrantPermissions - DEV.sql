USE RevRec

/*
SELECT * FROM SYS.tables WHERE TYPE = 'u'
SELECT * FROM SYS.VIEWS 
*/


GRANT SELECT, UPDATE, INSERT, DELETE ON RateCard                           to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON UserAccessLog					   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON ExecutionLog					   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON MMISMemberData					   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON CCAMemberSpanPatientSpendDown	   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON CCAMemberSpanPatientPay			   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON CCAMemberData					   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON CCAMemberSpanEnrollment			   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON MMISMultiMap					   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON CCAMemberSpanRegion				   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON CCAMemberSpanRatingCategory		   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON MemberMap						   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON testPatientPaymentDetail		   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON ValidationLog					   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON MMISFileProcessing				   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON PatientPayMonthly				   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON PatientPayDetail				   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON MonthlySummaryRecord			   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON CCARegions						   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON MonthlyCloseHeader				   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON RegionMap						   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON MonthlyCloseRecord				   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON Discrepancies					   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON CCARateCells					   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON MMISRegions						   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON UserEventLog					   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON MMISRateCells					   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON listParameters					   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON RateCellMap						   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON DiscrepancyStatuses				   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON DiscrepanciesCommentsHistory	   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON DiscrepanciesComments			   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON Users							   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON UserRoles						   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON logFileLoad						   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON DiscrepancyCategories			   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON DiscrepanciesHistory			   to webapp
GRANT SELECT, UPDATE, INSERT, DELETE ON UserRoleMap						   to webapp


grant select on vwGetUnmappedMMISRegionCount		   to webapp
grant select on vwGetUnmappedMMISRateCellCount		   to webapp
grant select on vwRateCard							   to webapp
grant select on vwCCAMemberData						   to webapp
grant select on vwMMISRateCells						   to webapp
grant select on vwMMISRegions						   to webapp
grant select on vwProcessMMISRegions				   to webapp
grant select on vwDiscrepancyCategories				   to webapp
grant select on vwProcessMMISRateCells				   to webapp
grant select on vwMMISMemberData					   to webapp
grant select on vwMemberMap							   to webapp
grant select on vwMemberData						   to webapp
grant select on vwMonthEndOutput					   to webapp
grant select on vwRegionMap							   to webapp
grant select on vwCCARateCells						   to webapp
grant select on vwCCARegions						   to webapp
grant select on vwProcessCCARateCells				   to webapp
grant select on vwProcessCCARegions					   to webapp
grant select on vwDiscrepancyStatus					   to webapp
grant select on vwGetDiscrepancyList				   to webapp
grant select on vwGetDiscrepancyRecord				   to webapp
grant select on vwRateCellMap						   to webapp
grant select on vwDiscrepancyStatuses				   to webapp
grant select on wvGetMonthlySummaryRecordMemberYears   to webapp
grant select on vwGetMonthlySummaryRecordMemberMonths  to webapp
grant select on vwGetDiscrepancyCommentList			   to webapp
grant select on vwGetMonthlySummaryRecordMemberYears   to webapp


grant view definition on type::dbo.BulkID 	 to webapp
grant view definition on type::dbo.BulkString to webapp
grant view definition on type::dbo.BulkDate   to webapp 

grant execute on type::dbo.BulkID 	 to webapp
grant execute on type::dbo.BulkString to webapp
grant execute on type::dbo.BulkDate   to webapp 
