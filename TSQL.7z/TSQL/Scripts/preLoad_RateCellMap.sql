USE [RevRec]
GO


/*
	09/15/2019 - added this to be part of the initial processing without need for special instructions/execution

	-- clear for re-import

	exec spTrun_MMISRateCells
	select * from MMISRateCells
*/

	exec spProcessMMISRateCells


/*
	-- clear for re-import
	EXEC spTrun_RateCellMap

	-- validate pre/post import
	SELECT * FROM RateCellMap
	select * from vwRateCellMap



-- Quick verification and research
	
	select * from  CCARateCells as c
	select * from MMISRateCells as s

	select 	
			c.CCARateCellID	
		, c.CCARateCell	
		, c.Product as CCAProduct
		, s.MMISRateCellID	
		, s.MMISRateCell	
		, s.Product as MMISProduct
	from  CCARateCells as c
	INNER JOIN MMISRateCells as s 
		on s.Product = c.Product
		and s.MMISRateCell = c.CCARateCell
*/



DECLARE @spStart datetime2(3) = getdate()

-- select * from vwCCARegions
-- select * from vwMMISRegions

	insert into RateCellMap (
		  CCARateCellID 
		, MMISRateCellID
		, ActiveFlag
		, insertDate
		, updateDate
	)
	-- direct matches
	select 
		  CCARateCellID 
		, MMISRateCellID
		, 1 as ActiveFlag
		, @spStart as insertDate
		, @spStart as updateDate
	from (	

		select 
			  c.CCARateCellID 
			, s.MMISRateCellID
		from  CCARateCells as c
		INNER JOIN MMISRateCells as s 
			on s.Product = c.Product
			and s.MMISRateCell = c.CCARateCell

	) as allRateCells
	where not exists (
		select RateCellMapID
		from RateCellMap as m
		where m.MMISRateCellID = allRateCells.MMISRateCellID
			and m.CCARateCellID = allRateCells.CCARateCellID
	)

	union all
	-- SCO prefix matches (stripping 4th character '2' suffix)

	select 
		  CCARateCellID 
		, MMISRateCellID
		, 1 as ActiveFlag
		, @spStart as insertDate
		, @spStart as updateDate
	from (	

		select 
			  c.CCARateCellID 
			, s.MMISRateCellID
		from  CCARateCells as c
		INNER JOIN MMISRateCells as s 
			on s.Product = c.Product
			and left(s.MMISRateCell, 3) = c.CCARateCell
		where s.Product = 'SCO'
			and len(s.MMISRateCell) = 4
			and right(s.MMISRateCell,1) = '2'

	) as prefixRateCells
	where not exists (
		select RateCellMapID
		from RateCellMap as m
		where m.MMISRateCellID = prefixRateCells.MMISRateCellID
			and m.CCARateCellID = prefixRateCells.CCARateCellID
	)


/*
	Post-QA: 09/12/2019
		altered column CCARateCellID to be null
			This will allow the the map to contain all MMIS rate cells, awaiting a map to CCA rate cell
			Will be compatible with the 1-to-many concept on the interface in the admin screen.

*/


	insert into RateCellMap
	(
		MMISRateCellID	
		, ActiveFlag	
		, insertDate	
		, updateDate
	)

	select 
		  RC.MMISRateCellID	
		, 0 AS ActiveFlag	
		, RC.insertDate	
		, RC.insertDate AS updateDate
	from MMISRateCells as rc
	where not exists (
		select mmisratecellid 
		from RateCellMap as m
		where rc.mmisratecellid = m.mmisratecellid 
	)


