USE [RevRec]
GO

/*
	-- clear for re-import
	-- EXEC spTrun_Users
	truncate table users

	-- validate pre/post import
	SELECT * FROM Users


*/	

DECLARE @spStart datetime2(3) = getdate()

if OBJECT_ID('tempdb..#revrecUsers') is not null
	drop table #revrecUsers

create table #revrecUsers (
	UserNameAD varchar(50)
	, UserFirstName varchar(50)
	, UserLastName	varchar(50)
	, UserEmail varchar(100) 
)

insert into #revrecUsers (
	UserNameAD
	, UserFirstName
	, UserLastName
	, UserEmail
)
values

  ('ysong'     ,'Yue', 'Song', 'ysong@commonwealthcare.org')
, ('jlewis'    ,'Jonathan', 'Lewis', 'jlewis@commonwealthcare.org')
, ('nfrenette' ,'Nicholas', 'Frenette', 'nfrenette@commonwealthcare.org')
, ('randrade'  ,'Remo', 'Andrade', 'randrade@commonwealthcare.org')
, ('lalvarez'  ,'Leslie', 'Alvarez', 'LAlvarez@commonwealthcare.org')
, ('aortiz'    ,'Albany', 'Ortiz', 'alortiz@commonwealthcare.org')
, ('jbresnahan','James', 'Bresnahan', 'jbresnahan@commonwealthcare.org')
, ('rrathore'  ,'Rajeev', 'Rathore', 'rrathore@commonwealthcare.org')
, ('tpardeshi' ,'Tejaswini', 'Pardeshi', 'tpardeshi@commonwealthcare.org')
, ('dboni' ,'Doug', 'Boni', 'dboni@commonwealthcare.org')
, ('adevarapall', 'Abhinay', 'Devarapall', 'adevarapall@commonwealthcare.org')



insert into Users (
		UserNameAD 
	, UserFirstName
	, UserLastName
	, UserEmail
	, ActiveFlag
	, insertDate
	, updateDate
)
select 
	rru.UserNameAD
	, rru.UserFirstName
	, rru.UserLastName
	, rru.UserEmail
	, 1        as ActiveFlag
	, @spStart as insertDate
	, @spStart as updateDate
from #revrecUsers as rru
where not exists (
	select UserId
	from Users as u
	where u.UserNameAD = rru.UserNameAD
		
	)

