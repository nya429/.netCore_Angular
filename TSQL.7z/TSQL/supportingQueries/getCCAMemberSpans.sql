
/*
	INSERT INTO dbo.CCAMemberData (

		CCAID
		, MMIS_ID
		, MemberFirstName
		, MemberMiddleName
		, MemberLastName
		, Gender
		, DOB
		, Product
		, EnrollStartDate
		, EnrollEndDate
		, RatingCategory
		, RatingCategoryStartDate
		, RatingCategoryEndDate
		, Region
		, RegionStartDate		
		, RegionEndDate
		, PatientPay
		, PatientPayStartDate		
		, PatientPayEndDate
		, PatientSpendDown
		, PatientSpendDownStartDate	
		, PatientSpendDownEndDate

	)
*/	

-- exec time: 0:02 seconds

-- PRE-QUERY FIX: 92056
-- if object_id('tempdb..#testMember1') is not null
-- 	drop table #testMember1
-- SELECT COUNT(*) FROM #testMember1

-- POST-QUERY FIX: 93430
-- if object_id('tempdb..#testMember2') is not null
-- 	drop table #testMember2
-- SELECT COUNT(*) FROM #testMember2


-- difference of: 3141
-- select * from #testMember2 except select * from #testMember1

	select 
		n.TEXT2            AS CCAID
		, eea.TEXT1        as MMIS_ID 
		, n.NAME_FIRST     as MemberFirstName
		, n.NAME_MI	       as MemberMiddleName
		, n.NAME_LAST      as MemberLastName
		, n.GENDER         as Gender
		, n.BIRTH_DATE     as DOB
		, dsEnr.VALUE      AS Product
		, dsEnr.START_DATE AS EnrollStartDate
		, dsEnr.END_DATE   AS EnrollEndDate
		, dsRat.VALUE      as RatingCategory
		, dsRat.START_DATE AS RatingCategoryStartDate		
		, dsRat.END_DATE   AS RatingCategoryEndDate
		, case dsEnr.value when 'SCO' then substring(dsRat.VALUE,4,3) when 'ICO' then dsReg.VALUE      else NULL end AS Region
		, case dsEnr.value when 'SCO' then dsRat.START_DATE           when 'ICO' then dsReg.START_DATE else NULL end AS RegionStartDate
		, case dsEnr.value when 'SCO' then dsRat.END_DATE             when 'ICO' then dsReg.END_DATE   else NULL end AS RegionEndDate
		, dsPat.VALUE      as PatientPay
		, dsPat.START_DATE AS PatientPayStartDate		
		, dsPat.END_DATE   AS PatientPayEndDate
		, dsSpd.VALUE      as PatientSpendDown
		, dsSpd.START_DATE AS PatientSpendDownStartDate		
		, dsSpd.END_DATE   AS PatientSpendDownEndDate

	INTO #testMember2 -- dbo.CCAMemberData
	from MPSnapshotProd.dbo.name as n
	inner join MPSnapshotProd.dbo.ENTITY_ENROLL_APP as eea on eea.entity_id = n.name_id
	inner join MPSnapshotProd.dbo.DATE_SPAN as dsEnr on dsEnr.NAME_ID = n.NAME_ID AND dsEnr.CARD_TYPE = 'MCAID App' and dsEnr.COLUMN_NAME = 'name_text19'
	inner join MPSnapshotProd.dbo.DATE_SPAN as dsRat on dsRat.NAME_ID = n.NAME_ID AND dsRat.CARD_TYPE = 'MCAID App' and dsRat.COLUMN_NAME = 'name_text14' and dsRat.START_DATE between dsEnr.START_DATE and isnull(dsEnr.END_DATE, '2999-12-31')
	LEFT join  MPSnapshotProd.dbo.DATE_SPAN as dsReg on dsReg.NAME_ID = n.NAME_ID AND dsReg.CARD_TYPE = 'MCAID App' and dsReg.COLUMN_NAME = 'name_text18' and dsEnr.VALUE = 'ICO'
		and dsReg.START_DATE between dsEnr.START_DATE and isnull(dsEnr.END_DATE, '2999-12-31')
		and dsReg.START_DATE between dsRat.START_DATE and isnull(dsRat.END_DATE, '2999-12-31')
	LEFT join  MPSnapshotProd.dbo.DATE_SPAN as dsPat on dsPat.NAME_ID = n.NAME_ID AND dsPat.CARD_TYPE = 'MCAID App' and dsPat.COLUMN_NAME = 'name_text22'
		and dsPat.START_DATE between dsEnr.START_DATE and isnull(dsEnr.END_DATE, '2999-12-31')
		and dsPat.START_DATE between dsRat.START_DATE and isnull(dsRat.END_DATE, '2999-12-31')
		and (
			dsReg.START_DATE is null
			or dsPat.START_DATE between dsReg.START_DATE and isnull(dsReg.END_DATE, '2999-12-31')
		)
	LEFT join  MPSnapshotProd.dbo.DATE_SPAN as dsSpd on dsSpd.NAME_ID = n.NAME_ID AND dsSpd.CARD_TYPE = 'MCAID App' and dsSpd.COLUMN_NAME = 'name_text20'
		and dsSpd.START_DATE between dsEnr.START_DATE and isnull(dsEnr.END_DATE, '2999-12-31')
		and dsSpd.START_DATE between dsRat.START_DATE and isnull(dsRat.END_DATE, '2999-12-31')
		and (
			dsReg.START_DATE is null
			or dsSpd.START_DATE between dsReg.START_DATE and isnull(dsReg.END_DATE, '2999-12-31')
		)
		and (
			dsPat.START_DATE is null
			or dsSpd.START_DATE between dsPat.START_DATE and isnull(dsPat.END_DATE, '2999-12-31')
		)
			

	where dsEnr.VALUE IN ('SCO', 'ICO')
	-- AND dsEnr.CREATE_DATE >= '2019-01-01'
	and eea.APP_TYPE = 'MCAID'
	-- and n.text2 like '[5][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' -- ADS-500 pattern match for more accurate member ID validation
	and n.text2 like '[5][3-9][6-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' -- ADS-500 pattern match for more accurate member ID validation
	-- won't roll over in Matt's lifetime

