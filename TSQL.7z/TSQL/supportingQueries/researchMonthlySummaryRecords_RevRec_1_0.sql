select * from monthly_summary_records;
select * from closing_monthly_summary_records;

select count(*) from monthly_summary_records; -- 1,779,512
select count(*) from closing_monthly_summary_records ; -- 89,396,779

select monthly_summary_record_id, count(*) from closing_monthly_summary_records group by monthly_summary_record_id ;
select closing_record_id, count(*) from closing_monthly_summary_records group by closing_record_id ;

show tables like '%month%';


select * from rating_categories;

select 
	case 
		when a.member_id < 0 then cast(a.member_id as char) 
		else (b.unique_identifier-5364521034)
	end as member_id
    , a.month as member_month
    ,"2019-08-01" as Assessment_Date
	,b.source_identifier as MpMemberId
    ,(
		select c.legacy_code 
		from  revrec_production.rating_categories c 
		where a.org_rating_category_id = c.id
	) as Org_Rating_Category
    , (
		select c.legacy_code 
		from  revrec_production.rating_categories c 
		where a.payor_rating_category_id = c.ID
	) as Payor_Rating 
    ,a.payor_rating_category_rate as Contract_Rate 
    ,a.org_premium as Org_Premium
	,a.payor_premium as Payor_Premium
    ,a.org_spenddown as Org_Spend_Down
    ,a.payor_spenddown as Payor_Spend_Down 
	,a.org_patient_pay as Org_Patient_Pay
    ,a.payor_patient_pay as Payor_Patient_Pay
    ,a.unexplained as Unexplained
from  revrec_production.closing_monthly_summary_records a 
left join  revrec_production.members b on a.member_ID = b.id
where a.month > '2019-05-01' and 
a.closing_record_id = "93"  and month < "2019-09-01" and a.id not in ("88468188"
,"90237633"
,"90264690"
,"90292008"
,"90319417"
,"90175134"
,"90200434"
,"90225704"
,"90251065"
,"90278074"
,"90305169")
;


select * from monthly_summary_records where month > '2019-05-01' ;

desc rating_categories;
select * from rating_categories;
select distinct description, modifier, legacy_code from rating_categories;
select max(length(legacy_code)) as maxlen_LegacyCode from rating_categories;
