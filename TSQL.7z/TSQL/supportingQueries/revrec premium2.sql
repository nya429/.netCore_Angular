Declare 
	@assessmentdate as datetime,
	@nextmonth as datetime
	
set @assessmentdate = '8/1/19' --set appropriately	
set	@nextmonth = '9/1/19'


delete from [PremiumReceivable].[dbo].[Medicaid_Reconciliation_History] where assessment_date = @assessmentdate

Insert into [PremiumReceivable].[dbo].[Medicaid_Reconciliation_History]
(member_id
,member_month
,Assessment_Date
,MpMemberId
,Org_Rating_Category
,Payor_Rating
,Contract_Rate
,Org_Premium
,Payor_Premium
,Org_Spend_Down
,Payor_Spend_Down
,Org_Patient_Pay
,Payor_Patient_Pay
,Unexplained)


select * from openquery(REVREC,
'select      case when a.member_id < 0 then cast(a.member_id as char) else (b.unique_identifier-5364521034)
end as member_id, a.month as member_month,"2019-08-01" as Assessment_Date
            ,b.source_identifier as MpMemberId,(
                        select c.legacy_code 
                        from  revrec_production.rating_categories c 
                        where a.org_rating_category_id = c.id) as Org_Rating_Category,   
                                    (select c.legacy_code 
                        from  revrec_production.rating_categories c 
                        where a.payor_rating_category_id = c.ID) as Payor_Rating ,a.payor_rating_category_rate as Contract_Rate ,a.org_premium as Org_Premium
            ,a.payor_premium as Payor_Premium,a.org_spenddown as Org_Spend_Down,a.payor_spenddown as Payor_Spend_Down 
            ,a.org_patient_pay as Org_Patient_Pay,a.payor_patient_pay as Payor_Patient_Pay,a.unexplained as Unexplained
from  revrec_production.closing_monthly_summary_records a left join 
 revrec_production.members b on a.member_ID = b.id
where a.closing_record_id = "93"  and month < "2019-09-01" and a.id not in ("88468188"
,"90237633"
,"90264690"
,"90292008"
,"90319417"
,"90175134"
,"90200434"
,"90225704"
,"90251065"
,"90278074"
,"90305169")
') 

--and a.id not in ("71972966","72000026","72027348","72054761","71935771"
--,"71961039","71986401","72013408","72040506","71910472")


--update [PremiumReceivable].[dbo].[Medicaid_Reconciliation_History] 
--set member_id = a.MemberID
--from [MPFinanceData].[dbo].[Members]a inner join
--[PremiumReceivable].[dbo].[Medicaid_Reconciliation_History] f
--on a.MPMemberID = f.mpmemberid
--where f.assessment_date = '9/1/14' and f.member_id like 'N0%'





--update [PremiumReceivable].[dbo].[Medicaid_Reconciliation_History] 
--set member_id = n.TEXT2-5364521034
--from [srvmedsql01].[MPSnapshotProd].[dbo].[NAME] n  inner join
--[PremiumReceivable].[dbo].[Medicaid_Reconciliation_History] f
--on n.NAME_ID = f.mpmemberid
--where f.assessment_date = '9/1/14' and f.member_id like 'N0%'
--+
-- and a.monthly_summary_record_id not in("1835167", "1867741",
--"1900216", "1932869", "1965558", "1919434", "1952168"


select * from [PremiumReceivable].[dbo].[Medicaid_Reconciliation_History] f where f.assessment_date = '8/1/19'
--and member_id = -5364521034
 and f.member_month = '8/1/19'
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
-- /1/19'--and org_premium <> payor_premium and org_patient_pay = 0

-- update [PremiumReceivable].[dbo].[Medicaid_Reconciliation_History] set member_id = -215  where assessment_date = '6/1/18'
--and member_id = -5364521034


--update [PremiumReceivable].[dbo].[Medicaid_Reconciliation_History] set member_id = '-10' where member_id ='N00005793483'
--update [PremiumReceivable].[dbo].[Medicaid_Reconciliation_History] set member_id = '-11' where member_id ='N00006728079'
--update [PremiumReceivable].[dbo].[Medicaid_Reconciliation_History] set member_id = '-12' where member_id ='N00008087315'

--Delete from [PremiumReceivable].[dbo].[Medicaid_Reconciliation_History]  where assessment_date = '9/1/14'
