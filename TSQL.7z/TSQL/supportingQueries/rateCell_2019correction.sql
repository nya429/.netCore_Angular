use revRec

/*
-- Rates to be altered:

SCO	CND	Bos	1/1/2019	6/30/2019	 $2,371.40 
> SCO	CND	Bos	7/1/2019	12/31/2019	 $2,378.58 
SCO	CND	Non	1/1/2019	6/30/2019	 $2,671.68 
> SCO	CND	Non	7/1/2019	12/31/2019	 $2,620.43 
SCO	CNM	Bos	1/1/2019	6/30/2019	 $3,648.28 
SCO	CNM	Bos	7/1/2019	12/31/2019	 $3,648.28 
SCO	CNM	Non	1/1/2019	6/30/2019	 $3,842.52 
> SCO	CNM	Non	7/1/2019	12/31/2019	 $3,966.47 

*/



DECLARE @returnValue as INT, @NewID int, @RetCd int
	
EXEC @returnValue = [dbo].[spUpdateRateCard] 
	  @eventUserID    = 2 
	, @RateCardID     = 9
	, @CCARateCellID  = 7
	, @CCARegionID    = 4
	, @Amount         = 2378.58
	, @StartDate      = '2019-07-01' 
	, @EndDate        = '2019-12-31'
	, @RateCardLabel  = ''
	-- , @Product = 'SCO'
	, @ActiveFlag = 1 -- default to 1 for active

	-- , @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output

PRINT @returnValue 
PRINT @NewID 
PRINT @RetCd  


-- DECLARE @returnValue as INT, @NewID int, @RetCd int
	
EXEC @returnValue = [dbo].[spUpdateRateCard] 
	  @eventUserID    = 2 
	, @RateCardID     = 11
	, @CCARateCellID  = 7
	, @CCARegionID    = 5
	, @Amount         = 2620.43
	, @StartDate      = '2019-07-01' 
	, @EndDate        = '2019-12-31'
	, @RateCardLabel  = ''
	-- , @Product = 'SCO'
	, @ActiveFlag = 1 -- default to 1 for active

	-- , @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output

PRINT @returnValue 
PRINT @NewID 
PRINT @RetCd  


-- DECLARE @returnValue as INT, @NewID int, @RetCd int
	
EXEC @returnValue = [dbo].[spUpdateRateCard] 
	  @eventUserID    = 2 
	, @RateCardID     = 22
	, @CCARateCellID  = 13
	, @CCARegionID    = 5
	, @Amount         = 3966.47
	, @StartDate      = '2019-07-01' 
	, @EndDate        = '2019-12-31'
	, @RateCardLabel  = ''
	-- , @Product = 'SCO'
	, @ActiveFlag = 1 -- default to 1 for active

	-- , @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output

PRINT @returnValue 
PRINT @NewID 
PRINT @RetCd  

-- validation
select * from vwratecard where CCARateCell = 'CND'
select * from vwratecard where CCARateCell = 'CNM'
select * from UserEventLog order by EventID desc

/*
-- additional validation
select * from vwRateCard order by RateCardID desc
select * from ratecard   order by RateCardID desc
exec spGetRateCard
select * from ExecutionLog order by ExecutionLogID desc
*/
