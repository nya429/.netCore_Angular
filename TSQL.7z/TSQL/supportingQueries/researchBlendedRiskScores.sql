use pdrin

select * from sys.tables order by name

select top 10 * from MMIS8200MDetail
where capitationmonthyear >= '2019-07-01'
and ratecell = 'CNM2'

