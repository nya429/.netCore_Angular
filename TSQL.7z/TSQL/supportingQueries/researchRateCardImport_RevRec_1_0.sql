
select  
  rc.description
, rc.modifier
, rc.alternate_code
, rc.alternate_modifier
, rcr.start_date
, rcr.end_date
, rcr.rate
from rating_categories as rc
inner join rating_category_rates as rcr on rcr.rating_category_id = rc.id
where start_date >= '2019-01-01'
or end_date >= '2019-01-01'
order by rc.description
, rc.modifier
, rcr.start_date
, rcr.end_date
, rcr.rate
;

