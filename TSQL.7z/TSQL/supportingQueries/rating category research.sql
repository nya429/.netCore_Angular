use revrec

/*
1.75
Rating Category	                                  Eastern	    Western	        The Cape	Statewide1
C1:  Community Other	                    $     189.26 	 $   168.22 	 $   181.57 	 $        180.86 
C2A: Community High Behavioral Health	    $     601.87 	 $   523.02 	 $   663.37 	 $        570.74 
C2B: Community Very High Behavioral Health	$     905.56 	 $   785.34 	 $   999.33 	 $        855.11 
C3A: High Community Need	                $  2,828.11 	 $2,854.92 	     $3,148.23 	     $     2,851.35 
C3B: Very High Community Need	            $  6,691.48 	 $6,755.90 	     $7,451.74 	     $     6,744.54 
C3C: Transitional Living Need	            $  8,506.43 	 $8,429.62 	     $7,059.46 	     $     8,430.39 
F1:  Facility-Based Care	                $10,077.61 	     $9,511.42 	     $8,374.37 	     $     9,772.22 

1.5
Rating Category	                                  Eastern	    Western	        The Cape	Statewide1
C1:  Community Other	                    $     186.42 	 $   165.69 	  $   178.84 	 $        178.15 
C2A: Community High Behavioral Health	    $     592.84 	 $   515.17 	  $   653.42 	 $        562.18 
C2B: Community Very High Behavioral Health	$     891.97 	 $   773.56 	  $   984.34 	 $        842.29 
C3A: High Community Need	                $  2,785.69 	 $2,812.10 	      $3,101.01 	 $     2,808.58 
C3B: Very High Community Need	            $  6,591.10 	 $6,654.56 	      $7,339.96 	 $     6,643.38 
C3C: Transitional Living Need	            $  8,378.84 	 $8,303.18 	      $6,953.57 	 $     8,303.93 
F1:  Facility-Based Care	                $  9,926.45 	 $9,368.75 	      $8,248.75 	 $     9,625.64 


MMIS	Region	2019 - Q1/Q2 	�2019 - Q3/Q4 
�Rate Cells 		PMPM Rate� 	�PMPM Rate� 
			
�CWD2	Boston	$��������� 328.36	�$��������� 328.36
�CWD2	Non- Boston	$��������� 368.61	�$��������� 368.61
�CWM2	Boston	$��������� 882.89	�$��������� 882.89
�CWM2	Non- Boston	$��������� 869.65	�$��������� 869.65
			
�CAD2	Boston	$��������� 549.04	�$��������� 549.04
�CAD2	Non- Boston	$��������� 548.62	�$��������� 548.62
�CAM2	Boston	$������ 1,615.02	�$� �����1,615.02
�CAM2	Non- Boston	$������ 1,417.50	�$������ 1,417.50
			
�CND2	Boston	$������ 2,371.40	�$������ 2,315.98
�CND2	Non- Boston	$������ 2,671.68	�$������ 2,609.58
�CNM2	Boston	$������ 3,648.28	�$������ 3,648.28
�CNM2	Non- Boston	$������ 3,842.52	�$������ 3,842.52
			
�TND2	Boston	$������ 2,371.40	�$������ 2,315.98
�TND2	Non- Boston	$������ 2,671.68	�$������ 2,609.58
�TNM2	Boston	$������ 3,648.28	�$������ 3,648.28
�TNM2	Non- Boston	$������ 3,842.52	�$������ 3,842.52
			
�I1D2	Statewide	$������ 4,460.29	�$������ 4,460.29
�I1M2	Statewide	$������ 4,460.29	�$������ 4,460.29
			
�I2D2	Statewide	$������ 6,381.46	�$������ 6,381.46
�I2M2	Statewide	$������ 6,381.46	�$������ 6,381.46
			
�I3D2	Statewide	$������ 8,196.99	�$������ 8,196.99
�I3M2	Statewide	$������ 8,196.99	�$������ 8,196.99
			
�TCD2	Statewide	$������ 4,460.29	�$������ 4,460.29
�TCM2	Statewide	$������ 4,460.29	�$������ 4,460.29




-- query for ETL - PRD to DEV refresh
select 
ReportName, RunDateTime, PaymentPeriodStart, PaymentPeriodEnd, MCPName, MCPID, FooterCapitationMonthYear, UnduplicatedMemberCount, TotalPailCapitatedAmount, CCAFileLocation
from PDRIn.DBO.MMIS8200MHeader
where FooterCapitationMonthYear >= '2019-01-01'

select 
CCADetailOrder, ReportName, RunDateTime, PageNumber, PaymentPeriodStart, PaymentPeriodEnd, MemberID, LastName, FirstName, MiddleInitial, Suffix, EffectiveDate, EndDate, CapitationMonthYear, RateCell, Legacy, MCRegion, BaseCapitationAmount, PatientPayAmountN, PatientPayAmountSCO, PaidCapitationAmount, CapitationReason, CCACheckAmount
from PDRIn.DBO.MMIS8200MDetail
where CapitationMonthYear >= '2019-01-01'
*/




-- build region map from matcihng rates

if object_id('tempdb..#rateCellAmounts') is not null
	drop table #rateCellAmounts


-- rate combinatinos
select 
RateCell	
, BaseCapitationAmount	
, COUNT(*) AS countByRateCardAmounts
into #rateCellAmounts
from PDRIn.DBO.MMIS8200MDetail
where PatientPayAmountN	= 0.00
and PatientPayAmountSCO = 0.00
and PaidCapitationAmount > 0.00
GROUP BY 
RateCell	
, BaseCapitationAmount	
order by 	
RateCell	
, BaseCapitationAmount	


if object_id('tempdb..#rateRegionAmounts') is not null
	drop table #rateRegionAmounts



-- rate and region combination
select 
RateCell	
, MCRegion	
, BaseCapitationAmount	
, case 
	when right(ReportName, 1) = 'A' and datepart(month,CapitationMonthYear) between 1 and 6 then 'Q12'
	when right(ReportName, 1) = 'A' and datepart(month,CapitationMonthYear) between 7 and 12 then 'Q34'
	ELSE 'Q1234'
END AS QuarterYear
-- , datepart(month,CapitationMonthYear)
, Year(CapitationMonthYear) as CapYear
, COUNT(*) AS countByRateCardAmounts
into #rateRegionAmounts
from PDRIn.DBO.MMIS8200MDetail
where PatientPayAmountN	= 0.00
and PatientPayAmountSCO = 0.00
and PaidCapitationAmount > 0.00
and CapitationMonthYear >= '2019-01-01'
GROUP BY 
RateCell	
, MCRegion	
, BaseCapitationAmount
, Year(CapitationMonthYear) 	
, case 
	when right(ReportName, 1) = 'A' and datepart(month,CapitationMonthYear) between 1 and 6 then 'Q12'
	when right(ReportName, 1) = 'A' and datepart(month,CapitationMonthYear) between 7 and 12 then 'Q34'
	ELSE 'Q1234'
END 
-- , datepart(month,CapitationMonthYear)






select CCARateCell, CCARegion, QuarterYear, count(*) as dupCheck
from (
	select distinct
	rc.CCARateCell
	, reg.CCARegion
	, rate.QuarterYear
	, rate.BaseCapitationAmount
	from #rateRegionAmounts as rate
	inner join vwRegionMap as reg on reg.MMISRegion = rate.MCRegion
	inner join vwRateCellMap as rc on rc.MMISRateCell = rate.RateCell
	inner join CCARateCells as ccaRc on ccaRc.CCARateCellID = rc.CCARateCellID
) as d
group by 
  d.CCARateCell
, d.CCARegion
, d.QuarterYear
order by dupCheck desc
, CCARateCell
, CCARegion
, d.QuarterYear



select 
	  rc.CCARateCellID                          as CCARateCellID 
	, reg.CCARegionID			                as CCARegionID   
	, '2019-01-01'				                as StartDate     
	, '2019-12-31'				                as EndDate       
	, rate.BaseCapitationAmount	                as Amount        
	, rc.CCARateCell             
		+ '_' + reg.CCARegion 
		+ '_' + cast(rate.CapYear as char(4))	as RateCardLabel 
	, case ccaRc.Product 
		when 'SCO' then SUBSTRING(rc.ccaRateCell, 3, 1) 
		when 'ICO' then 'D' 
		else NULL 
	end 	                                    as Eligibility   
	, ccaRc.Product                             as Product       
from #rateRegionAmounts as rate
	inner join vwRegionMap as reg on reg.MMISRegion = rate.MCRegion
	inner join vwRateCellMap as rc on rc.MMISRateCell = rate.RateCell
	inner join CCARateCells as ccaRc on ccaRc.CCARateCellID = rc.CCARateCellID
where rc.CCARateCell in ('CND', 'TND')
order by rc.CCARateCell
, reg.CCARegion











-- mapped CCA rate and region combinations
	

select 
	RateCell
	, BaseCapitationAmount 
from #rateCellAmounts

select top 10 * from MMISRegions 
select top 10 * from MMISRateCells
select top 10 * from RegionMap  
select top 10 * from RateCellMap 

select distinct
rc.CCARateCell
, ccaRc.Product
, reg.CCARegion
, rate.BaseCapitationAmount
, rate.CapYear
--  select
-- 	  rate.RateCell	
-- 	, rate.BaseCapitationAmount
-- 	, rate.CapYear
-- 	, rate.MCRegion	

from #rateRegionAmounts as rate
inner join vwRegionMap as reg on reg.MMISRegion = rate.MCRegion
inner join vwRateCellMap as rc on rc.MMISRateCell = rate.RateCell
inner join CCARateCells as ccaRc on ccaRc.CCARateCellID = rc.CCARateCellID

-- MISSING 16?
-- inner join MMISRegions as reg on reg.MMISRegion = rate.MCRegion
-- inner join MMISRateCells as rc on rc.MMISRateCell = rate.RateCell
-- inner join RegionMap as regMap on regMap.MMISRegionID = reg.MMISRegionID
-- inner join RateCellMap as rcMap on rcMap.MMISRateCellID = rc.MMISRateCellID


order by 	RateCell	
	, BaseCapitationAmount
	, MCRegion	


SELECT *
from #rateCellAmounts AS r
INNER JOIN #rateRegionAmounts AS rr 
	on rr.RateCell = r.RateCell
	and rr.BaseCapitationAmount = r.BaseCapitationAmount


-- full distinct amounts
select 
RateCell	
-- , Legacy	
, MCRegion	
, BaseCapitationAmount	
-- , PatientPayAmountN	
-- , PatientPayAmountSCO	
-- , PaidCapitationAmount
, COUNT(*) AS countByRateCardAmounts
from PDRIn.DBO.MMIS8200MDetail
where PatientPayAmountN	= 0.00
and PatientPayAmountSCO = 0.00
and PaidCapitationAmount > 0.00
-- and BaseCapitationAmount = PaidCapitationAmount
GROUP BY 
RateCell	
-- , Legacy	
, MCRegion	
, BaseCapitationAmount	
-- , PatientPayAmountN	
-- , PatientPayAmountSCO	
-- , PaidCapitationAmount



SELECT * FROM OPENQUERY(revrec, 'SELECT 
id
, rating_category_id
, cast(start_date as char(20)) as start_date
, cast(end_date as char(20)) as end_date
, rate
, cast(archived_at as char(20)) as archived_at
, cast(created_at as char(20)) as created_at
, cast(updated_at as char(20)) as updated_at
FROM rating_category_rates limit 1000 ;')


SELECT * FROM OPENQUERY(revrec, 'SELECT 
id
, program_id
, description
, modifier
, alternate_code
, alternate_description
, alternate_modifier
, legacy_code
, legacy_description
, legacy_modifier
, cast(archived_at as char(20)) as archived_at
, cast(created_at as char(20)) as created_at
, cast(updated_at as char(20)) as updated_at
FROM rating_categories limit 1000 ;')

SELECT * FROM OPENQUERY(revrec, 'SELECT 
id
, member_id
, rating_category_id
, cast(start_date as char(20)) as start_date
, cast(end_date as char(20)) as end_date
, cast(archived_at as char(20)) as archived_at
, cast(created_at as char(20)) as created_at
, cast(updated_at as char(20)) as updated_at
FROM rating_category_records limit 1000 ;')

