use RevRec


select 
  d.DiscrepancyID
, d.MonthlySummaryRecordID
, d.MasterPatientID 
, d.MemberMonth
, d.TypeRateCell
, d.TypeRegion
, d.TypePatientPay
, d.TypePatientSpendDown
, d.TypePaymentError
, mpm.MMIS_ID	
, mpm.CCAID	
, mpm.MemberFirstName	
, mpm.MemberMiddleName	
, mpm.MemberLastName
-- select * 
from Discrepancies as d
inner join MasterPatientManagement as mpm on mpm.MasterPatientID = d.MasterPatientID
-- where TypeRateCell			= 1
/*
DiscrepancyID	MonthlySummaryRecordID	MasterPatientID
23480	287340	3 -- confirmed
25631	321463	3 -- confirmed
27541	349271	3 -- confirmed
30434	385732	3 -- confirmed
33843	413548	3 -- confirmed
36639	441753	3 -- confirmed
40807	473587	3 -- confirmed
44062	507485	3 -- confirmed
48488	544374	3 -- confirmed
51564	573565	3 -- confirmed
47951	548678	412 -- confirmed
51793	575652	412 -- confirmed
*/
-- where TypeRegion			= 1
/*
DiscrepancyID	MonthlySummaryRecordID	MasterPatientID
10196	13795	27 -- confirmed
9641	3719	76 -- confirmed
10741	28554	76 -- confirmed
12211	56056	76 -- confirmed
13347	77021	76 -- confirmed
14699	107582	76 -- confirmed
16111	130268	76 -- confirmed
35585	426111	76 -- confirmed
39173	460640	76 -- confirmed
21620	245692	76 -- confirmed
22692	286708	76 -- confirmed
24584	301930	76 -- confirmed
26786	333180	76 -- confirmed
29608	364655	76 -- confirmed
32307	395854	76 -- confirmed
17446	162162	76 -- confirmed
18706	187623	76 -- confirmed
20508	216239	76 -- confirmed
*/
-- where TypePatientPay		= 1 
/*
DiscrepancyID	MonthlySummaryRecordID	MasterPatientID
9872	9002	997 -- confirmed
11353	33998	997 -- confirmed
12383	63154	997 -- confirmed
15101	115605	1205 -- confirmed
16385	141385	1205 -- confirmed
17970	170449	1205 -- confirmed
32923	406162	1205 -- confirmed
36027	442297	1205 -- confirmed
*/
-- where TypePatientSpendDown	= 1
/*
DiscrepancyID	MonthlySummaryRecordID	MasterPatientID
18612	183900	4802 -- confirmed
*/
where TypePaymentError      = 1
/*
DiscrepancyID	MonthlySummaryRecordID	MasterPatientID
9641	3719	76 -- confirmed
10741	28554	76 -- confirmed
12211	56056	76 -- confirmed
39173	460640	76 -- confirmed
32307	395854	76 -- confirmed
35585	426111	76 -- confirmed
24584	301930	76 -- confirmed
26786	333180	76 -- confirmed
29608	364655	76 -- confirmed
20508	216239	76 -- confirmed
21620	245692	76 -- confirmed
22692	286708	76 -- confirmed
17446	162162	76 -- confirmed
18706	187623	76 -- confirmed
13347	77021	76 -- confirmed
14699	107582	76 -- confirmed
16111	130268	76 -- confirmed
10017	17628	82 -- confirmed
11106	38669	82 -- confirmed
12402	59551	82 -- confirmed
13937	86346	82 -- confirmed
15280	113578	82 -- confirmed
16597	142296	82 -- confirmed
17889	171856	256 -- confirmed
19225	199013	256 -- confirmed
20899	227489	256 -- confirmed
21917	254948	256 -- confirmed
23418	284730	256 -- confirmed
24997	315234	256 -- confirmed
*/
