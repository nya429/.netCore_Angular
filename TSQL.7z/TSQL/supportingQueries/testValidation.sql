use RevRec


if object_id('tempdb..#prepMSR') is not null
	drop table #prepMSR

	select 
		memMMIS.MasterPatientID as MasterPatientID
		, pd.CapitationMonthYear as MemberMonth
		, pd.MemberID as MMIS_ID

		-- conversion for varchar > numeric errors
		, (ratCCA.Amount - case when memcca.PatientPay like '%[0-9].[0-9][0-9]' then cast(memcca.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when memcca.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(memcca.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end)  
			- (pd.BaseCapitationAmount - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00)) as Variance 
		, (pd.BaseCapitationAmount - ratMMIS.Amount) as PaymentError  -- Payment error SHOULD NOT be part of the variance calculation

		-- from PatientPayDetail... what the state actually says they paid, based on file
		, pd.BaseCapitationAmount as BaseCapitationAmount	
		, pd.PatientPay as PatientPayAmountN		
		, pd.SpendDown as PatientPayAmountSCO	
		, pd.Paid as PaidCapitationAmount
		, pd.Remit	
	

		, memCCA.CCARateCellID as CCARateCellID 
		, memCCA.CCARegionID as CCARegionID 
		-- conversion for varchar > numeric errors
		, case when memCCA.PatientPay like '%[0-9].[0-9][0-9]' then cast(memCCA.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end as CCAPatientPay 
		, case when memCCA.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(memCCA.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end as CCAPatientSpendDown 


		-- CCA's expected based on current member's rate cell and region in MP
		, memCCA.RateCardID as CCARateCardID 
		, ratCCA.Amount as CCAAmount 

		-- conversion for varchar > numeric errors
		, (isnull(ratCCA.Amount,0.00) - case when memcca.PatientPay like '%[0-9].[0-9][0-9]' then cast(memcca.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when memcca.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(memcca.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end) as CCANetAmount 
		
		, ratMMIS.CCARateCellID as MMISRateCellID 
		, ratMMIS.CCARegionID as MMISRegionID 
		, pd.PatientPay as MMISPatientPay 
		, pd.SpendDown as MMISPatientSpendDown 
	
		-- expected payment based on state's rate rate cell and region
		, ratmmis.RateCardID as MMISRateCardID 
		, ratMMIS.Amount as MMISAmount 
		, (isnull(ratMMIS.Amount,0.00) - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00))  as MMISNetAmount 

	-- from PatientPayDetail as ppd
	-- select top 10 * 
	into #prepMSR

	from vwPaymentDetail as pd
	left join MMISMemberData as memMMIS on memMMIS.MMIS_ID    = pd.MemberID
	left join vwRateCellMap	 as rcMap   on rcMap.MMISRateCell = pd.RateCell and rcMap.ActiveFlag = 1
	left join vwRegionMap    as regMap  on regMap.MMISRegion  = pd.MCRegion and regMap.ActiveFlag = 1
	-- note overlaps in test rate card data
	left join vwRateCard     as ratMMIS	
		on  ratMMIS.CCARateCellID = rcMap.CCARateCellID
		and ratMMIS.CCARegionID = regMap.CCARegionID
		and pd.CapitationMonthYear between ratMMIS.StartDate and ratMMIS.EndDate
		and ratMMIS.ActiveFlag = 1
	left join vwCCAMemberData as memCCA ON memCCA.MMIS_ID = memMMIS.MMIS_ID
		and pd.CapitationMonthYear between memCCA.RatingCategoryStartDate and memCCA.RatingCategoryEndDate
		and pd.CapitationMonthYear between memCCA.RegionStartDate AND memCCA.RegionEndDate
		and memCCA.ActiveFlag = 1
	left join vwRateCard     as ratCCA on ratCCA.RateCardID = memCCA.RateCardID
	where pd.rnCurrentPaidAmount = 1
	
	select * from #prepMSR
	exec spGetDiscrepancyList
	
	select masterPatientID, MemberMonth, count(*) as dupCheck 
	from Discrepancies
	group by masterPatientID, MemberMonth
	having count(*) > 1

	select masterPatientID, MemberMonth, count(*) as dupCheck 
	from monthlysummaryRecord
	group by masterPatientID, MemberMonth
	having count(*) > 1



select * from sys.tables as tbl order by name

select 'ExecutionLog' as tblName , * from ExecutionLog     order by ExecutionLogID desc
select 'listParameters' as tblName , * from listParameters order by parameterName


select top 10 'CCAMemberData' as tblName , * from CCAMemberData
select top 10 'CCAMemberSpanEnrollment' as tblName , * from CCAMemberSpanEnrollment
select top 10 'CCAMemberSpanPatientPay' as tblName , * from CCAMemberSpanPatientPay
select top 10 'CCAMemberSpanPatientSpendDown' as tblName , * from CCAMemberSpanPatientSpendDown
select top 10 'CCAMemberSpanRatingCategory' as tblName , * from CCAMemberSpanRatingCategory
select top 10 'CCAMemberSpanRegion' as tblName , * from CCAMemberSpanRegion
select top 10 'CCARateCells' as tblName , * from CCARateCells
select top 10 'CCARegions' as tblName , * from CCARegions
select top 10 'Discrepancies' as tblName , * from Discrepancies
select top 10 'DiscrepanciesComments' as tblName , * from DiscrepanciesComments
select top 10 'DiscrepanciesCommentsHistory' as tblName , * from DiscrepanciesCommentsHistory
select top 10 'DiscrepanciesHistory' as tblName , * from DiscrepanciesHistory
select top 10 'DiscrepancyCategories' as tblName , * from DiscrepancyCategories
select top 10 'DiscrepancyStatuses' as tblName , * from DiscrepancyStatuses
select top 10 'MemberList' as tblName , * from MemberList
select top 10 'MemberMap' as tblName , * from MemberMap
select top 10 'MMISFileProcessing' as tblName , * from MMISFileProcessing
select top 10 'MMISMemberData' as tblName , * from MMISMemberData
select top 10 'MMISMultiMap' as tblName , * from MMISMultiMap
select top 10 'MMISRateCells' as tblName , * from MMISRateCells
select top 10 'MMISRegions' as tblName , * from MMISRegions
select top 10 'MonthlySummaryRecord' as tblName , * from MonthlySummaryRecord
select top 10 'PaymentDetailPaid' as tblName , * from PaymentDetailPaid
select top 10 'PaymentDetailPatientPay' as tblName , * from PaymentDetailPatientPay
select top 10 'PaymentDetailRemit' as tblName , * from PaymentDetailRemit
select top 10 'PaymentDetailSpendDown' as tblName , * from PaymentDetailSpendDown
select top 10 'RateCard' as tblName , * from RateCard
select top 10 'RateCellMap' as tblName , * from RateCellMap
select top 10 'RegionMap' as tblName , * from RegionMap
select top 10 'UserAccessLog' as tblName , * from UserAccessLog
select top 10 'UserEventLog' as tblName , * from UserEventLog
select top 10 'UserRoleMap' as tblName , * from UserRoleMap
select top 10 'UserRoles' as tblName , * from UserRoles
select top 10 'Users' as tblName , * from Users