use RevRec


select rc.* from vwRateCard as rc -- 95

select rc.* 
, rcm.MMISRateCellID, rcm.MMISRateCell
, rm.MMISRegionID, rm.MMISRegion

from vwRateCard as rc -- 95
inner join vwRateCellMap as rcm on rcm.CCARateCellID = rc.CCARateCellID -- 155
inner join vwRegionMap as rm on rm.CCARegionID = rc.CCARegionID -- 282

order by CCARateCell, CCARegion, StartDate, EndDate


select * from MMISRegions order by Product, MMISRegion
select * from CCARegions  order by Product, CCARegion

select * from MMISRateCells order by Product, MMISRateCell
select * from CCARateCells	order by Product, CCARateCell

select * from vwRateCellMap
select * from vwRegionMap




select MMISRateCell as rc from MMISRateCells
except
select CCARateCell as rc from CCARateCells -- CCA Rate cells mirror MMIS Rate cells.  However, MMIS adds extra that need to be mapped

/*
CAD2
CAM2
CND2
CNM2
CWD2
CWM2
I1D2
I1M2
I2D2
I2M2
I3D2
I3M2
TCD2
TCM2
TND2
TNM2
*/


