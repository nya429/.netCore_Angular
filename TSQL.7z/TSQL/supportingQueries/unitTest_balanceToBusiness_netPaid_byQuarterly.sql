use RevRec

	if object_id('tempdb..#calcNetRemit') is not null
		drop table #calcNetRemit
	
	select 

		--   f.MMISFileProcessID	
		-- , f.ReportName	
		  f.Product	
		, f.ReportType	
		, f.ReportMonth	
		-- , f.PaymentPeriodStart	
		-- , f.PaymentPeriodEnd	
		-- , f.ReportRowCount	
		-- , f.ProcessIndicator	
		-- , f.IdentifiedDate	
		-- , f.ProcessedDate

		, r.MemberID
		, r.CapitationMonthYear
		, r.RateCell
		, r.MCRegion
		, r.BaseCapitationAmount
		, r.Paid
		, lag(r.Paid)            over(partition by product, MemberID, CapitationMonthYear, RateCell, MCRegion order by reportMonth) as lag_RemitCapMonth
		, lag(r.PaymentIndicator) over(partition by product, MemberID, CapitationMonthYear, RateCell, MCRegion order by reportMonth) as lag_PaymentIndicator
		, r.CountPayCode - r.CountRetractionCode as PaymentIndicator -- 1: Payment Code prevailed; 2: Retraction Code prevailed
		-- debug
		-- , r.CountPayCode 
		-- , r.CountRetractionCode 
		-- , row_number() over(partition by product, MemberID, CapitationMonthYear order by reportMonth desc, remit desc) as rn_LatestMemberMonthProcessed
		-- , dense_rank() over(partition by product, MemberID, CapitationMonthYear order by reportMonth desc, remit desc) as drk_LatestMemberMonthProcessed
		, row_number() over(partition by product, MemberID, CapitationMonthYear order by reportMonth desc) as rn_LatestMemberMonthProcessed
		, dense_rank() over(partition by product, MemberID, CapitationMonthYear order by reportMonth desc) as drk_LatestMemberMonthProcessed

		INTO #calcNetRemit

	from PaymentDetailPaid as r
	inner join MMISFileProcessing as f on f.MMISFileProcessID = r.MMISFileProcessID
	-- where r.Remit = 0.00 and (r.CountPayCode - r.CountRetractionCode <> 0) -- confirms retractions all results in 0 payment
	-- where r.CapitationMonthYear = '2018-04-01'
	-- order by product, MemberID, CapitationMonthYear , reportMonth desc	




	-- calculate net remit for cap month by report month
	select 
		Product
		, ReportType
		, ReportMonth
		, MemberID
		, CapitationMonthYear
		, RateCell
		, MCRegion
		, BaseCapitationAmount
		, Paid 
		, lag_RemitCapMonth
		, PaymentIndicator
		, lag_PaymentIndicator
		, rn_LatestMemberMonthProcessed
		, drk_LatestMemberMonthProcessed
		, case when ReportType = 'M' then paid when ReportType = 'Q' and lag_RemitCapMonth is null then paid else paid - isnull(lag_RemitCapMonth, paid) end as netPaid -- just 0 out if no difference from last month for quarterly.  Show payment for monthly
	
	from #calcNetRemit
	where CapitationMonthYear = '2018-04-01'
	-- where memberID = '100007777525'
	AND MemberID = '100007782591'
	order by product, MemberID, CapitationMonthYear , reportMonth 


	select 
		Product
		, ReportMonth
		, CapitationMonthYear

		, sum(
			case when ReportType = 'M' then paid when ReportType = 'Q' and lag_RemitCapMonth is null then paid else paid - isnull(lag_RemitCapMonth, paid) end 
		) as netPaid -- just 0 out if no difference from last month for quarterly.  Show payment for monthly
	from #calcNetRemit
	where CapitationMonthYear = '2019-05-01' and Product = 'ICO'
	group by 
		Product
		, ReportMonth
		, CapitationMonthYear


	-- see raw data 
	select * from PDRIn.dbo.MMIS8200MDetail 
	-- where memberID = '100007777525'
	where MemberID = '100007782591'
	order by capitationmonthyear, paymentPeriodend
	, substring(ReportName, 10, 1)

		
	-- lag to 0 pay