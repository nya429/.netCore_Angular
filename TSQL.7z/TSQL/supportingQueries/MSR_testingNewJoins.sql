use RevRec

if object_id('tempdb..#testMSR') is not null
	drop table #testMSR

	select 
		mpm.MasterPatientID as MasterPatientID
		, isnull(pd.CapitationMonthYear, ep.MasterMemberMonth) as MemberMonth
		-- , pd.MemberID as MMIS_ID
		, mpm.MMIS_ID as MMIS_ID

		-- conversion for varchar > numeric errors
		, (ep.Amount - case when ep.PatientPay like '%[0-9].[0-9][0-9]' then cast(ep.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when ep.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(ep.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end)  
			- (pd.BaseCapitationAmount - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00)) as Variance 
		, (pd.BaseCapitationAmount - pd.Amount) as PaymentError  -- Payment error SHOULD NOT be part of the variance calculation

		-- from PatientPayDetail... what the state actually says they paid, based on file
		, pd.BaseCapitationAmount as BaseCapitationAmount	
		, pd.PatientPay as PatientPayAmountN		
		, pd.SpendDown as PatientPayAmountSCO	
		, pd.Paid as PaidCapitationAmount
		, pd.Remit	
	

		, ep.CCARateCellID as CCARateCellID 
		, ep.CCARegionID as CCARegionID 
		-- conversion for varchar > numeric errors
		, case when ep.PatientPay like '%[0-9].[0-9][0-9]' then cast(ep.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end as CCAPatientPay 
		, case when ep.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(ep.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end as CCAPatientSpendDown 


		-- CCA's expected based on current member's rate cell and region in MP
		, ep.RateCardID as CCARateCardID 
		, ep.Amount as CCAAmount 

		-- conversion for varchar > numeric errors
		, (isnull(ep.Amount,0.00) - case when ep.PatientPay like '%[0-9].[0-9][0-9]' then cast(ep.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when ep.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(ep.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end) as CCANetAmount 
		
		, pd.CCARateCellID as MMISRateCellID 
		, pd.CCARegionID as MMISRegionID 
		, pd.PatientPay as MMISPatientPay 
		, pd.SpendDown as MMISPatientSpendDown 
	
		-- expected payment based on state's rate rate cell and region
		, pd.RateCardID as MMISRateCardID 
		, pd.Amount as MMISAmount 
		, (isnull(pd.Amount,0.00) - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00))  as MMISNetAmount 
	into #testMSR

	select *
	-- select count(*) 
	from MasterPatientManagement as mpm 
	full outer join ExpectedPayments as ep 
		on (ep.CCAID = mpm.CCAID or ep.MMIS_ID = mpm.MMIS_ID) 
	full outer join PaymentDetail as pd -- do we get the rate card here and call it a day?
		-- on pd.rnCurrentPaidAmount = 1 -- staging takes care of this
		on pd.MemberID = mpm.MMIS_ID 
		-- and pd.CapitationMonthYear = ep.MasterMemberMonth -- this loses MMIS data... how to join dates on both
		-- build this outside 
	where mpm.MasterPatientID in (
		10 -- MMIS
		-- , 58132 -- CCA/MMIS - source CCA
		-- , 58150 -- CCAID only
		, 58482 -- CCA/MMIS - source CCA
		, 211   -- '100000059863' -- MMIS only
		, 55846 -- '100000091957' -- MMIS only

	)
	order by mpm.MasterPatientID, ep.MasterMemberMonth

	select mpm.MasterPatientID, ep.MasterMemberMonth 
	from MasterPatientManagement as mpm
	-- inner join ExpectedPayments as ep on (ep.CCAID = mpm.CCAID or ep.MMIS_ID = mpm.MMIS_ID) 
--	inner join ExpectedPayments as ep on ep.CCAID = mpm.CCAID -- or ep.MMIS_ID = mpm.MMIS_ID) 
	inner join ExpectedPayments as ep on ep.MMIS_ID = mpm.MMIS_ID

	-- views vs staged tables: 1:02 minutes vs 0:02 seconds

	-- pre-build this list for performance: total rows: 716299
	select mpm.MasterPatientID, pd.CapitationMonthYear as MemberMonth 
	from MasterPatientManagement as mpm
	inner join PaymentDetail as pd on pd.MemberID = mpm.MMIS_ID -- 683164
	union 
	select mpm.MasterPatientID, ep.MasterMemberMonth as MemberMonth 
	from MasterPatientManagement as mpm
	inner join ExpectedPayments as ep on ep.MMIS_ID = mpm.MMIS_ID -- 618614
	union 
	select mpm.MasterPatientID, ep.MasterMemberMonth as MemberMonth 
	from MasterPatientManagement as mpm
	inner join ExpectedPayments as ep on ep.CCAID = mpm.CCAID -- 195... but expected payment is not missing MMIS_ID on any
	
	


	SELECT count(*) FROM PaymentDetail as pd
	select count(*) from ExpectedPayments as ep


	SELECT MemberID FROM PaymentDetail as pd
	EXCEPT select MMIS_ID from ExpectedPayments as ep

	SELECT * 
	FROM PaymentDetail
	where MemberID in (
		 '100000109312' -- 	26
		,'100000019875' -- 	105
		,'100000059863' -- 	211
		,'100000279248' -- 	253
		,'100000091957' -- 	55846
	)



	select * from MasterPatientManagement
	where MMIS_ID in (
		 '100000059863'
		,'100000091957'
	)


	select *
	-- select count(*) 
	from MasterPatientManagement as mpm 
	inner join ExpectedPayments as ep 
		on (ep.CCAID = mpm.CCAID) or ep.MMIS_ID = mpm.MMIS_ID) 



	left join (
		select distinct CapitationMonthYear as MasterMemberMonth 
		from PaymentDetailPaid as pdp
		cross join (
			select parameterValue as LookbackDate from listParameters where parameterName = 'LookbackDate'
		) as lbd 
		where pdp.CapitationMonthYear >= lbd.LookbackDate
		-- order by MasterMemberMonth 
	) as mm on 


	full outer join PaymentDetail as pd -- do we get the rate card here and call it a day?
		-- on pd.rnCurrentPaidAmount = 1 -- staging takes care of this
		on pd.MemberID = mpm.MMIS_ID 
		and pd.CapitationMonthYear = ep.MasterMemberMonth



select * from MonthlySummaryRecord as msr where CCAPatientPay <> 0.00 and CCAPatientPay is not null

select * 
from MonthlySummaryRecord as msr 
where MMIS_ID IN (
	  '100010248043' -- variance/payment error
	, '100028942264' -- payment error
	, '100013988546' -- QA issue
)
ORDER BY MMIS_ID, MemberMonth

select * from MonthlySummaryRecord as msr 
WHERE MSR.CCARegionID <> MSR.MMISRegionID

SELECT * FROM Discrepancies WHERE MasterPatientID = 49717 -- '100017912732'
EXEC spProcessMemberList


