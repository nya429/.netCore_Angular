
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwMMISRawPayment]


-- validate names are the same in both header and detail
select reportname 
from PDRIn.DBO.MMIS8200MDetail
intersect
select reportname
from PDRIn.DBO.MMIS8200MHeader 

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwMMISRawPayment]') AND type in (N'V'))
DROP VIEW [dbo].[vwMMISRawPayment]
GO

/****** Object:  View [dbo].[vwMMISRawPayment]    Script Date: 07/08/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		
-- Create date: 07/08/2019
-- Description:	

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwMMISRawPayment] AS



select distinct reportname
	, case right(reportname, 1) when 'A' then 'SCO' when 'B' then 'ICO' else NULL end as Product
	, case SUBSTRING(reportname,10,1) when 'M' then 'Monthly' when 'Q' then 'Quarterly' when 'A' then 'Annually' else NULL end as ReportType
	, SUBSTRING(reportname,5,4) as ReportNumber   
from PDRIn.DBO.MMIS8200MDetail
-- all details required are in the detail, as far as report information about product and monthly/quarterly file
-- select distinct reportname, right(reportname, 1) as Product, SUBSTRING(reportname,10,1) as ReportType, SUBSTRING(reportname,5,4) as ReportNumber, mcpid from PDRIn.DBO.MMIS8200MHeader 

select top 100 * from PDRIn.DBO.MMIS8200MHeader 
select top 100 * from PDRIn.DBO.MMIS8200MDetail
-- capitation month year - 3 per quarterly... payment represented by month

GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwMMISRawPayment] TO [Talend] 
GRANT SELECT ON [dbo].[vwMMISRawPayment] TO [Support] 
GO
-- *****************************************************************************************************
