use RevRec

set identity_insert MasterPatientManagement on;


insert into MasterPatientManagement (

	  MasterPatientID    
 	, MMIS_ID      
	-- , CCAID        
	, SourceSystem 

 	, MemberFirstName  
 	, MemberMiddleName 
 	, MemberLastName   
 	, Suffix     

	, ActiveFlag 
	, insertDate 
	, updateDate 
)

select  
	MasterPatientID
	, MMIS_ID
	, 'MMIS' as SourceSystem

	, MemberFirstName
	, MemberMiddleName
	, MemberLastName
	, Suffix

	, ActiveFlag
	, insertDate
	, updateDate

from mmisMemberData;

set identity_insert MasterPatientManagement off;


-- select * from MasterPatientManagement 


-- remove from MMISMemberData

if exists(select * from sys.key_constraints where name = 'PK_MMISMemberData' and object_name(parent_object_id) = 'MMISMemberData')
	alter table MMISMemberData drop constraint PK_MMISMemberData	
GO

if exists(select * from sys.key_constraints where name = 'UQ_MMISMemberData' and object_name(parent_object_id) = 'MMISMemberData')
	alter table MMISMemberData drop constraint UQ_MMISMemberData
GO

IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[MMISMemberData]') AND name = 'MasterPatientID') 
	ALTER TABLE MMISMemberData DROP COLUMN MasterPatientID
GO

IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[MMISMemberData]') AND name = 'MMIS_ID') 
	ALTER TABLE MMISMemberData ALTER COLUMN MMIS_ID char(12) NOT NULL
go 

ALTER TABLE MMISMemberData 
	ADD CONSTRAINT [PK_MMISMemberData] PRIMARY KEY 
	(
		MMIS_ID 
	) 
GO 



