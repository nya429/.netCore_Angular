use pdrin

select top 100 *
-- delete 
from PDRIn.DBO.MMIS8200MHeader
-- where FooterCapitationMonthYear between '2018-01-01' and '2018-12-01'
where FooterCapitationMonthYear >= '2019-01-01'

-- expected: 95070 rows deleted
select top 100 *
-- delete 
from PDRIn.DBO.MMIS8200MDetail
-- where CapitationMonthYear between '2018-01-01' and '2018-12-01'
where CapitationMonthYear >= '2019-01-01'

-- expected: 6 rows deleted... total from production: 112
select year(FooterCapitationMonthYear ) as y, count(*) as countByYear
from PDRIn.DBO.MMIS8200MHeader
-- where FooterCapitationMonthYear between '2018-01-01' and '2018-12-01'
group by year(FooterCapitationMonthYear )
order by y desc

-- expected: 95064 rows deleted... total from production: 1673981, 50 seconds to load
select year(capitationmonthyear) as y, count(*) as countByYear
from PDRIn.DBO.MMIS8200MDetail
-- where CapitationMonthYear between '2018-01-01' and '2018-12-01'
group by year(capitationmonthyear)
order by y desc


SELECT DISTINCT
ReportName
, case datediff(month,PaymentPeriodStart, PaymentPeriodEnd) when 0 then 'M' when 2 then 'Q' when 11 then 'A' else cast(datediff(month,PaymentPeriodStart, PaymentPeriodEnd) as varchar) end as FileType
, case RIGHT(ReportName,1) when 'A' then 'SCO' when 'B' then 'ICO' else RIGHT(ReportName,1) end AS Product
, case datediff(month,PaymentPeriodStart, PaymentPeriodEnd) when 0 then PaymentPeriodStart else DATEADD(DAY,1,PaymentPeriodEnd) end AS ReportMonth
, PaymentPeriodStart
, PaymentPeriodEnd
, CapitationMonthYear

from MMIS8200MDetail
where CapitationMonthYear >= '2019-01-01'
order by FileType, Product, ReportMonth, CapitationMonthYear

-- , CapitationMonthYear 
