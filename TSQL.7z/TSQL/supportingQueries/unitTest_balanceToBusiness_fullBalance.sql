use PDRIn

declare 
@program as varchar(10)

set @program = 'ICO'


IF OBJECT_ID('TEMPDB..#nickResults') is not null
	drop table #nickResults


-- for single month
;with

c2 AS (
select 
	IIF(
			DATEDIFF(M, h.PaymentPeriodStart, h.PaymentPeriodEnd) > 1, 
			DATEADD(M, DATEDIFF(M, 0, h.PaymentPeriodEnd) + 1, 0), 
			h.PaymentPeriodStart
			) as CheckMonth,
    IIF(DATEDIFF(M, h.PaymentPeriodStart, h.PaymentPeriodEnd) > 1, 'Q', 'M') as FileType,
	h.*
from 
	MMIS8200MHeader as h
where 
		CASE
			WHEN @program = 'SCO' then 'A'
			WHEN @program = 'ICO' then 'B'
		END  = right(ReportName, 1)

)

-- for every month
, c3 as  
(
select 
c2.*,
IIF(
	h.FooterCapitationMonthYear is not null, 
	Format(
		IIF(
			DATEDIFF(M, h.PaymentPeriodStart, h.PaymentPeriodEnd) > 1, 
			DATEADD(M, DATEDIFF(M, 0, h.PaymentPeriodEnd) + 1, 0), 
			h.PaymentPeriodStart
			),
			'MM/yyyy'
		), 
	null
	) as 'RecMonth',	
IIF(h.FooterCapitationMonthYear is not null, IIF(DATEDIFF(M, h.PaymentPeriodStart, h.PaymentPeriodEnd) > 1,  'Q', 'M'), null) as RecFileType,	
h.FooterCapitationMonthYear as 'RecCapMonthYear',
h.TotalPailCapitatedAmount as RecTotal,
h.PaymentPeriodStart as RecPaymentPeriodStart,
h.PaymentPeriodEnd as RecPaymentPeriodEnd,
IIF(h.TotalPailCapitatedAmount is not null, 
c2.TotalPailCapitatedAmount - h.TotalPailCapitatedAmount, 
c2.TotalPailCapitatedAmount) as Remit
from MMIS8200MHeader h
right join c2
on 
	c2.FooterCapitationMonthYear = h.FooterCapitationMonthYear
and
				CASE
					WHEN @program = 'SCO' then 'A'
					WHEN @program = 'ICO' then 'B'
				END  = right(h.ReportName, 1)
and(
-- pm
	(
		DATEADD(M, DATEDIFF(M, 0, c2.CheckMonth) -1,  0) = h.PaymentPeriodStart 
			and 
			DATEADD(M, DATEDIFF(M, 0, c2.CheckMonth),  -1) = h.PaymentPeriodEnd
	)
or
-- pq
	(
		DATEADD(M, DATEDIFF(M, 0, c2.CheckMonth) -2,  0) <> h.PaymentPeriodStart
		 and 
	   DATEADD(M, DATEDIFF(M, 0, c2.CheckMonth) -1,  -1) = h.PaymentPeriodEnd
	   )
-- pa
or
	(
	   DATEDIFF(M, DATEADD(M, DATEDIFF(M, 0, h.PaymentPeriodEnd), 0),  DATEADD(M, DATEDIFF(M, 0,   c2.CheckMonth) -1,  0)) > 1
	    and
		DATEADD(M, DATEDIFF(M, 0, c2.FooterCapitationMonthYear), 0) = h.PaymentPeriodStart
	    and 
	    DATEADD(M, DATEDIFF(M, 0, c2.FooterCapitationMonthYear) + 1, -1) <> h.PaymentPeriodEnd
	)

))


select 
Format(c3.CheckMonth, 'MM/yyyy') as 'CheckMonth',
c3.FileType,
Format(c3.FooterCapitationMonthYear, 'MM/yyyy') as 'CapMonthYear', 
c3.FooterCapitationMonthYear,
c3.TotalPailCapitatedAmount,
c3.RecMonth,
c3.RecFileType,
Format(c3.RecCapMonthYear, 'MM/yyyy') as 'RecCapMonthYear', 
c3.RecTotal,
c3.Remit,

t.CheckTotal 

-- , cast(right(checkMonth, 4) + '-' + left(checkMonth, 2) + '-01' as date) as CheckMonthYear
, c3.CheckMonth as CheckMonthYear

into #nickResults
from 
c3 left join 
(select CheckMonth, sum(Remit) as CheckTotal from c3 group by c3.CheckMonth) as t
on t.CheckMonth = c3.CheckMonth and c3.FileType = 'M'

order by 
c3.CheckMonth desc, c3.FooterCapitationMonthYear desc



use RevRec


IF OBJECT_ID('TEMPDB..#revrecResults') is not null
	drop table #revrecResults

	select 
		p.Product, p.ReportType, p.ReportMonth, p.CapitationMonthYear
		, p.sumPaid
		, r.sumRemit
		, pp.sumPatientPay
		, sd.sumSpendDown
	into #revrecResults
	from (
		select f.Product, f.ReportType, f.ReportMonth, p.CapitationMonthYear, sum(p.Paid) as sumPaid              from PaymentDetailPaid		as p inner join MMISFileProcessing as f on f.MMISFileProcessID = p.MMISFileProcessID where p.PaymentIndicator = 1 group by f.Product, f.ReportType, f.ReportMonth, p.CapitationMonthYear 
	) as p
	inner join (
		select f.Product, f.ReportType, f.ReportMonth, p.CapitationMonthYear, sum(p.Remit) as sumRemit            from PaymentDetailRemit		as p inner join MMISFileProcessing as f on f.MMISFileProcessID = p.MMISFileProcessID group by f.Product, f.ReportType, f.ReportMonth, p.CapitationMonthYear 
	) as r 
		on r.ReportType = p.ReportType
		and r.Product = p.Product
		and r.ReportMonth = p.ReportMonth
		and r.CapitationMonthYear = p.CapitationMonthYear
	inner join (
		select f.Product, f.ReportType, f.ReportMonth, p.CapitationMonthYear, sum(p.PatientPay) as sumPatientPay  from PaymentDetailPatientPay  as p inner join MMISFileProcessing as f on f.MMISFileProcessID = p.MMISFileProcessID where p.PaymentIndicator = 1 group by f.Product, f.ReportType, f.ReportMonth, p.CapitationMonthYear 
	) as pp
		on  pp.ReportType = p.ReportType
		and pp.Product = p.Product
		and pp.ReportMonth = p.ReportMonth
		and pp.CapitationMonthYear = p.CapitationMonthYear
	inner join (
		select f.Product, f.ReportType, f.ReportMonth, p.CapitationMonthYear, sum(p.SpendDown) as sumSpendDown    from PaymentDetailSpendDown   as p inner join MMISFileProcessing as f on f.MMISFileProcessID = p.MMISFileProcessID where p.PaymentIndicator = 1 group by f.Product, f.ReportType, f.ReportMonth, p.CapitationMonthYear 
	) as sd
		on  sd.ReportType = p.ReportType
		and sd.Product = p.Product
		and sd.ReportMonth = p.ReportMonth
		and sd.CapitationMonthYear = p.CapitationMonthYear
	order by p.Product, p.ReportType, p.ReportMonth, p.CapitationMonthYear


select * from #revrecResults where Product = 'ICO' order by ReportMonth, CapitationMonthYear, ReportType
select * from #nickResults 	 order by checkMonthYear, FootercapitationMonthYear, FileType
select left(checkMonth, 2), right(checkMonth, 4) from #nickResults 
