use PDRIn

declare 
@program as varchar(10)

set @program = 'ICO'


IF OBJECT_ID('TEMPDB..#nickResults') is not null
	drop table #nickResults


-- for single month
;with

c2 AS (
select 
	IIF(
			DATEDIFF(M, h.PaymentPeriodStart, h.PaymentPeriodEnd) > 1, 
			DATEADD(M, DATEDIFF(M, 0, h.PaymentPeriodEnd) + 1, 0), 
			h.PaymentPeriodStart
			) as CheckMonth,
    IIF(DATEDIFF(M, h.PaymentPeriodStart, h.PaymentPeriodEnd) > 1, 'Q', 'M') as FileType,
	h.*
from 
	MMIS8200MHeader as h
where 
		CASE
			WHEN @program = 'SCO' then 'A'
			WHEN @program = 'ICO' then 'B'
		END  = right(ReportName, 1)

)

-- for every month
, c3 as  
(
select 
c2.*,
IIF(
	h.FooterCapitationMonthYear is not null, 
	Format(
		IIF(
			DATEDIFF(M, h.PaymentPeriodStart, h.PaymentPeriodEnd) > 1, 
			DATEADD(M, DATEDIFF(M, 0, h.PaymentPeriodEnd) + 1, 0), 
			h.PaymentPeriodStart
			),
			'MM/yyyy'
		), 
	null
	) as 'RecMonth',	
IIF(h.FooterCapitationMonthYear is not null, IIF(DATEDIFF(M, h.PaymentPeriodStart, h.PaymentPeriodEnd) > 1,  'Q', 'M'), null) as RecFileType,	
h.FooterCapitationMonthYear as 'RecCapMonthYear',
h.TotalPailCapitatedAmount as RecTotal,
h.PaymentPeriodStart as RecPaymentPeriodStart,
h.PaymentPeriodEnd as RecPaymentPeriodEnd,
IIF(h.TotalPailCapitatedAmount is not null, 
c2.TotalPailCapitatedAmount - h.TotalPailCapitatedAmount, 
c2.TotalPailCapitatedAmount) as Remit
from MMIS8200MHeader h
right join c2
on 
	c2.FooterCapitationMonthYear = h.FooterCapitationMonthYear
and
				CASE
					WHEN @program = 'SCO' then 'A'
					WHEN @program = 'ICO' then 'B'
				END  = right(h.ReportName, 1)
and(
-- pm
	(
		DATEADD(M, DATEDIFF(M, 0, c2.CheckMonth) -1,  0) = h.PaymentPeriodStart 
			and 
			DATEADD(M, DATEDIFF(M, 0, c2.CheckMonth),  -1) = h.PaymentPeriodEnd
	)
or
-- pq
	(
		DATEADD(M, DATEDIFF(M, 0, c2.CheckMonth) -2,  0) <> h.PaymentPeriodStart
		 and 
	   DATEADD(M, DATEDIFF(M, 0, c2.CheckMonth) -1,  -1) = h.PaymentPeriodEnd
	   )
-- pa
or
	(
	   DATEDIFF(M, DATEADD(M, DATEDIFF(M, 0, h.PaymentPeriodEnd), 0),  DATEADD(M, DATEDIFF(M, 0,   c2.CheckMonth) -1,  0)) > 1
	    and
		DATEADD(M, DATEDIFF(M, 0, c2.FooterCapitationMonthYear), 0) = h.PaymentPeriodStart
	    and 
	    DATEADD(M, DATEDIFF(M, 0, c2.FooterCapitationMonthYear) + 1, -1) <> h.PaymentPeriodEnd
	)

))


select 
Format(c3.CheckMonth, 'MM/yyyy') as 'CheckMonth',
c3.FileType,
Format(c3.FooterCapitationMonthYear, 'MM/yyyy') as 'CapMonthYear', 
c3.FooterCapitationMonthYear,
c3.TotalPailCapitatedAmount,
c3.RecMonth,
c3.RecFileType,
Format(c3.RecCapMonthYear, 'MM/yyyy') as 'RecCapMonthYear', 
c3.RecTotal,
c3.Remit,

t.CheckTotal 

into #nickResults
from 
c3 left join 
(select CheckMonth, sum(Remit) as CheckTotal from c3 group by c3.CheckMonth) as t
on t.CheckMonth = c3.CheckMonth and c3.FileType = 'M'

order by 
c3.CheckMonth desc, c3.FooterCapitationMonthYear desc


declare @researchMonth date = '2018-01-01'

select * from #nickResults
where FooterCapitationMonthYear = @researchMonth

select f.ReportMonth, r.capitationMonthYear, f.product, sum(Paid) as sumPaid
from RevRec.dbo.PaymentDetailPaid as r
inner join RevRec.dbo.MMISFileProcessing as f on f.MMISFileProcessID = R.MMISFileProcessid
where f.Product = @program and r.CapitationMonthYear = @researchMonth
group by f.ReportMonth, r.capitationMonthYear, f.product
order by f.ReportMonth, r.capitationMonthYear, f.product

select f.ReportMonth, r.capitationMonthYear, f.product, sum(Remit) as sumRemit
from RevRec.dbo.PaymentDetailRemit as r
inner join RevRec.dbo.MMISFileProcessing as f on f.MMISFileProcessID = R.MMISFileProcessid
where f.Product = @program and r.CapitationMonthYear = @researchMonth
group by f.ReportMonth, r.capitationMonthYear, f.product
order by f.ReportMonth, r.capitationMonthYear, f.product

