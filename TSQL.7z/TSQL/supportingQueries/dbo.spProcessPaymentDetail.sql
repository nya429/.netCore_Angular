
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
DECLARE @returnValue as INT
EXEC @returnValue = [dbo].[spProcessPaymentDetail] 
PRINT @returnValue 

-- see status for MMIS files identified
select * from MMISFileProcessing order by ReportMonth Desc, Product, ReportType

-- test loading files
delete from MMISFileProcessing where reportMonth = '2019-09-01'

-- set other files unmarked for testing later
update MMISFileProcessing set ProcessIndicator = 'R'


-- Total process time for 2018 - Sep 2019:  1:28 minutes
EXEC [dbo].[spProcessMMISGetPaymentFiles]


EXEC [dbo].[spProcessPaymentDetailInitialize] -- 0:38 seconds

EXEC [dbo].[spProcessPaymentDetailPaid] 
EXEC [dbo].[spProcessPaymentDetailRemit] 
EXEC [dbo].[spProcessPaymentDetailPatientPay] 
EXEC [dbo].[spProcessPaymentDetailSpendDown] 
-- EXEC [dbo].[spProcessPaymentDetail] -- Final

EXEC [dbo].[spProcessPaymentDetailComplete] 


-- verify results
-- **************************
select TOP 100 * from PaymentDetailPaid
select TOP 100 * from PaymentDetailRemit
select TOP 100 * from PaymentDetailPatientPay
select TOP 100 * from PaymentDetailSpendDown

select count(*) from PaymentDetailPaid
select count(*) from PaymentDetailRemit
select count(*) from PaymentDetailPatientPay
select count(*) from PaymentDetailSpendDown

select * from ExecutionLog order by ExecutionLogID desc

-- *****************************************************************************************************
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spProcessPaymentDetail]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spProcessPaymentDetail]
GO

/****** Object:  StoredProcedure [dbo].[spProcessPaymentDetail]    Script Date: 09/23/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- Debugging note: Actual Line 1
/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/23/2019
-- Description:	Processing for putting together a single table for storing payment detail
				Will be used to derive monthly summary record and discrepancies

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC TIME:	 
-- *****************************************************************************************************
*/

CREATE PROCEDURE [dbo].[spProcessPaymentDetail]
	-- Add the parameters for the stored procedure here
	-- @param1 varchar(50) = ''
	-- , @param2 int = 0


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- *****************************************************************************************************
	-- Declarations
	
	DECLARE @appProject varchar(50) = 'RevRec' 
	DECLARE @appLogType char(1) = (select parameterValue from dbo.listParameters where ApplicationName = @appProject and parameterName = 'ExecutionLogging')
	DECLARE @spProcName varchar(50) = '[' + OBJECT_SCHEMA_NAME(@@PROCID) + '].[' + OBJECT_NAME(@@PROCID) + ']'
	DECLARE @spStart datetime2(3)  = getdate()
	DECLARE @spEnd datetime2(3)
	DECLARE @logEntryID int
	DECLARE @procSection varchar(10)
	
-- *****************************************************************************************************

	IF @appLogType = 'A' 
	BEGIN

		INSERT INTO ExecutionLog( 
			-- job_repository_id -- not needed, NULL allowed
			project
			, job
			, StartTime
			, EndTime
		)
		SELECT 
			@appProject 
			, @spProcName
			, @spStart
			, @spStart -- have to insert something... end time is not null in table definition

		-- SET @logEntryID = SCOPE_IDENTITY() -- this would have to be a sequence with job_repository_id... or something else, guid?
	END 
	
	BEGIN TRY
-- *****************************************************************************************************
	-- Add primary code block here
	
	
	-- RAISERROR ('File already loaded, cannot process', 16, 1)

	-- ******************************
	-- STEP 
	-- ******************************

	select top 10 * from PaymentDetailPaid       as p
	select top 10 * from PaymentDetailPatientPay as pp
	select top 10 * from PaymentDetailSpendDown	 as sd
	select top 10 * from PaymentDetailRemit		 as r

-- validation: 
	select count(distinct MMISFileProcessID) from PaymentDetailPaid       
	select count(distinct MMISFileProcessID) from PaymentDetailPatientPay 
	select count(distinct MMISFileProcessID) from PaymentDetailSpendDown	 
	select count(distinct MMISFileProcessID) from PaymentDetailRemit		 

	          select COUNT(*) as count_PaymentDetail, 'Paid'        AS tableName from PaymentDetailPaid       as p  where paymentIndicator = 1
	union all select COUNT(*) as count_PaymentDetail, 'PatientPay'  AS tableName from PaymentDetailPatientPay as pp where paymentIndicator = 1
	union all select COUNT(*) as count_PaymentDetail, 'SpendDown'	AS tableName  from PaymentDetailSpendDown	 as sd where paymentIndicator = 1
	union all select COUNT(*) as count_PaymentDetail, 'Remit'		AS tableName  from PaymentDetailRemit		 as r  where PaymentIndicator = 1

	-- 1. get a view
	-- 2. align to MonthlySummaryRecord

	/*
	-- validated this set of columns joined gets the joint and consistent count of 2296133 (for 01/2018 - 08/2019)
	on r.MMISFileProcessID = f.MMISFileProcessID 
		and r.MemberID = p.MemberID
		and r.CapitationMonthYear = p.CapitationMonthYear
		and r.PaymentIndicator = p.PaymentIndicator
		and r.RateCell	= p.RateCell
		and r.MCRegion	= p.MCRegion
	*/

	select 
		 f.Product	
		,f.ReportType	
		,f.ReportMonth
		,p.MemberID
		,p.CapitationMonthYear
		,p.RateCell	
		,p.MCRegion	
		,p.BaseCapitationAmount
		,pp.PatientPay
		,sd.SpendDown
		,r.Remit
		, row_number() over(Partition by p.MemberID, p.CapitationMonthYear, p.RateCell, p.MCRegion order by f.ReportMonth desc) as rnCurrentPaidAmount
	-- select count(*) -- 2296133
	from MMISFileProcessing as f 
	-- lead table... but all should have same member set
	inner join PaymentDetailPaid as p on p.MMISFileProcessID = f.MMISFileProcessID 
	inner join PaymentDetailPatientPay as pp 
		on pp.MMISFileProcessID = f.MMISFileProcessID 
		and pp.MemberID = p.MemberID
		and pp.CapitationMonthYear = p.CapitationMonthYear
		and pp.PaymentIndicator = p.PaymentIndicator
		and pp.RateCell	= p.RateCell
		and pp.MCRegion	= p.MCRegion
	inner join PaymentDetailSpendDown as sd 		
		on sd.MMISFileProcessID = f.MMISFileProcessID 
		and sd.MemberID = p.MemberID
		and sd.CapitationMonthYear = p.CapitationMonthYear
		and sd.PaymentIndicator = p.PaymentIndicator
		and sd.RateCell	= p.RateCell
		and sd.MCRegion	= p.MCRegion
	-- do we need this table for monthly summary record
	inner join PaymentDetailRemit as r 		
		on r.MMISFileProcessID = f.MMISFileProcessID 
		and r.MemberID = p.MemberID
		and r.CapitationMonthYear = p.CapitationMonthYear
		and r.PaymentIndicator = p.PaymentIndicator
		and r.RateCell	= p.RateCell
		and r.MCRegion	= p.MCRegion
	where 
		-- indicates clear payments
		p.PaymentIndicator = 1 




	select 
		f.Product	
		,f.ReportType	
		,f.ReportMonth
		,p.*
		-- should this be a rank?
		, row_number() over(Partition by p.MemberID, p.CapitationMonthYear, p.RateCell, p.MCRegion order by f.ReportMonth desc) as rnCurrentPaidAmount
	from PaymentDetailPaid as p  
	inner join MMISFileProcessing as f on f.MMISFileProcessID = p.MMISFileProcessID 
	where PaymentIndicator = 1 -- indicates clear payments
	and p.MemberID in (
		-- '100013869266' -- had 4 lines when not checking for 0 value?

		-- examples of multi line
		 '100207898428' -- 	2018-11-01 ; 28
		,'100018927515' -- 	2017-12-01 ; 96
		,'100207898428' -- 	2018-10-01 ; 40
		,'100207898428' -- 	2018-11-01 ; 40
		,'100012735229' -- 	2019-05-01 ; 84
		,'100018987311' -- 	2018-09-01 ; 41

		-- examples of single line
		,'100007946864' -- 2018-01-01 ; 76
		,'100007769217' -- 2018-06-01 ; 75 -- see 2018-03-01 for example of retraction
		,'100020812366' -- 2018-09-01 ; 11
		,'100018541431' -- 2018-08-01 ; 29
		,'100030679029' -- 2018-10-01 ; 46	
	)
	order by 
		 p.MemberID
		,p.CapitationMonthYear
		,f.ReportMonth
		,f.Product	
		-- ,f.ReportType	
		,p.PaymentIndicator

	
	select 
		f.Product	
		,f.ReportType	
		,f.ReportMonth
		,pp.*
		-- should this be a rank?
		, row_number() over(Partition by pp.MemberID, pp.CapitationMonthYear, pp.RateCell, pp.MCRegion order by f.ReportMonth desc) as rnCurrentPaidAmount
	from PaymentDetailPatientPay as pp 
	inner join MMISFileProcessing as f on f.MMISFileProcessID = pp.MMISFileProcessID 
	where PaymentIndicator = 1 -- indicates clear payments
	and pp.MemberID in (
		-- '100013869266' -- had 4 lines when not checking for 0 value?

		-- examples of multi line
		 '100207898428' -- 	2018-11-01 ; 28
		,'100018927515' -- 	2017-12-01 ; 96
		,'100207898428' -- 	2018-10-01 ; 40
		,'100207898428' -- 	2018-11-01 ; 40
		,'100012735229' -- 	2019-05-01 ; 84
		,'100018987311' -- 	2018-09-01 ; 41

		-- examples of single line
		,'100007946864' -- 2018-01-01 ; 76 
		,'100007769217' -- 2018-06-01 ; 75 -- see 2018-03-01 for example of retraction
		,'100020812366' -- 2018-09-01 ; 11
		,'100018541431' -- 2018-08-01 ; 29
		,'100030679029' -- 2018-10-01 ; 46	
	)
	order by 
		 pp.MemberID
		,pp.CapitationMonthYear
		,f.ReportMonth
		,f.Product	
		-- ,f.ReportType	
		,pp.PaymentIndicator -- need this, I think

	
	select top 10 * from PaymentDetailPatientPay as pp where patientPay <>  0.00



	/*
	-- find examples 	
	select memberID, CapitationMonthYear, MMISFileProcessID, count(*) as multiCheck 
	from PaymentDetailPatientPay 
	where patientPay <>  0.00
	group by memberID, CapitationMonthYear, MMISFileProcessID
	having count(*) > 1
	order by multiCheck desc
	
	-- examples of multi line
	100013869266 -- had 4 lines when not checking for 0 value?

	memberID	CapitationMonthYear	MMISFileProcessID
	100207898428	2018-11-01 00:00:00.000	28
	100018927515	2017-12-01 00:00:00.000	96
	100207898428	2018-10-01 00:00:00.000	40
	100207898428	2018-11-01 00:00:00.000	40
	100012735229	2019-05-01 00:00:00.000	84
	100018987311	2018-09-01 00:00:00.000	41

	-- examples of single line
	memberID	CapitationMonthYear	MMISFileProcessID
	100007946864	2018-01-01 00:00:00.000	76
	100007769217	2018-06-01 00:00:00.000	75
	100020812366	2018-09-01 00:00:00.000	11
	100018541431	2018-08-01 00:00:00.000	29
	100030679029	2018-10-01 00:00:00.000	46

	*/



	-- End primary code block 
-- *****************************************************************************************************

-- *****************************************************************************************************
	-- clean-up:
		-- temp table(s)
		-- final logs

	IF @appLogType = 'A' 
	BEGIN
		set @spEnd = getdate()

		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 1
				, duration = datediff(minute,@spStart, @spEnd)
		where job = @spProcName and StartTime = @spStart

	END 

-- *****************************************************************************************************
	END TRY

-- *****************************************************************************************************
	-- catch block here
	-- should this be 2 tables, one for execution, one for error (so as not to over expand the execution log)
	BEGIN CATCH

		set @spEnd = getdate()
		
		IF @appLogType = 'E' 
		BEGIN
			INSERT INTO ExecutionLog ( -- Database/Schema 
				project
				, job
				, StartTime
				, EndTime 
			)
			SELECT 
				@appProject 
				, @spProcName
				, @spStart
				, @spEnd -- can populate with actual end time here, if error only

		END 		
		
		update ExecutionLog
			set 
				  EndTime = @spEnd
				, successFlag = 0
				, duration = datediff(minute,@spStart, @spEnd).     
				, message_type = 'Error'
				, errorNumber = ERROR_NUMBER() 
				, errorProcedure = ERROR_PROCEDURE() 
				, errorLine = ERROR_LINE() 
				, errorSeverity = ERROR_SEVERITY()  
				, message = ERROR_MESSAGE()   
				, errorState = ERROR_STATE()     
		where job = @spProcName and StartTime = @spStart
		
		; THROW 


		/*
		-- immediate error results printed, returning the error number
		print    'errNUMB:' + cast(ERROR_NUMBER()    as varchar)
		+ '; ' + 'errPROC:' + cast(ERROR_PROCEDURE() as varchar)
		+ '; ' + 'errLINE:' + cast(ERROR_LINE() 	 as varchar)
		+ '; ' + 'errMESG:' + cast(ERROR_MESSAGE()   as varchar)
		*/
				
		return error_number()			
		

	END CATCH
-- *****************************************************************************************************


END
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT EXECUTE ON [dbo].[spProcessPaymentDetail] TO [Talend] 
GRANT EXECUTE ON [dbo].[spProcessPaymentDetail] TO [Support] 
GO
-- *****************************************************************************************************