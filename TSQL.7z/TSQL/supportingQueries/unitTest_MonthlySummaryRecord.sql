use RevRec

/*
-- "backup" monthly summary record using the monthly close process to generate a new entry

DECLARE @returnValue as INT, @NewID int, @RetCd int
EXEC @returnValue = [dbo].[spCreateMonthlyClose] 
	  @eventUserID = 2 

	, @NewIdentity = @NewID output
	, @ReturnCode = @RetCd  output
	
-- Confirm proper results returned
PRINT @returnValue
PRINT @NewID
PRINT @RetCd

select * from monthlyCloseRecord where monthlycloseHeaderID > 1
select * from monthlycloseHeader

select * from RateCard

*/


	select 
		memMMIS.MasterPatientID as MasterPatientID
		, pd.CapitationMonthYear as MemberMonth
		, pd.MemberID as MMIS_ID

		-- conversion for varchar > numeric errors
		, (ratCCA.Amount - case when memcca.PatientPay like '%[0-9].[0-9][0-9]' then cast(memcca.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when memcca.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(memcca.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end)  
			- (pd.BaseCapitationAmount - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00)) as Variance 
		, (pd.BaseCapitationAmount - ratMMIS.Amount) as PaymentError  -- Payment error SHOULD NOT be part of the variance calculation

		-- from PatientPayDetail... what the state actually says they paid, based on file
		, pd.BaseCapitationAmount as BaseCapitationAmount	
		, pd.PatientPay as PatientPayAmountN		
		, pd.SpendDown as PatientPayAmountSCO	
		, pd.Paid as PaidCapitationAmount
		, pd.Remit	
	

		, memCCA.CCARateCellID as CCARateCellID 
		, memCCA.CCARegionID as CCARegionID 
		-- conversion for varchar > numeric errors
		, case when memCCA.PatientPay like '%[0-9].[0-9][0-9]' then cast(memCCA.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end as CCAPatientPay 
		, case when memCCA.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(memCCA.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end as CCAPatientSpendDown 


		-- CCA's expected based on current member's rate cell and region in MP
		, memCCA.RateCardID as CCARateCardID 
		, ratCCA.Amount as CCAAmount 

		-- conversion for varchar > numeric errors
		, (isnull(ratCCA.Amount,0.00) - case when memcca.PatientPay like '%[0-9].[0-9][0-9]' then cast(memcca.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when memcca.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(memcca.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end) as CCANetAmount 
		
		, ratMMIS.CCARateCellID as MMISRateCellID 
		, ratMMIS.CCARegionID as MMISRegionID 
		, pd.PatientPay as MMISPatientPay 
		, pd.SpendDown as MMISPatientSpendDown 
	
		-- expected payment based on state's rate rate cell and region
		, ratmmis.RateCardID as MMISRateCardID 
		, ratMMIS.Amount as MMISAmount 
		, (isnull(ratMMIS.Amount,0.00) - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00))  as MMISNetAmount 

	-- from PatientPayDetail as ppd
	-- select top 10 * 
	from vwPaymentDetail as pd
	left join MMISMemberData as memMMIS on memMMIS.MMIS_ID    = pd.MemberID
	left join vwRateCellMap	 as rcMap   on rcMap.MMISRateCell = pd.RateCell and rcMap.ActiveFlag = 1
	left join vwRegionMap    as regMap  on regMap.MMISRegion  = pd.MCRegion and regMap.ActiveFlag = 1
	-- note overlaps in test rate card data
	left join vwRateCard     as ratMMIS	
		on  ratMMIS.CCARateCellID = rcMap.CCARateCellID
		and ratMMIS.CCARegionID = regMap.CCARegionID
		and pd.CapitationMonthYear between ratMMIS.StartDate and ratMMIS.EndDate
		and ratMMIS.ActiveFlag = 1
	left join vwCCAMemberData as memCCA ON memCCA.MMIS_ID = memMMIS.MMIS_ID
		and pd.CapitationMonthYear between memCCA.RatingCategoryStartDate and memCCA.RatingCategoryEndDate
		and pd.CapitationMonthYear between memCCA.RegionStartDate AND memCCA.RegionEndDate
		and memCCA.ActiveFlag = 1
	left join vwRateCard     as ratCCA on ratCCA.RateCardID = memCCA.RateCardID
	where pd.rnCurrentPaidAmount = 1
	