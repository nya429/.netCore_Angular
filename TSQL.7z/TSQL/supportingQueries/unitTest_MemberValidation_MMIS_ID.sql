use MPSnapshotProd

/*
-- Oracle query
"SELECT DISTINCT
CAST(n.TEXT2 AS INT) CCAID
, eea.TEXT1 MMIS_ID 
, n.NAME_ID
, n.NAME_FIRST MemberFirstName
, n.NAME_MI MemberMiddleName
, n.NAME_LAST MemberLastName
, n.GENDER Gender
, n.BIRTH_DATE DOB
FROM SC_BASE.name  n
INNER JOIN SC_BASE.ENTITY_ENROLL_APP  eea on eea.entity_id = n.name_id
INNER JOIN SC_BASE.DATE_SPAN  dsEnr on dsEnr.NAME_ID = n.NAME_ID AND dsEnr.CARD_TYPE = 'MCAID App' and dsEnr.COLUMN_NAME = 'name_text19'
WHERE dsEnr.VALUE IN ('SCO', 'ICO')
AND eea.APP_TYPE = 'MCAID'
AND regexp_like(n.text2, '[5][3-9][6-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
"
*/


SELECT DISTINCT
CAST(n.TEXT2 AS bigINT) CCAID
, eea.TEXT1 MMIS_ID 
, n.NAME_ID
, n.NAME_FIRST MemberFirstName
, n.NAME_MI MemberMiddleName
, n.NAME_LAST MemberLastName
, n.GENDER Gender
, n.BIRTH_DATE DOB
FROM name  n
INNER JOIN ENTITY_ENROLL_APP  eea on eea.entity_id = n.name_id
INNER JOIN DATE_SPAN  dsEnr on dsEnr.NAME_ID = n.NAME_ID AND dsEnr.CARD_TYPE = 'MCAID App' and dsEnr.COLUMN_NAME = 'name_text19'
WHERE dsEnr.VALUE IN ('SCO', 'ICO')
AND eea.APP_TYPE = 'MCAID'
AND n.text2 like '[5][3-9][6-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'

use RevRec

select * from ccamemberdata where mmis_id not like '100[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]' or mmis_id is null
