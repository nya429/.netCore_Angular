USE [RevRec]
GO


/*
	-- clear for re-import
	EXEC dbo.spTrun_RateCard

	-- validate pre/post import
	SELECT * FROM RateCard
	select * from vwRateCard

	SELECT * FROM RateCard order by startdate, enddate -- between '2018-01-01' and '2018-12-31' or enddate between '2018-01-01' and '2018-12-31'
*/	



DECLARE @spStart datetime2(3) = getdate()


if object_id('tempdb..#rateRegionAmounts') is not null
	drop table #rateRegionAmounts

create table #rateRegionAmounts (
description	
modifier	
alternate_code	
alternate_modifier	
start_date	
end_date	 
rate 

)

	
	select * from ccaRateCells
	select * from mmisRateCells
	select * from ccaRegions
	select * from mmisRegions




insert into RateCard (
	  CCARateCellID       
	, CCARegionID         
	, StartDate           
	, EndDate             
	, Amount              
	, RateCardLabel       
	, Eligibility         
	, Product
	, ActiveFlag
	, insertDate
	, updateDate
)

from #rateRegionAmounts as rate
inner join vwRegionMap as reg on reg.MMISRegion = rate.MCRegion
inner join vwRateCellMap as rc on rc.MMISRateCell = rate.RateCell
inner join CCARateCells as ccaRc on ccaRc.CCARateCellID = rc.CCARateCellID
-- MISSING 16?
-- order by 	RateCell, BaseCapitationAmount, MCRegion	


select * from #rateRegionAmounts as rate


SELECT * FROM #rc2018 as rc inner join (

SELECT RATECARDLABEL, COUNT(*) AS DUPCHECK
FROM #rc2018 
GROUP BY RATECARDLABEL
having count(*) > 1
-- ORDER BY DUPCHECK DESC, RATECARDLABEL 
) as dup
on dup.RATECARDLABEL = rc.RATECARDLABEL
order by CCARateCellID, CCARegionID, StartDate, EndDate


