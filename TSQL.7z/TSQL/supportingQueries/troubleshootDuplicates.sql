use RevRec

if object_id('tempdb..#prepMSR') IS NOT NULL
	DROP TABLE #prepMSR

select 
		memMMIS.MasterPatientID as MasterPatientID
		, pd.CapitationMonthYear as MemberMonth


		-- conversion for varchar > numeric errors
		, (ratCCA.Amount - case when memcca.PatientPay like '%[0-9].[0-9][0-9]' then cast(memcca.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when memcca.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(memcca.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end)  
			- (pd.BaseCapitationAmount - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00)) as Variance 
		, (pd.BaseCapitationAmount - ratMMIS.Amount) as PaymentError  -- Payment error SHOULD NOT be part of the variance calculation

		-- from PatientPayDetail... what the state actually says they paid, based on file
		, pd.BaseCapitationAmount as BaseCapitationAmount	
		, pd.PatientPay as PatientPayAmountN		
		, pd.SpendDown as PatientPayAmountSCO	
		, pd.Paid as PaidCapitationAmount
		, pd.Remit	
	

		, memCCA.CCARateCellID as CCARateCellID 
		, memCCA.CCARegionID as CCARegionID 
		-- conversion for varchar > numeric errors
		, case when memCCA.PatientPay like '%[0-9].[0-9][0-9]' then cast(memCCA.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end as CCAPatientPay 
		, case when memCCA.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(memCCA.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end as CCAPatientSpendDown 


		-- CCA's expected based on current member's rate cell and region in MP
		, memCCA.RateCardID as CCARateCardID 
		, ratCCA.Amount as CCAAmount 

		-- conversion for varchar > numeric errors
		, (isnull(ratCCA.Amount,0.00) - case when memcca.PatientPay like '%[0-9].[0-9][0-9]' then cast(memcca.PatientPay as numeric(18,2)) else cast(0.00 as numeric(18,2)) end - case when memcca.PatientSpendDown like '%[0-9].[0-9][0-9]' then cast(memcca.PatientSpendDown as numeric(18,2)) else cast(0.00 as numeric(18,2)) end) as CCANetAmount 
		
		, ratMMIS.CCARateCellID as MMISRateCellID 
		, ratMMIS.CCARegionID as MMISRegionID 
		, pd.PatientPay as MMISPatientPay 
		, pd.SpendDown as MMISPatientSpendDown 
	
		-- expected payment based on state's rate rate cell and region
		, ratmmis.RateCardID as MMISRateCardID 
		, ratMMIS.Amount as MMISAmount 
		, (isnull(ratMMIS.Amount,0.00) - isnull(pd.PatientPay,0.00) - isnull(pd.SpendDown,0.00))  as MMISNetAmount 
	INTO #prepMSR
	-- from PatientPayDetail as ppd
	-- select top 10 * 
	from vwPaymentDetail as pd
	left join MMISMemberData as memMMIS on memMMIS.MMIS_ID    = pd.MemberID
	left join vwRateCellMap	 as rcMap   on rcMap.MMISRateCell = pd.RateCell and rcMap.ActiveFlag = 1
	left join vwRegionMap    as regMap  on regMap.MMISRegion  = pd.MCRegion and regMap.ActiveFlag = 1
	-- note overlaps in test rate card data
	left join vwRateCard     as ratMMIS	
		on  ratMMIS.CCARateCellID = rcMap.CCARateCellID
		and ratMMIS.CCARegionID = regMap.CCARegionID
		and pd.CapitationMonthYear between ratMMIS.StartDate and ratMMIS.EndDate
		and ratMMIS.ActiveFlag = 1
	left join vwCCAMemberData as memCCA ON memCCA.MMIS_ID = memMMIS.MMIS_ID
		and pd.CapitationMonthYear between memCCA.RatingCategoryStartDate and memCCA.RatingCategoryEndDate
		and pd.CapitationMonthYear between memCCA.RegionStartDate AND memCCA.RegionEndDate
	left join vwRateCard     as ratCCA on ratCCA.RateCardID = memCCA.RateCardID
		
	
	where pd.rnCurrentPaidAmount = 1
	

	select top 100 msr.* from #prepMSR as msr
	inner join (
		SELECT MasterPatientID, memberMonth, count(*) as dupCheck 
		from #prepMSR 
		group by MasterPatientID, memberMonth having count(*) > 1
	) as dup on dup.MasterPatientID = msr.MasterPatientID
	and dup.MemberMonth = msr.MemberMonth
	where msr.MasterPatientid = 16903 
	order by MasterPatientID, memberMonth

	
	select count(*) from #prepMSR 
	-- ORIGINAL TOTAL:   1521810
	-- RATE CARD FILTER: 1521736
	-- AFTER row number: 1466968
	-- AFTER RATE CARD:   926337
	-- after date:        686242 -- no more duplicates

	select * from vwRateCard
	WHERE RATECARDID IN (6, 47) 
	
	select * from vwRateCard
	WHERE RATECARDID IN (48, 78)


	select * from vwRateCard
	where ratecardid in (10, 11)
		
	select insertDate, count(*) as countByInsertDate from RateCard group by insertDate

	update RateCard
	set ActiveFlag = 0
	 where insertDate > '2019-07-22 10:02:30.280'

	-- select r1.CCARateCellID, r1.CCARegionID, r1.StartDate, r1.EndDate 	, r2.CCARateCellID, r2.CCARegionID, r2.StartDate, r2.EndDate 
	select r1.*, r2.*
	from RateCard as r1
	inner join ratecard as r2 on r1.StartDate between r2.StartDate and r2.EndDate and r1.CCARateCellID = r2.CCARateCellID and r1.CCARegionID = r2.CCARegionID and r1.RateCardID <> r2.RateCardID


	select * from mmismemberdata where masterpatientid = 1 -- 4/2018?
	select * from mmismemberdata where masterpatientid = 3 -- 4/2018
	select * from mmismemberdata where masterpatientid = 16903 -- 8/2018

	select * from vwPaymentDetail 
	-- where memberid  = '100000010072' -- duplicate before
	-- where memberid = '100000021269' -- duplicate after
	WHERE MEMBERID = '100014448474' -- duplicate after Rate card inactive
	and rnCurrentPaidAmount = 1 
	order by CapitationMonthYear


