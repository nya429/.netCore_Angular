
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwGetDiscrepancyCommentList]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwGetDiscrepancyCommentList]') AND type in (N'V'))
DROP VIEW [dbo].[vwGetDiscrepancyCommentList]
GO

/****** Object:  View [dbo].[vwGetDiscrepancyCommentList]    Script Date: 09/05/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/05/2019
-- Description:	Method for spGetDiscrepancyCommentList

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwGetDiscrepancyCommentList] AS

select  
		  dc.DiscrepancyCommentID	
		, dc.DiscrepancyID	
		, dc.ReplyCommentID	
		, dc.Comment_UserID	
		, u.UserNameAD
		, u.UserFirstName
		, u.UserLastName
		, dc.DiscrepancyComment	
		, dc.ActiveFlag	
		, dc.insertDate	
		, dc.updateDate

	from DiscrepanciesComments as dc
	inner join Users as u on userid = dc.Comment_UserID

	where dc.ActiveFlag = 1
	





GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwGetDiscrepancyCommentList] TO [Talend] 
GRANT SELECT ON [dbo].[vwGetDiscrepancyCommentList] TO [Support] 
GRANT SELECT ON [dbo].[vwGetDiscrepancyCommentList] TO [webapp] 
GO
-- *****************************************************************************************************
