
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwDiscrepancyCategories]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwDiscrepancyCategories]') AND type in (N'V'))
DROP VIEW [dbo].[vwDiscrepancyCategories]
GO

/****** Object:  View [dbo].[vwDiscrepancyCategories]    Script Date: 08/22/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/22/2019
-- Description:	View for Discrepancy Categories
				Presents results as returned from API spGetDiscrepancyCategories

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwDiscrepancyCategories] AS


	select 
		  dc.DiscrepancyCategoryID
		, dc.DiscrepancyCategory
		, dc.DiscrepancyCategoryDescription
		, dc.DiscrepancyCategoryDisplay
		, dc.ActiveFlag
		, dc.insertDate
		, dc.updateDate
	from DiscrepancyCategories as dc
	WHERE dc.ActiveFlag = 1





GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwDiscrepancyCategories] TO [Talend] 
GRANT SELECT ON [dbo].[vwDiscrepancyCategories] TO [Support] 
GRANT SELECT ON [dbo].[vwDiscrepancyCategories] TO [webapp] 
GO
-- *****************************************************************************************************
