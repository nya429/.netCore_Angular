
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwGetUnmappedMMISRateCellCount]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwGetUnmappedMMISRateCellCount]') AND type in (N'V'))
DROP VIEW [dbo].[vwGetUnmappedMMISRateCellCount]
GO

/****** Object:  View [dbo].[vwGetUnmappedMMISRateCellCount]    Script Date: 09/03/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/03/2019
-- Description:	View for model: spGetUnmappedMMISRateCellCount
				Returns count of unmapped MMIS Rate Cells
				

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwGetUnmappedMMISRateCellCount] AS



	select count(*) over() as UnmappedMMISRateCellCount
 	from MMISRateCells as rc
	left join RateCellMap as rcm on rcm.MMISRateCellID = rc.MMISRateCellID
	where rc.ActiveFlag = 1
		and (
			rcm.ActiveFlag is null
			or rcm.ActiveFlag = 0
		)



GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwGetUnmappedMMISRateCellCount] TO [Talend] 
GRANT SELECT ON [dbo].[vwGetUnmappedMMISRateCellCount] TO [Support] 
GRANT SELECT ON [dbo].[vwGetUnmappedMMISRateCellCount] TO [webapp] 
GO
-- *****************************************************************************************************
