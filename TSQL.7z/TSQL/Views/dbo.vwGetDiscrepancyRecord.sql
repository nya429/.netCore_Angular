
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwGetDiscrepancyRecord]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwGetDiscrepancyRecord]') AND type in (N'V'))
DROP VIEW [dbo].[vwGetDiscrepancyRecord]
GO

/****** Object:  View [dbo].[vwGetDiscrepancyRecord]    Script Date: 09/05/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/05/2019
-- Description:	Model for spGetDiscrepancyRecord

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwGetDiscrepancyRecord] AS



	select 
		 d.DiscrepancyID
		,d.MonthlySummaryRecordID
		,d.MasterPatientID
		,d.MemberMonth
		,d.Variance
		,d.PaymentError
		,d.BaseCapitationAmount
		,d.PatientPayAmountN
		,d.PatientPayAmountSCO
		,d.PaidCapitationAmount
		,d.CCARateCellID
		,d.CCARegionID
		,d.CCAPatientPay
		,d.CCAPatientSpendDown
		,d.CCARateCardID
		,d.CCAAmount
		,d.CCANetAmount
		,d.MMISRateCellID
		,d.MMISRegionID
		,d.MMISPatientPay
		,d.MMISPatientSpendDown
		,d.MMISRateCardID
		,d.MMISAmount
		,d.MMISNetAmount
		,d.TypeRateCell
		,d.TypeRegion
		,d.TypePatientPay
		,d.TypePatientSpendDown
		,d.TypePaymentError
		,d.Assigned_UserID
		,d.Action_UserID
		,d.DiscrepancyStatusID
		,d.DueDate
		,d.DiscoverDate
		,d.ResolvedDate
		,d.Balanced
		,d.ActiveFlag
		,d.insertDate
		,d.updateDate
		,ds.DiscrepancyStatus
		,u.UserNameAD as AssignedUserName -- this alias may need to become full first/last if no AD plugin
	from Discrepancies as d
	inner join DiscrepancyStatuses as ds on ds.DiscrepancyStatusID = d.DiscrepancyStatusID
	left join Users as u on u.userID = d.assigned_UserID




GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwGetDiscrepancyRecord] TO [Talend] 
GRANT SELECT ON [dbo].[vwGetDiscrepancyRecord] TO [Support] 
GRANT SELECT ON [dbo].[vwGetDiscrepancyRecord] TO [webapp] 
GO
-- *****************************************************************************************************
