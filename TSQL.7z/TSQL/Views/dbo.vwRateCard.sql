
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwRateCard]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwRateCard]') AND type in (N'V'))
DROP VIEW [dbo].[vwRateCard]
GO

/****** Object:  View [dbo].[vwRateCard]    Script Date: 07/22/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/22/2019
-- Description:	Model - View for seeing Rate Card map

				Post Unit Test - 09/27/2019
					needed webapp permissions, getting denied on select error

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwRateCard] AS


select 
	  r.RateCardID
	, r.CCARateCellID
	, rc.CCARateCell
	, r.CCARegionID
	, reg.CCARegion
	, r.StartDate
	, r.EndDate
	, r.Amount
	, r.RateCardLabel
	, r.Eligibility
	, case r.Eligibility
		when 'D' then 'Dual'
		when 'M' then 'Mass Health Only'
		else NULL
	end as EligibilityStatus
	, r.Product
	, r.ActiveFlag
	, r.insertDate
	, r.updateDate
from RateCard as r
inner join CCARateCells as rc on rc.CCARateCellID = r.CCARateCellID
inner join CCARegions as reg on reg.CCARegionID = r.CCARegionID




GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwRateCard] TO [Talend] 
GRANT SELECT ON [dbo].[vwRateCard] TO [Support] 
GRANT SELECT ON [dbo].[vwRateCard] TO [webapp] 
GO
-- *****************************************************************************************************
