
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwMemberList]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwMemberList]') AND type in (N'V'))
DROP VIEW [dbo].[vwMemberList]
GO

/****** Object:  View [dbo].[vwMemberList]    Script Date: 09/16/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/16/2019
-- Description:	For model, introduced MemberList view

				Post Unit Test - API Feature request - 09/23/2019
					Return TotalAssigned count for discrepancies (by member)

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwMemberList] AS


		select 
			  ml.MasterPatientID 
			, ml.MemberFirstName 
			, ml.MemberMiddleName 
			, ml.MemberLastName 
			, ml.MMIS_MMIS_ID 
			, ml.CCAID 
			, ml.Product 
			, ml.EnrollStartDate 
			, ml.EnrollEndDate 
			, ml.DOB 
			, ml.DOD 
			, ml.RatingCategory 
			, ml.Region 
			, ml.MemberEnrollmentStatus 
			, ml.TotalDiscrepancies 
			, ml.maxAging 
			, ml.absoluteVarianceSum 
			, d.TotalAssigned
		from MemberList as ml
		inner join (
			select 
			MasterPatientID
			, sum(case when Assigned_UserID is null then 0 else 1 end) as TotalAssigned
			, sum(case when Assigned_UserID is null then 1 else 0 end) as TotalUnAssigned
			from Discrepancies
			group by MasterPatientID
		) as d on d.MasterPatientID = ml.MasterPatientID




GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwMemberList] TO [Talend] 
GRANT SELECT ON [dbo].[vwMemberList] TO [Support] 
GRANT SELECT ON [dbo].[vwMemberList] TO [webapp] 
GO
-- *****************************************************************************************************
