
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwPaymentDetail]

SELECT TOP 10 * FROM [dbo].[vwPaymentDetail]
SELECT count(*) FROM [dbo].[vwPaymentDetail] -- before rate card: 2296133; after rate card: 2296133
-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwPaymentDetail]') AND type in (N'V'))
DROP VIEW [dbo].[vwPaymentDetail]
GO

/****** Object:  View [dbo].[vwPaymentDetail]    Script Date: 09/24/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/24/2019
-- Description:	View for seeing all state payment details together
				Includes ranking to see latest member/month record 
				Will be used for populating monthly summary record and generating discrepancies

				Post QA - 10/16/2019
					need to modify PaymentIndicator as filter between 0 and 1 (beyond 1 appear to be incorrect payments, or possible multiple loads of 8200 file)
					Add to row_number() instead.  Will have the same effect in getting latest, and will include 0 payments correctly
					Also added to result set so processing can handle zeroing out amounts for all payment details
					


-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwPaymentDetail] AS



	select 
		 f.Product	
		,f.ReportType	
		,f.ReportMonth
		,p.MemberID
		,p.CapitationMonthYear
		,p.RateCell	
		,p.MCRegion	
		,p.BaseCapitationAmount
		,p.Paid
		,pp.PatientPay
		,sd.SpendDown
		,r.Remit

		, ratMMIS.RateCardID
		, ratMMIS.CCARateCell
		, ratMMIS.CCARateCellID
		, ratMMIS.CCARegion
		, ratMMIS.CCARegionID
		, ratMMIS.StartDate
		, ratMMIS.EndDate
		, ratMMIS.Amount
		, ratMMIS.ActiveFlag
	

		, p.PaymentIndicator


		-- , row_number() over(Partition by p.MemberID, p.CapitationMonthYear, p.RateCell, p.MCRegion order by f.ReportMonth desc) as rnCurrentPaidAmount
		-- cannot consider rate cell and region... this creates duplciate monthly summary record and discrepancies
		, row_number() over(Partition by p.MemberID, p.CapitationMonthYear order by f.ReportMonth desc, p.PaymentIndicator desc) as rnCurrentPaidAmount
	-- select count(*) -- 2296133
	from MMISFileProcessing as f 
	-- lead table... but all should have same member set
	inner join PaymentDetailPaid as p on p.MMISFileProcessID = f.MMISFileProcessID 
	inner join PaymentDetailPatientPay as pp 
		on pp.MMISFileProcessID = f.MMISFileProcessID 
		and pp.MemberID = p.MemberID
		and pp.CapitationMonthYear = p.CapitationMonthYear
		and pp.PaymentIndicator = p.PaymentIndicator
		and pp.RateCell	= p.RateCell
		and pp.MCRegion	= p.MCRegion
	inner join PaymentDetailSpendDown as sd 		
		on sd.MMISFileProcessID = f.MMISFileProcessID 
		and sd.MemberID = p.MemberID
		and sd.CapitationMonthYear = p.CapitationMonthYear
		and sd.PaymentIndicator = p.PaymentIndicator
		and sd.RateCell	= p.RateCell
		and sd.MCRegion	= p.MCRegion
	-- do we need this table for monthly summary record
	inner join PaymentDetailRemit as r 		
		on r.MMISFileProcessID = f.MMISFileProcessID 
		and r.MemberID = p.MemberID
		and r.CapitationMonthYear = p.CapitationMonthYear
		and r.PaymentIndicator = p.PaymentIndicator
		and r.RateCell	= p.RateCell
		and r.MCRegion	= p.MCRegion

	-- potential addition, rather than dealing with this in MonthlySummaryRecord... will still be current because in view
	left join vwRateCellMap	 as rcMap   on rcMap.MMISRateCell = p.RateCell and rcMap.ActiveFlag = 1
	left join vwRegionMap    as regMap  on regMap.MMISRegion  = p.MCRegion and regMap.ActiveFlag = 1
	left join vwRateCard     as ratMMIS	
		on  ratMMIS.CCARateCellID = rcMap.CCARateCellID
		and ratMMIS.CCARegionID = regMap.CCARegionID
		and p.CapitationMonthYear between ratMMIS.StartDate and ratMMIS.EndDate
		and ratMMIS.ActiveFlag = 1

	where 
		-- indicates clear payments (1) or retraction (0)
		p.PaymentIndicator between 0 and 1 




GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwPaymentDetail] TO [Talend] 
GRANT SELECT ON [dbo].[vwPaymentDetail] TO [Support] 
GO
-- *****************************************************************************************************
