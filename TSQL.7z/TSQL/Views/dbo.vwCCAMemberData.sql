
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwCCAMemberData]
SELECT count(*) FROM [dbo].[vwCCAMemberData]
109238 - before change
109252 - after change
109252 - after 2nd change

-- pre-ActiveFlag Filter: 109233;  post-ActiveFlag Filter: 109233
SELECT count(*) FROM [dbo].[vwCCAMemberData]


SELECT * FROM [dbo].[vwCCAMemberData]
where MMIS_ID = '100013304728'

/*
-- before

Product	EnrollStartDate	EnrollEndDate	RatingCategory	RatingCategoryStartDate	RatingCategoryEndDate	Region	RegionStartDate
ICO	2019-01-01	NULL	DC2A	2018-08-01	2019-03-31	West	2018-05-01
ICO	2019-01-01	NULL	DC3A	2019-04-01	NULL	West	2018-05-01
ICO	2018-05-01	2018-07-31	DC2A	2018-05-01	2018-07-31	West	2018-05-01
ICO	2018-08-01	2018-12-31	DC2A	2018-08-01	2019-03-31	NULL	NULL


-- after
Product	EnrollStartDate	EnrollEndDate	RatingCategory	RatingCategoryStartDate	RatingCategoryEndDate	Region	RegionStartDate
ICO	2018-08-01	2018-12-31	DC2A	2018-08-01	2019-03-31	West	2018-05-01
ICO	2019-01-01	NULL	DC2A	2018-08-01	2019-03-31	West	2018-05-01
ICO	2019-01-01	NULL	DC3A	2019-04-01	NULL	West	2018-05-01
ICO	2018-05-01	2018-07-31	DC2A	2018-05-01	2018-07-31	West	2018-05-01


*/
-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwCCAMemberData]') AND type in (N'V'))
DROP VIEW [dbo].[vwCCAMemberData]
GO

/****** Object:  View [dbo].[vwCCAMemberData]    Script Date: 08/21/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/21/2019
-- Description:	View member data with all spans, date aligned with enrollment spans and other sub-spans.
				
				Post Unit-test: 10/09/2019
					Included additional conditions to not lose span alignment for end dates


-- Modified by: Jonathan Lewis
-- Modified dt: 01/08/2020
-- Description: ADS-2980/ADS-2915
				Will add ActiveFlag for filter to exclude bad records


-- Modified by: Jonathan Lewis
-- Modified dt: 01/13/2020
-- Description: ADS-2980/ADS-2939
				Added "reverse" region to rating category lookup for spans


-- Modified by: Jonathan Lewis
-- Modified dt: 01/13/2020
-- Description: ADS-2980/ADS-2939
				Added "reverse" region to rating category lookup for spans
					both compared to enrollment and rating category spans
					

-- EXEC Time: 0:34 seconds (over VPN), midnight; 0:03 seconds (over VPN)
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwCCAMemberData] AS


	select 
		  mem.CCAID	
		, mem.MMIS_ID	
		, mem.MemberFirstName	
		, mem.MemberMiddleName	
		, mem.MemberLastName	
		, mem.Gender	
		, mem.DOB	
		, mem.DOD

		, dsEnr.Product
		, dsEnr.EnrollStartDate
		, dsEnr.EnrollEndDate
		, dsRat.RatingCategory
		, dsRat.RatingCategoryStartDate		
		, dsRat.RatingCategoryEndDate
		, dsReg.Region
		, dsReg.RegionStartDate
		, dsReg.RegionEndDate
		, dsPat.PatientPay
		, dsPat.PatientPayStartDate		
		, dsPat.PatientPayEndDate
		, dsSpd.PatientSpendDown
		, dsSpd.PatientSpendDownStartDate		
		, dsSpd.PatientSpendDownEndDate
-- can I remove this here
		, rc.RateCardID
		, rc.CCARateCellID
		, rc.CCARegionID
		, rc.Amount
		, rc.StartDate
		, rc.EndDate
		, rc.ActiveFlag
		-- , rc.RateCardLabel
	from CCAMemberData as mem
	cross join listParameters as p 
	inner join CCAMemberSpanEnrollment as dsEnr on dsEnr.CCAID = mem.CCAID 
	left join CCAMemberSpanRatingCategory as dsRat on dsRat.CCAID = mem.CCAID and dsRat.ActiveFlag = 1
		-- tier 1: compare to enrollment
		and (
			dsRat.RatingCategoryStartDate between dsEnr.EnrollStartDate and isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date))
			or (dsRat.RatingCategoryStartDate is not null
				and isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date)) between dsEnr.EnrollStartDate and isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date))
			)
			or (
				dsEnr.EnrollStartDate between dsRat.RatingCategoryStartDate and isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date))
				or isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date)) between dsRat.RatingCategoryStartDate and isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date))
			)
		)
	LEFT join CCAMemberSpanRegion as dsReg on dsReg.CCAID = mem.CCAID and dsReg.ActiveFlag = 1 -- and dsEnr.Product = 'ICO' -- w/SCO 93881 vs w/o SCO 93850... some split regions must occur with SCO
		-- tier 2: (1) compare to enrollment
		and (
			dsReg.RegionStartDate between dsEnr.EnrollStartDate and isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date))
			or (dsReg.RegionStartDate is not null
				and isnull(dsReg.RegionEndDate, cast(p.parameterValue as date)) between dsEnr.EnrollStartDate and isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date))
			)
			or (
				dsEnr.EnrollStartDate between dsReg.RegionStartDate and isnull(dsReg.RegionEndDate , cast(p.parameterValue as date))
				or isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date)) between dsReg.RegionStartDate and isnull(dsReg.RegionEndDate , cast(p.parameterValue as date))
			)
		)
		-- tier 2: (2) compare to rating category
		and (
			dsRat.RatingCategoryStartDate is null 
			or (
				dsReg.RegionStartDate between dsRat.RatingCategoryStartDate and isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date))
				or (dsReg.RegionStartDate is not null
					and isnull(dsReg.RegionEndDate, cast(p.parameterValue as date)) between dsRat.RatingCategoryStartDate and isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date))
				)
			)
			or (
				dsRat.RatingCategoryStartDate between dsReg.RegionStartDate and isnull(dsReg.RegionEndDate , cast(p.parameterValue as date))
				or isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date)) between dsReg.RegionStartDate and isnull(dsReg.RegionEndDate , cast(p.parameterValue as date))
			)
		)

	LEFT join CCAMemberSpanPatientPay as dsPat on dsPat.CCAID = mem.CCAID and dsPat.ActiveFlag = 1
		-- tier 3: (1) compare to enrollment
		and (
			dsPat.PatientPayStartDate between dsEnr.EnrollStartDate and isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date))
			or (dsPat.PatientPayStartDate is not null
				and isnull(dsPat.PatientPayEndDate, cast(p.parameterValue as date)) between dsEnr.EnrollStartDate and isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date))
			)
		)
		-- tier 3: (2) compare to rating category
		and (
			dsRat.RatingCategoryStartDate is null
			or (
				dsPat.PatientPayStartDate between dsRat.RatingCategoryStartDate and isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date))
				or (dsPat.PatientPayStartDate is not null
					and isnull(dsPat.PatientPayEndDate, cast(p.parameterValue as date)) between dsRat.RatingCategoryStartDate and isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date))
				)
			)
		)
		-- tier 3: (3) compare to region
		and (
			dsReg.RegionStartDate is null
			or (
				dsPat.PatientPayStartDate between dsReg.RegionStartDate and isnull(dsReg.RegionEndDate, cast(p.parameterValue as date))
				or (dsPat.PatientPayStartDate is not null
					and isnull(dsPat.PatientPayEndDate, cast(p.parameterValue as date)) between dsReg.RegionStartDate and isnull(dsReg.RegionEndDate, cast(p.parameterValue as date))
				)
			)
		)

	LEFT join CCAMemberSpanPatientSpendDown as dsSpd on dsSpd.CCAID = mem.CCAID and dsSpd.ActiveFlag = 1
		-- tier 4: (1) compare to enrollment
		and (
			dsSpd.PatientSpendDownStartDate between dsEnr.EnrollStartDate and isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date))
			or (dsSpd.PatientSpendDownStartDate is not null
				and isnull(dsSpd.PatientSpendDownEndDate, cast(p.parameterValue as date)) between dsEnr.EnrollStartDate and isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date))
			)
		)
		-- tier 4: (2) compare to rating category
		and (
			dsRat.RatingCategoryStartDate is null
			or (
				dsSpd.PatientSpendDownStartDate between dsRat.RatingCategoryStartDate and isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date))
				or (dsSpd.PatientSpendDownStartDate is not null
					and isnull(dsSpd.PatientSpendDownEndDate, cast(p.parameterValue as date)) between dsRat.RatingCategoryStartDate and isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date))
				)
			)
		)
		-- tier 4: (3) compare to region
		and (
			dsReg.RegionStartDate is null
			or (
				dsSpd.PatientSpendDownStartDate between dsReg.RegionStartDate and isnull(dsReg.RegionEndDate, cast(p.parameterValue as date))
				or (dsSpd.PatientSpendDownStartDate is not null
					and isnull(dsSpd.PatientSpendDownEndDate, cast(p.parameterValue as date)) between dsReg.RegionStartDate and isnull(dsReg.RegionEndDate, cast(p.parameterValue as date))
				)
			)
		)
		-- tier 4: (4) compare to patient pay
		and (
			dsPat.PatientPayStartDate is null
			or (
				dsSpd.PatientSpendDownStartDate between dsPat.PatientPayStartDate and isnull(dsPat.PatientPayEndDate, cast(p.parameterValue as date))
				or (dsSpd.PatientSpendDownStartDate is not null
					and isnull(dsSpd.PatientSpendDownStartDate, cast(p.parameterValue as date)) between dsPat.PatientPayStartDate and isnull(dsPat.PatientPayEndDate, cast(p.parameterValue as date))
				)
			)
		)
	-- would this help or hurt performance
	-- left join -- select * from  vwRateCard
	left join ccaratecells as rat on rat.CCARateCell = case dsEnr.product when 'SCO' then left(dsRat.RatingCategory,3) else dsRat.RatingCategory end
	-- left join ccaregions as reg on reg.CCARegion = case  dsEnr.product when 'SCO' then right(dsRat.RatingCategory,3) else dsReg.Region end
	left join ccaregions as reg on reg.CCARegion = dsReg.Region 

-- can I remove this here... everything in vwExpectedPayments
	left join RateCard as rc 
		on rc.ActiveFlag = 1
		and rc.CCARateCellID = rat.CCARateCellID 
		and rc.CCARegionID = reg.CCARegionID

		-- do we need the additional range verification with end date... counts in unit test line up?
		-- never mind all this, should be month-to-month
		and (
			dsEnr.EnrollStartDate between rc.StartDate and isnull(rc.EndDate, cast(p.parameterValue as date))
			or (
				dsEnr.EnrollStartDate is not null
				and isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date)) between rc.StartDate and isnull(rc.EndDate, cast(p.parameterValue as date))
			
			)
		)
		and (dsRat.RatingCategoryStartDate is null 
			or (
				dsRat.RatingCategoryStartDate between rc.StartDate and isnull(rc.EndDate, cast(p.parameterValue as date))
				or (dsRat.RatingCategoryStartDate is not null
					and isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date)) between rc.StartDate and isnull(rc.EndDate, cast(p.parameterValue as date))
				)
			)
		)
		and (dsReg.RegionStartDate is null
			or (
				dsReg.RegionStartDate between rc.StartDate and isnull(rc.EndDate, cast(p.parameterValue as date))
				or (dsReg.RegionStartDate is not null
					and isnull(dsReg.RegionEndDate, cast(p.parameterValue as date)) between rc.StartDate and isnull(rc.EndDate, cast(p.parameterValue as date))
				)
			)
		)

		
		/*
		-- lots of joins to verify correct date
		and getdate() between dsEnr.EnrollStartDate and isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date)) -- confirms currently enrolled
		and getdate() between dsRat.RatingCategoryStartDate and isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date))
		and getdate() between dsReg.RegionStartDate and isnull(dsReg.RegionEndDate, cast(p.parameterValue as date))
		and getdate() between rc.StartDate and isnull(rc.EndDate, cast(p.parameterValue as date)) -- gets match based on rate card matching enrollment period

		
		-- first try, opposite direction
		and rc.StartDate between dsEnr.EnrollStartDate and isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date))
		and rc.StartDate between dsRat.RatingCategoryStartDate and isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date))
		and rc.StartDate between dsReg.RegionStartDate and isnull(dsReg.RegionEndDate, cast(p.parameterValue as date))
		and rc.EndDate between dsEnr.EnrollStartDate and isnull(dsEnr.EnrollEndDate, cast(p.parameterValue as date))
		and rc.EndDate between dsRat.RatingCategoryStartDate and isnull(dsRat.RatingCategoryEndDate, cast(p.parameterValue as date))
		and rc.EndDate between dsReg.RegionStartDate and isnull(dsReg.RegionEndDate, cast(p.parameterValue as date))

		*/
	where p.parameterName = 'OpenEndDate'
		and mem.ActiveFlag = 1
		and dsEnr.ActiveFlag = 1
	
GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwCCAMemberData] TO [Talend] 
GRANT SELECT ON [dbo].[vwCCAMemberData] TO [Support] 
GRANT SELECT ON [dbo].[vwCCAMemberData] TO [webapp] 
GO
-- *****************************************************************************************************
