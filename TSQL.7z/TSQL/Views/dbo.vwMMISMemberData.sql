
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwMMISMemberData]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwMMISMemberData]') AND type in (N'V'))
DROP VIEW [dbo].[vwMMISMemberData]
GO

/****** Object:  View [dbo].[vwMMISMemberData]    Script Date: 07/22/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/22/2019
-- Description:	Views member data from MMIS  relevant for reconciliation. Based on 8200 files.  Used in processing, NOT UI

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 0:13 seconds
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwMMISMemberData] AS

select 
	  MemberID	
	, LastName	
	, FirstName	
	, MiddleInitial	
	, Suffix
	, CapitationMonthYear
from (
	select 
		  MemberID	
		, LastName	
		, FirstName	
		, MiddleInitial	
		, Suffix
		-- , count(*) as countPaymentEntries
		, CapitationMonthYear
		, row_number() over(partition by MemberID order by CapitationMonthYear desc) as rnLatestMemberEntry
	from PDRIn.DBO.MMIS8200MDetail
	-- where CapitationMonthYear >= '2019-01-01'
	-- order by MemberID, CapitationMonthYear desc
) as mmis
where mmis.rnLatestMemberEntry = 1



GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwMMISMemberData] TO [Talend] 
GRANT SELECT ON [dbo].[vwMMISMemberData] TO [Support] 
-- GRANT SELECT ON [dbo].[vwMMISMemberData] TO [webapp] -- USED FOR INTERNAL PROCESSING.  Not part of the model
GO
-- *****************************************************************************************************

