
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwMonthEndOutput]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwMonthEndOutput]') AND type in (N'V'))
DROP VIEW [dbo].[vwMonthEndOutput]
GO

/****** Object:  View [dbo].[vwMonthEndOutput]    Script Date: 08/21/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/21/2019
-- Description:	This view will format the monthly close record details required for month end import in the CCA Financial data warehouse.

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwMonthEndOutput] AS

	select 
		 (mm.CCAID - BrowneConstant) as member_id -- is this subtracting Browne's constant?
		,mcr.MemberMonth             as member_month
		,mhr.ReportMonth             as Assessment_date -- where should we get this from?
		,mem.NAME_ID                 as mpMemberID -- is this CCAID
		,isnull(ccaLeg.LegacyCode, ccaLeg.CCARateCell) as Org_Rating_category 
		,isnull(mmisLeg.LegacyCode, mmisLeg.CCARateCell) as Payor_Rating
		,ccaRateCard.Amount          as Contract_Rate -- should this be linked to CCA instead?
		,mmisRateCard.Amount         as Org_Premium -- calculate this differently?
		,mcr.PaidCapitationAmount    as Payor_Premium -- calculate this differently?
		,mcr.CCAPatientSpendDown     as Org_Spend_Down
		,mcr.MMISPatientSpendDown    as Payor_Spend_Down
		,mcr.CCAPatientPay           as Org_Patient_Pay
		,mcr.MMISPatientPay          as Payor_Patient_Pay
		,mcr.PaymentError            as Unexplained
	-- select top 10 * 
	from MonthlyCloseRecord as mcr
	cross join (select parameterValue as BrowneConstant from listParameters where ApplicationName = 'RevRec' and parameterName = 'BrowneConstant') as p
	inner join MonthlyCloseHeader as mhr on mhr.MonthlyCloseHeaderID = MCR.MonthlyCloseHeaderID
	inner join MemberMap as mm on mm.MasterPatientID = mcr.MasterPatientID
	inner join CCAMemberData as mem on mem.CCAID = mm.CCAID

	inner join vwRateCard as mmisRateCard on mmisRateCard.RateCardID = mcr.MMISRateCardID
	-- inner join CCARateCells as mmisRat on mmisRat.CCARateCellID = mmisRateCard.CCARateCellID
	-- inner join CCARegions as mmisReg on mmisReg.CCARegionID = mmisRateCard.CCARegionID
	inner join CCARatingCategoryLegacy as mmisLeg  
		on mmisLeg.CCARateCell = mmisRateCard.CCARateCell 
		AND mmisLeg.CCARegion = mmisRateCard.CCARegion

	inner join vwRateCard as ccaRateCard on ccaRateCard.RateCardID = mcr.CCARateCardID
	-- inner join CCARateCells as mmisRat on mmisRat.CCARateCellID = mmisRateCard.CCARateCellID
	-- inner join CCARegions as mmisReg on mmisReg.CCARegionID = mmisRateCard.CCARegionID
	inner join CCARatingCategoryLegacy as ccaLeg  
		on ccaLeg.CCARateCell = ccaRateCard.CCARateCell 
		AND ccaLeg.CCARegion =  ccaRateCard.CCARegion

GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwMonthEndOutput] TO [Talend] 
GRANT SELECT ON [dbo].[vwMonthEndOutput] TO [Support] 
GRANT SELECT ON [dbo].[vwMonthEndOutput] TO [webapp] 

GO
-- *****************************************************************************************************
