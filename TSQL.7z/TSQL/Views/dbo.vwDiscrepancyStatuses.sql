
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwDiscrepancyStatuses]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwDiscrepancyStatuses]') AND type in (N'V'))
DROP VIEW [dbo].[vwDiscrepancyStatuses]
GO

/****** Object:  View [dbo].[vwDiscrepancyStatuses]    Script Date: 08/20/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/20/2019
-- Description:	View for Discrepancy Statuses
				Presents results as returned from API spGetDiscrepancyStatus

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwDiscrepancyStatuses] AS

	select 
		ds.DiscrepancyStatusID, ds.DiscrepancyStatus, ds.DiscrepancyStatusDescription, ds.DiscrepancyCategoryID, ds.DiscrepancyStatusType, ds.ActiveFlag, ds.insertDate, ds.updateDate
		, dc.DiscrepancyCategory, dc.DiscrepancyCategoryDescription
	from discrepancyStatuses as ds
	inner join DiscrepancyCategories as dc on dc.DiscrepancyCategoryID = ds.DiscrepancyCategoryID
	where ds.ActiveFlag = 1
		and dc.ActiveFlag = 1





GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwDiscrepancyStatuses] TO [Talend] 
GRANT SELECT ON [dbo].[vwDiscrepancyStatuses] TO [Support] 
GRANT SELECT ON [dbo].[vwDiscrepancyStatuses] TO [webapp] 
GO
-- *****************************************************************************************************
