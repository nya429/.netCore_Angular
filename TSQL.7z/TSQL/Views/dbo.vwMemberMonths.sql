
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwMemberMonths]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwMemberMonths]') AND type in (N'V'))
DROP VIEW [dbo].[vwMemberMonths]
GO

/****** Object:  View [dbo].[vwMemberMonths]    Script Date: 01/11/2020 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author: Shubham Pathak
-- Create date: 12/20/2019
-- Description:	List of all the Member Months

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwMemberMonths] AS 


select distinct membermonth from monthlySummaryRecord





GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwMemberMonths] TO [Talend] 
GRANT SELECT ON [dbo].[vwMemberMonths] TO [Support] 
GRANT SELECT ON [dbo].[vwMemberMonths] TO [webapp] 
GO
-- *****************************************************************************************************
