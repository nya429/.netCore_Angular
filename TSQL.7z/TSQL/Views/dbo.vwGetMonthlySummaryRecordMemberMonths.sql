
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwGetMonthlySummaryRecordMemberMonths]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwGetMonthlySummaryRecordMemberMonths]') AND type in (N'V'))
DROP VIEW [dbo].[vwGetMonthlySummaryRecordMemberMonths]
GO

/****** Object:  View [dbo].[vwGetMonthlySummaryRecordMemberMonths]    Script Date: 09/05/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/05/2019
-- Description:	Model for spGetMonthlySummaryRecordMemberMonths

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwGetMonthlySummaryRecordMemberMonths] AS


	select 
		MonthlySummaryRecordID
		,MasterPatientID
		,MMIS_ID
		,MemberMonth
		,Variance
		,PaymentError
		,BaseCapitationAmount
		,PatientPayAmountN
		,PatientPayAmountSCO
		,PaidCapitationAmount
		,CCARateCellID
		,CCARegionID
		,CCAPatientPay
		,CCAPatientSpendDown
		,CCARateCardID
		,CCAAmount
		,CCANetAmount
		,MMISRateCellID
		,MMISRegionID
		,MMISPatientPay
		,MMISPatientSpendDown
		,MMISRateCardID
		,MMISAmount
		,MMISNetAmount
	from MonthlySummaryRecord 





GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwGetMonthlySummaryRecordMemberMonths] TO [Talend] 
GRANT SELECT ON [dbo].[vwGetMonthlySummaryRecordMemberMonths] TO [Support] 
GRANT SELECT ON [dbo].[vwGetMonthlySummaryRecordMemberMonths] TO [webapp] 
GO
-- *****************************************************************************************************
