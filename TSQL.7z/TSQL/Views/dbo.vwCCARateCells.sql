
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwCCARateCells]
order by Product, CCARateCell

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwCCARateCells]') AND type in (N'V'))
DROP VIEW [dbo].[vwCCARateCells]
GO

/****** Object:  View [dbo].[vwCCARateCells]    Script Date: 07/17/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		
-- Create date: 07/17/2019
-- Description:	

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwCCARateCells] AS



select 
	CCARateCellID
	,CCARateCell
	,Product
	,ActiveFlag
	,insertDate
	,updateDate
from CCARateCells




GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwCCARateCells] TO [Talend] 
GRANT SELECT ON [dbo].[vwCCARateCells] TO [Support] 
GRANT SELECT ON [dbo].[vwCCARateCells] TO [webapp] 
GO
-- *****************************************************************************************************
