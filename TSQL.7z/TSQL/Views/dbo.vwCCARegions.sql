
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwCCARegions]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwCCARegions]') AND type in (N'V'))
DROP VIEW [dbo].[vwCCARegions]
GO

/****** Object:  View [dbo].[vwCCARegions]    Script Date: 07/08/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		
-- Create date: 07/08/2019
-- Description:	

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwCCARegions] AS

select 
	CCARegionID
	,CCARegion
	,Product
	,ActiveFlag
	,insertDate
	,updateDate

from CCARegions

GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwCCARegions] TO [Talend] 
GRANT SELECT ON [dbo].[vwCCARegions] TO [Support] 
GRANT SELECT ON [dbo].[vwCCARegions] TO [webapp] 
GO
-- *****************************************************************************************************
