
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwProcessMMISRateCells]
order by Product, MMISRateCell

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwProcessMMISRateCells]') AND type in (N'V'))
DROP VIEW [dbo].[vwProcessMMISRateCells]
GO

/****** Object:  View [dbo].[vwProcessMMISRateCells]    Script Date: 07/17/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/17/2019
-- Description:	Processing view for MMIS source data
				
				Post QA - 09/15/2019
					Added Rtrim to MMISRateCell

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 0:01 seconds
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwProcessMMISRateCells] AS



select 
rtrim(RateCell) as MMISRateCell
, case right(reportname, 1) when 'A' then 'SCO' when 'B' then 'ICO' else NULL end as Product
, MIN(PaymentPeriodStart) as Min_PaymentPeriodStart
, MAX(PaymentPeriodEnd) as Max_PaymentPeriodEnd
, COUNT(*) AS CountByMMISRateCell 
from PDRIn.DBO.MMIS8200MDetail
GROUP BY RateCell  
, case right(reportname, 1) when 'A' then 'SCO' when 'B' then 'ICO' else NULL end
-- order by Product, MMISRateCell



GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwProcessMMISRateCells] TO [Talend] 
GRANT SELECT ON [dbo].[vwProcessMMISRateCells] TO [Support] 
GO
-- *****************************************************************************************************
