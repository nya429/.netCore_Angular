
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwMemberData]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwMemberData]') AND type in (N'V'))
DROP VIEW [dbo].[vwMemberData]
GO

/****** Object:  View [dbo].[vwMemberData]    Script Date: 08/27/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 08/27/2019
-- Description:	Model for entity framework
				View for all member data

				Unit-test: 10/07/2019
					Removed join to MMISMemberData on MasterPatientID.  No longer valid
				

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwMemberData] AS

	-- could consider CTE to bring in parameters for use in final query

	select 
		  m.MasterPatientID       -- ID
		, m.CCAID				  -- CCAID
		, m.MMIS_MMIS_ID		  -- MMIS_ID
		-- was CCA before
		, isnull(m.CCA_MemberFirstName , m.MMIS_MemberFirstName  ) as MemberFirstName -- NAME
		, isnull(m.CCA_MemberMiddleName, m.MMIS_MemberMiddleName ) as MemberMiddleName-- NAME
		, isnull(m.CCA_MemberLastName  , m.MMIS_MemberLastName   ) as MemberLastName  -- NAME 
		, ccaMem.Gender
		, ccaMem.DOB              -- dateOfBirth
		, '' as DOD               -- dateOfDeath -- needs to be added to member
		, ccaMem.Product          -- Program
		, ccaMem.EnrollStartDate  -- enrollmentStart
		, ccaMem.EnrollEndDate    -- enrollmentEnd

		, ccaMem.RatingCategory
		, ccaMem.RatingCategoryStartDate
		, ccaMem.RatingCategoryEndDate
		, ccaMem.Region
		, ccaMem.RegionStartDate
		, ccaMem.RegionEndDate
		, ccaMem.PatientPay
		, ccaMem.PatientPayStartDate
		, ccaMem.PatientPayEndDate
		, ccaMem.PatientSpendDown
		, ccaMem.PatientSpendDownStartDate
		, ccaMem.PatientSpendDownEndDate
		, ccaMem.RateCardID
		, ccaMem.CCARateCellID
		, ccaMem.CCARegionID
		, ccaMem.Amount
		, ccaMem.StartDate
		, ccaMem.EndDate
		, ccaMem.ActiveFlag

		, case 
			when m.CCAID is null
				then 'Never enrolled' -- 0
			when getdate() between ccaMem.EnrollStartDate and isnull(ccaMem.EnrollEndDate, '2999-12-31') -- @openEndDate
				then 'Currently enrolled' -- 1 
			else 'Not currently enrolled' -- 2
		end as MemberEnrollmentStatus
		, cast(null as int) as totalDiscrepancies		  -- place holder for screen
		, cast(null as int) as maxAging				  -- place holder for screen
		, cast(null as numeric(18,2)) as absoluteVarianceSum -- place holder for screen
		-- add member details
	from vwMemberMap as m
	-- left join vwCCAMemberData as ccaMem on ccaMem.CCAID = m.CCAID -- original join, before rank
	left join (
		select mem.CCAID, mem.MMIS_ID, mem.MemberFirstName, mem.MemberMiddleName, mem.MemberLastName, mem.Gender, mem.DOB, mem.DOD, mem.Product, mem.EnrollStartDate, mem.EnrollEndDate, mem.RatingCategory, mem.RatingCategoryStartDate, mem.RatingCategoryEndDate, mem.Region, mem.RegionStartDate, mem.RegionEndDate, mem.PatientPay, mem.PatientPayStartDate, mem.PatientPayEndDate, mem.PatientSpendDown, mem.PatientSpendDownStartDate, mem.PatientSpendDownEndDate, mem.RateCardID, mem.CCARateCellID, mem.CCARegionID, mem.Amount, mem.StartDate, mem.EndDate, mem.ActiveFlag
			--   mem.CCAID
			-- , mem.Product          -- Program
			-- , mem.EnrollStartDate  -- enrollmentStart
			-- , mem.EnrollEndDate    -- enrollmentEnd
			-- , mem.DOB              -- dateOfBirth
			-- , '' as DOD               -- dateOfDeath -- needs to be added to member
			-- , mem.RatingCategory   -- 
			-- , mem.Region


			-- do we need end date desc, too?... other date ranges should not be used... already aligned in the view
			, row_number() over (partition by mem.CCAID order by mem.EnrollStartDate           desc) as rnEnroll
			-- , row_number() over (partition by mem.CCAID order by mem.RatingCategoryStartDate   desc) as rnRatingCategory
			-- , row_number() over (partition by mem.CCAID order by mem.RegionStartDate           desc) as rnRegion
			-- , row_number() over (partition by mem.CCAID order by mem.PatientPayStartDate       desc) as rnPatientPay
			-- , row_number() over (partition by mem.CCAID order by mem.PatientSpendDownStartDate desc) as rnPatientSpendDown

		from vwCCAMemberData as mem
	) as ccaMem on ccaMem.CCAID = m.CCAID
		and ccaMem.rnEnroll           = 1
		-- and ccaMem.rnRatingCategory   = 1
		-- and ccaMem.rnRegion           = 1
		-- and ccaMem.rnPatientPay       = 1
		-- and ccaMem.rnPatientSpendDown = 1
	-- left join MMISMemberData as mmisMem on mmisMem.MasterPatientID = m.MasterPatientID




GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwMemberData] TO [Talend] 
GRANT SELECT ON [dbo].[vwMemberData] TO [Support] 
GRANT SELECT ON [dbo].[vwMemberData] TO [webapp] 
GO
-- *****************************************************************************************************
