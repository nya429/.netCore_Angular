
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwGetDiscrepancyList]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwGetDiscrepancyList]') AND type in (N'V'))
DROP VIEW [dbo].[vwGetDiscrepancyList]
GO

/****** Object:  View [dbo].[vwGetDiscrepancyList]    Script Date: 09/05/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/05/2019
-- Description:	Model: View for spGetDiscrepancyList

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwGetDiscrepancyList] AS


	select 
		 d.DiscrepancyID
		,d.MonthlySummaryRecordID
		,d.MasterPatientID
		,M.MemberFirstName
		,m.MemberLastName
		,d.MemberMonth
		,m.Product
		,d.Variance
		,ISNULL(d.PaymentError, 0.00) AS PaymentError
		,d.BaseCapitationAmount
		,d.PatientPayAmountN
		,d.PatientPayAmountSCO
		,d.PaidCapitationAmount
		,d.CCARateCellID
		,d.CCARegionID
		,isnull(ccarc.CCARateCell        , '99') as CCARateCell        
		,isnull(ccareg.CCARegion         , 'NA') as CCARegion         
		,ISNULL(d.CCAPatientPay		 , 0.00) AS CCAPatientPay		 
		,ISNULL(d.CCAPatientSpendDown, 0.00) AS CCAPatientSpendDown
		,d.CCARateCardID
		,d.CCAAmount
		,d.CCANetAmount
		,ISNULL(d.MMISRateCellID , CAST(0 AS INT)) AS MMISRateCellID 
		,ISNULL(d.MMISRegionID   , CAST(0 AS INT)) AS MMISRegionID   
		,isnull(mmisrc.MMISRateCell		 , '99') as MMISRateCell
		,isnull(mmisreg.MMISRegion       , 'NA') as MMISRegion
		,d.MMISPatientPay
		,d.MMISPatientSpendDown
		,ISNULL(d.MMISRateCardID, CAST(0 AS INT)) AS MMISRateCardID
		,ISNULL(d.MMISAmount, 0.00) AS MMISAmount
		,d.MMISNetAmount
		,d.TypeRateCell
		,d.TypeRegion
		,d.TypePatientPay
		,d.TypePatientSpendDown
		,d.TypePaymentError
		,d.Assigned_UserID
		,uAss.UserNameAD as Assigned_UserName
		,d.Action_UserID
		,uAct.UserNameAD as Action_UserName
		,d.DiscrepancyStatusID
		,ds.DiscrepancyStatus
		,d.DueDate
		,d.DiscoverDate
		,d.ResolvedDate
		,d.Balanced
		,d.ActiveFlag
		,d.insertDate
		,d.updateDate
		/*
		,dc.DiscrepancyCommentID	
		-- ,dc.DiscrepancyID	
		,dc.ReplyCommentID as ReplyDiscrepancyCommentID	
		,dc.Comment_UserID	
		,dc.DiscrepancyComment	
		,dc.ActiveFlag as DiscrepancyComment_ActiveFlag		
		,dc.insertDate as DiscrepancyComment_insertDate		
		,dc.updateDate as DiscrepancyComment_updateDate
		*/
		,m.MMIS_MMIS_ID
		,m.CCAID
		-- , count(*) over() as ResultCount
	from Discrepancies as d
	inner join MemberList as m on m.MasterPatientID = d.MasterPatientID
	-- inner join vwMemberMap as mm on mm.MasterPatientID = d.MasterPatientID
	left join DiscrepancyStatuses as ds on ds.DiscrepancyStatusID = d.DiscrepancyStatusID
	left join users as uAct on uAct.UserID = d.Action_UserID
	left join users as uAss on uAss.UserID = d.Assigned_UserID

		-- join for actual vaulues... maybe reevaluate pulling it into discrepancies table itself
		left join MMISRateCells	 AS mmisrc  on mmisrc.MMISRateCellID   = d.MMISRateCellID
		left join MMISRegions	 AS mmisreg on mmisreg.MMISRegionID    = d.MMISRegionID
		left join CCARateCells	 AS ccarc   on ccarc.CCARateCellID     = d.CCARateCellID
		left join CCARegions     AS ccareg  on ccareg.CCARegionID      = d.CCARegionID 
		-- left join MMISMemberData as mmismem on mmismem.MasterPatientID = d.MasterPatientID




GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwGetDiscrepancyList] TO [Talend] 
GRANT SELECT ON [dbo].[vwGetDiscrepancyList] TO [Support] 
GRANT SELECT ON [dbo].[vwGetDiscrepancyList] TO [webapp] 
GO
-- *****************************************************************************************************
