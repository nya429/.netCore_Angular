
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwMemberMap]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwMemberMap]') AND type in (N'V'))
DROP VIEW [dbo].[vwMemberMap]
GO

/****** Object:  View [dbo].[vwMemberMap]    Script Date: 07/23/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/23/2019
-- Description:	View to show member map between MMIS and CCA members.
				Missing map for master patient ID indicates member missing from CCA (MP)

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwMemberMap] AS


select distinct
	  mm.MemberMapID	
	, mm.MasterPatientID	
	, mm.CCAID	
	, c.MemberFirstName	   as CCA_MemberFirstName
	, c.MemberMiddleName   as CCA_MemberMiddleName
	, c.MemberLastName	   as CCA_MemberLastName
	-- , c.Gender			   as CCA_Gender
	-- , c.DOB				   as CCA_DOB
	, c.MMIS_ID            as CCA_MMIS_ID
	, s.MemberFirstName	   as MMIS_MemberFirstName
	, s.MemberMiddleName   as MMIS_MemberMiddleName
	, s.MemberLastName	   as MMIS_MemberLastName
	, s.MMIS_ID            as MMIS_MMIS_ID
	, mm.ActiveFlag	
	, mm.insertDate	
	, mm.updateDate
	
from MemberMap as mm
-- inner join MMISMemberData as s on s.MasterPatientID = mm.MasterPatientID
inner join MasterPatientManagement as s on s.MasterPatientID = mm.MasterPatientID
left join CCAMemberData as c on c.CCAID = mm.CCAID 




GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwMemberMap] TO [Talend] 
GRANT SELECT ON [dbo].[vwMemberMap] TO [Support] 
GRANT SELECT ON [dbo].[vwMemberMap] TO [WEBAPP] 
GO
-- *****************************************************************************************************
