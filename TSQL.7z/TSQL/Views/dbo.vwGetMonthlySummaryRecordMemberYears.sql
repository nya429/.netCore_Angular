
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwGetMonthlySummaryRecordMemberYears]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwGetMonthlySummaryRecordMemberYears]') AND type in (N'V'))
DROP VIEW [dbo].[vwGetMonthlySummaryRecordMemberYears]
GO

/****** Object:  View [dbo].[vwGetMonthlySummaryRecordMemberYears]    Script Date: 09/05/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/05/2019
-- Description:	Model for spGetMonthlySummaryRecordMemberYears

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwGetMonthlySummaryRecordMemberYears] AS

	-- query is not identical to API stored procedure due to parameterized logic and temp tables.
	-- these results will provide a model for entity framework, though
	select 
		distinct year(MemberMonth) as MemberYear -- get all member months available
		,0 as Gap
	from MonthlySummaryRecord  





GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwGetMonthlySummaryRecordMemberYears] TO [Talend] 
GRANT SELECT ON [dbo].[vwGetMonthlySummaryRecordMemberYears] TO [Support] 
GRANT SELECT ON [dbo].[vwGetMonthlySummaryRecordMemberYears] TO [webapp] 
GO
-- *****************************************************************************************************
