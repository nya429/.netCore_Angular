
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwRegionMap]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwRegionMap]') AND type in (N'V'))
DROP VIEW [dbo].[vwRegionMap]
GO

/****** Object:  View [dbo].[vwRegionMap]    Script Date: 07/08/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/08/2019
-- Description:	Model - View for seeing Region map

				Post Unit Test - 09/27/2019
					needed webapp permissions, getting denied on select error

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwRegionMap] AS


select 
	  m.RegionMapID	
	, m.CCARegionID	
	, C.CCARegion
	, m.MMISRegionID	
	, S.MMISRegion
	, m.ActiveFlag	
	, m.insertDate	
	, m.updateDate
from RegionMap AS m
inner join CCARegions as c on C.CCARegionID = M.CCARegionID
inner join MMISRegions as s on s.MMISRegionID = M.MMISRegionID




GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwRegionMap] TO [Talend] 
GRANT SELECT ON [dbo].[vwRegionMap] TO [Support] 
GRANT SELECT ON [dbo].[vwRegionMap] TO [webapp] 
GO
-- *****************************************************************************************************
