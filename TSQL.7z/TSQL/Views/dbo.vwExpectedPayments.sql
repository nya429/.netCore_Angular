
USE [RevRec]
GO


/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwExpectedPayments]
order by CCAID, MasterMemberMonth

missing 17037 of 618614 rate cards - less than 3% error

SELECT * FROM vwCCAMemberData where CCAID = '5364521807'
select * from CCAMemberSpanRegion where CCAID = '5364521807'

select * from listParameters where parameterName = 'BrowneConstant'
select * from listParameters where parameterName = 'OpenEndDate'

if object_id('tempdb..#testexpect') is not null
	drop table #testexpect 
SELECT * into #testexpect FROM [dbo].[vwExpectedPayments]

select top 10 * from #testexpect

select MasterMemberMonth, CCAID, count(*) as dupCheck
from #testexpect
group by MasterMemberMonth, CCAID
having count(*) > 1
order by dupCheck desc, MasterMemberMonth, CCAID

select * 
from #testexpect
where MasterMemberMonth = '2019-02-01'
and CCAID = 5365600581


select * 
from #testexpect
where MasterMemberMonth = '2018-01-01'
and CCAID = 5364522639

select * 
from #testexpect
where MasterMemberMonth = '2018-01-01'
and CCAID = 5364524253



select * 
from #testexpect
where MasterMemberMonth = '2018-01-01'
and CCAID in (
	5365551648
	,5365557770
	,5365558843
)


select * from CCARegions
-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwExpectedPayments]') AND type in (N'V'))
DROP VIEW [dbo].[vwExpectedPayments]
GO

/****** Object:  View [dbo].[vwExpectedPayments]    Script Date: 10/08/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 10/08/2019
-- Description:	View to show member months for CCA members

-- Modified by: Jonathan Lewis
-- Modified dt: 01/13/2020
-- Description: ADS-2939
				IGNORE: For region, match to SCO right 3 characters only if region is not 'CSTAT'
				Region computed for SCO at import time... no need to separate RatingCategory to get region.

-- EXEC Time: 0:56 seconds
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwExpectedPayments] AS


select distinct -- distinct used to get to single entry for rate card per month... vwCCAMemberData may match against multiple rate cards for a given range.
	mm.MasterMemberMonth
	, mem.CCAID	
	, mem.MMIS_ID	
	, mem.MemberFirstName	
	, mem.MemberMiddleName	
	, mem.MemberLastName	
	, mem.Gender	
	, mem.DOB	
	, mem.DOD	
	, mem.Product	
	, mem.EnrollStartDate	
	, mem.EnrollEndDate	
	, mem.RatingCategory	
	, mem.RatingCategoryStartDate	
	, mem.RatingCategoryEndDate	
	, mem.Region	
	, mem.RegionStartDate	
	, mem.RegionEndDate	
	, mem.PatientPay	
	, mem.PatientPayStartDate	
	, mem.PatientPayEndDate	
	, mem.PatientSpendDown	
	, mem.PatientSpendDownStartDate	
	, mem.PatientSpendDownEndDate
-- 	, mem.RateCardID	
-- 	, mem.CCARateCellID	
-- 	, mem.CCARegionID	
-- 	, mem.Amount	
-- 	, mem.StartDate	
-- 	, mem.EndDate	
-- 	, mem.ActiveFlag


	, rc.RateCardID	
	, rc.CCARateCellID	
	, rc.CCARateCell	
	, rc.CCARegionID	
	, rc.CCARegion	
	, rc.StartDate	
	, rc.EndDate	
	, rc.Amount	
	, rc.RateCardLabel	
	, rc.Eligibility	
	, rc.EligibilityStatus	
	-- , rc.Product	
	, rc.ActiveFlag	
	, rc.insertDate	
	, rc.updateDate

from vwCCAMemberData as mem
inner join (
	select distinct CapitationMonthYear as MasterMemberMonth 
	from PaymentDetailPaid as pdp
	cross join (
		select parameterValue as LookbackDate from listParameters where parameterName = 'LookbackDate'
	) as lbd 
	where pdp.CapitationMonthYear >= lbd.LookbackDate
	-- order by MasterMemberMonth 
) as mm 
	on (mm.MasterMemberMonth between mem.EnrollStartDate and isnull(mem.EnrollEndDate, '2999-12-31')) -- Product
	and (mem.RatingCategory	is null or mm.MasterMemberMonth between mem.RatingCategoryStartDate and isnull(mem.RatingCategoryEndDate, '2999-12-31')) -- Rate Cell
	and (mem.Region is null or mm.MasterMemberMonth between mem.RegionStartDate and isnull(mem.RegionEndDate, '2999-12-31')) -- Region
	and (mem.PatientPay is null or mm.MasterMemberMonth between mem.PatientPayStartDate and isnull(mem.PatientPayEndDate, '2999-12-31')) -- Patient Pay
	and (mem.PatientSpendDown is null or mm.MasterMemberMonth between mem.PatientSpendDownStartDate and isnull(mem.PatientSpendDownEndDate, '2999-12-31')) -- Spend Down


left join ccaratecells as rat on rat.CCARateCell = case mem.product when 'SCO' then left(mem.RatingCategory,3) else mem.RatingCategory end
left join ccaregions as reg on reg.CCARegion = mem.Region
/*
-- adjusting for CSTAT... but will just adjust at import time
	on reg.CCARegion = 
		case when mem.product = 'SCO' and mem.Region <> 'CSTAT' 
			then right(mem.RatingCategory,3)
		else mem.Region 
	end
*/
left join vwRateCard as rc 
	on rc.ActiveFlag = 1
	and rc.CCARateCellID = rat.CCARateCellID 
	and rc.CCARegionID = reg.CCARegionID

	-- do we need the additional range verification with end date... counts in unit test line up?
	-- never mind all this, should be month-to-month
	and mm.MasterMemberMonth between rc.StartDate and isnull(rc.EndDate, '2999-12-31')
	-- and dsRat.RatingCategoryStartDate between rc.StartDate and isnull(rc.EndDate, cast(p.parameterValue as date))

	-- SELECT * FROM VWRateCard

GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwExpectedPayments] TO [Talend] 
GRANT SELECT ON [dbo].[vwExpectedPayments] TO [Support] 
GO
-- *****************************************************************************************************
