
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwUsers]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwUsers]') AND type in (N'V'))
DROP VIEW [dbo].[vwUsers]
GO

/****** Object:  View [dbo].[vwUsers]    Script Date: 09/14/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/14/2019s
-- Description:	Model - view for displaying users

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwUsers] AS


		select 
			  u.UserID	
			, u.UserNameAD
			, u.UserEmail
			, u.UserFirstName
			, u.UserLastName
			, isnull(purm.Administrator, 0) as Administrator
			, isnull(purm.Helpdesk     , 0) as Helpdesk     
			, isnull(purm.Specialist   , 0) as Specialist   
			, isnull(purm.Supervisor   , 0) as Supervisor   
		from users as u
		-- this may need to be thought through more... user roles have to coincide with application access, so release fixes may be required when adding a role?
		left join (
			select 
				  urm.UserID
				, max(case ur.UserRoleID when 1 then urm.ActiveFlag else 0 end) as Administrator
				, max(case ur.UserRoleID when 2 then urm.ActiveFlag else 0 end) as Helpdesk
				, max(case ur.UserRoleID when 3 then urm.ActiveFlag else 0 end) as Supervisor
				, max(case ur.UserRoleID when 4 then urm.ActiveFlag else 0 end) as Specialist
			from UserRoleMap as urm
			inner join UserRoles as ur on ur.UserRoleID = urm.UserRoleID
			group by urm.UserID

		) as purm -- pivoted user role map
			on purm.UserID = u.UserID





GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwUsers] TO [Talend] 
GRANT SELECT ON [dbo].[vwUsers] TO [Support] 
GRANT SELECT ON [dbo].[vwUsers] TO [webapp] 
GO
-- *****************************************************************************************************
