
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwMMISRateCells]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwMMISRateCells]') AND type in (N'V'))
DROP VIEW [dbo].[vwMMISRateCells]
GO

/****** Object:  View [dbo].[vwMMISRateCells]    Script Date: 07/17/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/17/2019
-- Description:	Model: View MMIS Rate Cells: spGetMMISRateCells

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 0:01 seconds
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwMMISRateCells] AS



	select 
		  rc.MMISRateCellID	
		, rc.MMISRateCell	
		, rc.Product
		, case when isnull(rcm.ActiveFlag, 0) = 1 then 1 else 0 end as MMISRateCellMapActive
		, count(*) over() as ResultCount
 	from MMISRateCells as rc
	left join RateCellMap as rcm on rcm.MMISRateCellID = rc.MMISRateCellID
	where rc.ActiveFlag = 1



GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwMMISRateCells] TO [Talend] 
GRANT SELECT ON [dbo].[vwMMISRateCells] TO [Support] 
GRANT SELECT ON [dbo].[vwMMISRateCells] TO [webapp] 
GO
-- *****************************************************************************************************
