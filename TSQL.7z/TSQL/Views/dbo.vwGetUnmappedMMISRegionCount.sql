
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwGetUnmappedMMISRegionCount]

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwGetUnmappedMMISRegionCount]') AND type in (N'V'))
DROP VIEW [dbo].[vwGetUnmappedMMISRegionCount]
GO

/****** Object:  View [dbo].[vwGetUnmappedMMISRegionCount]    Script Date: 09/03/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 09/03/2019
-- Description:	View for Model: spGetUnmappedMMISRegionCount
				Returns count of unmapped MMIS Region Codes

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwGetUnmappedMMISRegionCount] AS



	select count(*) as UnmappedMMISRegionCount
 	from MMISRegions as r
	left join RegionMap as rm on rm.MMISRegionID = r.MMISRegionID
	where r.ActiveFlag = 1
		and (
			rm.ActiveFlag is null
			or rm.ActiveFlag = 0 
		)




GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwGetUnmappedMMISRegionCount] TO [Talend] 
GRANT SELECT ON [dbo].[vwGetUnmappedMMISRegionCount] TO [Support] 
GRANT SELECT ON [dbo].[vwGetUnmappedMMISRegionCount] TO [webapp] 
GO
-- *****************************************************************************************************
