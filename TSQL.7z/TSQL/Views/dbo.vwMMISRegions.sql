
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwMMISRegions]

-- region confirmed always populated in 8200:
select * 
from PDRIn.DBO.MMIS8200MDetail
where MCRegion is null

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwMMISRegions]') AND type in (N'V'))
DROP VIEW [dbo].[vwMMISRegions]
GO

/****** Object:  View [dbo].[vwMMISRegions]    Script Date: 07/08/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/08/2019
-- Description:	Model for MMIS Regions: spGetMMISRegions

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 0:04 seconds 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwMMISRegions] AS


	select 
		  r.MMISRegionID	
		, r.MMISRegion	
		, r.Product
		, case when isnull(rm.ActiveFlag, 0) = 1 then 1 else 0 end as MMISRegionMapActive
		, count(*) over() as ResultCount 
 	from MMISRegions as r
	left join RegionMap as rm on rm.MMISRegionID = r.MMISRegionID
	where r.ActiveFlag = 1


GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwMMISRegions] TO [Talend] 
GRANT SELECT ON [dbo].[vwMMISRegions] TO [Support] 
GRANT SELECT ON [dbo].[vwMMISRegions] TO [webapp] 
GO
-- *****************************************************************************************************
