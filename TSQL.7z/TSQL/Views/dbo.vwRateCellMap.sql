
USE [RevRec]
GO

/*
-- *****************************************************************************************************
-- Test Execution Block
SELECT * FROM [dbo].[vwRateCellMap]

select * from ccaRateCells
select * from mmisRateCells

-- *****************************************************************************************************
*/


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[vwRateCellMap]') AND type in (N'V'))
DROP VIEW [dbo].[vwRateCellMap]
GO

/****** Object:  View [dbo].[vwRateCellMap]    Script Date: 07/17/2019 00:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
-- *****************************************************************************************************
-- Author:		Jonathan Lewis
-- Create date: 07/17/2019
-- Description:	Model - View for seeing Rate Cell map

				Post Unit Test - 09/27/2019
					needed webapp permissions, getting denied on select error

-- Modified by: 
-- Modified dt: 
-- Description: 

-- EXEC Time: 
-- *****************************************************************************************************
*/

CREATE VIEW [dbo].[vwRateCellMap] AS




select 
	  m.RateCellMapID	
	, m.CCARateCellID	
	, C.CCARateCell
	, m.MMISRateCellID	
	, S.MMISRateCell
	, m.ActiveFlag	
	, m.insertDate	
	, m.updateDate
from RateCellMap AS m
inner join CCARateCells as c on C.CCARateCellID =  M.CCARateCellID
inner join MMISRateCells as s on s.MMISRateCellID = M.MMISRateCellID



GO


-- *****************************************************************************************************
-- Uncomment to provide permissions to Talend, or modify for another user/user groups execution
GRANT SELECT ON [dbo].[vwRateCellMap] TO [Talend] 
GRANT SELECT ON [dbo].[vwRateCellMap] TO [Support] 
GRANT SELECT ON [dbo].[vwRateCellMap] TO [webapp] 
GO
-- *****************************************************************************************************
