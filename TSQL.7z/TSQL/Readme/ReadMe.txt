Item: RevRec 2.0 (Replacement)
 
 
Jira item#: https://commonwealthcare.atlassian.net/browse/
SVN Tag (ticket#): https://srvmedsvnp01.commonwealthcare.org/svn/ReportingApps/tags/

Development Server: SRVMARSQLD05\CCA
Test Server: SRVMLBSQLT05\CCA
Production Server: SRVMEDSQLP05\CCA
Primary Database: RevRec

Cross-Databases (if any):
	MPSnapshotProd
	PDRIn
	MDM/PartnerStage?

Permissions: 
	talend
	support
	webapp

Integration Jobs:
	Build
	Integration Tool: Talend
	Repository: 
	Folders: 
	Jobs:
		Master Job: 
		Sub Job: 


 
Reason: 

	Web application to replace RevRec.


Special Instructions:


Deployment Order: (manifestFile.txt)... or list order below using guided outline

	One-Time Tag Items:
		Schema
		Scripts
	Permanent Trunk Items: 
		Tables
		Views
		Functions
		Triggers
		StoredProcedures
		

(Includes dates/tags where available)
Release Notes:
	
	
Bug Fixes:

